#include "lcd.h"

/////////////////////////////////////
// Global variable for LCD write
/////////////////////////////////////
uint32_t RAM24[4];

uint8_t const Apins[]={8,9,10,15};                       	// 0 ,,, 3
uint8_t const Bpins[]={0,1,3,4,5,8,9,15};     			// 0 ,,, 8
uint8_t const Cpins[]={0,1,2,3,4,5,6,7,8,9,10,11,12};     // 0 ,,, 12
uint8_t const Dpins[]={2};								// 2 LCD progl

uint8_t const MAP[]={26,27,24,25,6,15,23,5,21,22,20,17,18,19,41,42,43,7,8,9,16,40}; //14 - Numeric chars, then pfh, funcl, progl, arrow, bat, ant, sim1, sim2
		
void PinCfgA(char PIN, char MODE, char FUNC){  
       GPIOA->MODER         &=  ~(0x03<<(2*PIN)) ;     // Mode mask 
       GPIOA->MODER         |=    MODE<<(2*PIN) ;      // 0=i; 1=O; 2=AltFun; 3=Analog  
       GPIOA->OTYPER 		&=  ~(1<<PIN) ;            // PushPull(0)      
       GPIOA->OSPEEDR       &=  ~(0x03<<(2*PIN)) ;     // Speed mask       
       GPIOA->OSPEEDR       |=    0x01<<(2*PIN) ;      // 2 MHz(01)                  
       GPIOA->PUPDR         &=  ~(0x03<<(2*PIN)) ;     // PUPD mask 
	   GPIOA->PUPDR     	|=   (0x00<<(2*PIN)) ;     // No PUPD(00)
       GPIOA->ODR           &=     ~(1<<PIN) ;                // Clear PIN		
       if(PIN<=7){
              GPIOA->AFR[0] &=  ~(0x0F<<(4*PIN)) ;            // AFR mask
              GPIOA->AFR[0]        |=    FUNC<<(4*PIN) ;             // Alt Func
              } else{
              GPIOA->AFR[1]        &=  ~(0x0F<<(4*(PIN-8))); // AFR mask
              GPIOA->AFR[1]        |=    FUNC<<(4*(PIN-8)) ; // Alt Func
              } 
}
                                                                                                                      
void PinCfgB(char PIN, char MODE, char FUNC){  
       GPIOB->MODER         &=  ~(0x03<<(2*PIN)) ;     // Mode mask 
       GPIOB->MODER         |=    MODE<<(2*PIN) ;      // 0=i; 1=O; 2=AltFun; 3=Analog  
       GPIOB->OTYPER 		&=  ~(1<<PIN) ;            // PushPull(0)      
       GPIOB->OSPEEDR       &=  ~(0x03<<(2*PIN)) ;     // Speed mask       
       GPIOB->OSPEEDR       |=    0x01<<(2*PIN) ;      // 2 MHz(01)                  
       GPIOB->PUPDR         &=  ~(0x03<<(2*PIN)) ;     // PUPD mask 
	   GPIOB->PUPDR     	|=   (0x00<<(2*PIN)) ;     // No PUPD(00)
       GPIOB->ODR           &=  ~(1<<PIN) ;         	// Clear PIN
	   GPIOB->BSRRL 		|= (0x01<<PIN);	
       if(PIN<=7){
              GPIOB->AFR[0] &=  ~(0x0F<<(4*PIN)) ;            // AFR mask
              GPIOB->AFR[0]        |=    FUNC<<(4*PIN) ;             // Alt Func
              } else{
              GPIOB->AFR[1]        &=  ~(0x0F<<(4*(PIN-8))); // AFR mask
              GPIOB->AFR[1]        |=    FUNC<<(4*(PIN-8)) ; // Alt Func
              } 
}

void PinCfgC(char PIN, char MODE, char FUNC){  
       GPIOC->MODER         &=  ~(0x03<<(2*PIN)) ;     // Mode mask 
       GPIOC->MODER         |=    MODE<<(2*PIN) ;      // 0=i; 1=O; 2=AltFun; 3=Analog  
       GPIOC->OTYPER 		&=  ~(1<<PIN) ;            // PushPull(0)      
       GPIOC->OSPEEDR       &=  ~(0x03<<(2*PIN)) ;     // Speed mask       
       GPIOC->OSPEEDR       |=    0x01<<(2*PIN) ;      // 2 MHz(01)                  
       GPIOC->PUPDR         &=  ~(0x03<<(2*PIN)) ;     // PUPD mask 
	   GPIOC->PUPDR     	|=   (0x00<<(2*PIN)) ;     // No PUPD(00)
       GPIOC->ODR           &=     ~(1<<PIN) ;                // Clear PIN
       if(PIN<=7){
              GPIOC->AFR[0] &=  ~(0x0F<<(4*PIN)) ;            // AFR mask
              GPIOC->AFR[0]        |=    FUNC<<(4*PIN) ;      // Alt Func
              } else{
              GPIOC->AFR[1]        &=  ~(0x0F<<(4*(PIN-8))); // AFR mask
              GPIOC->AFR[1]        |=    FUNC<<(4*(PIN-8)) ; // Alt Func
              } 
}
void PinCfgD(char PIN, char MODE, char FUNC){  
       GPIOD->MODER         &=  ~(0x03<<(2*PIN)) ;     // Mode mask 
       GPIOD->MODER         |=    MODE<<(2*PIN) ;      // 0=i; 1=O; 2=AltFun; 3=Analog  
       GPIOD->OTYPER 		&=  ~(1<<PIN) ;            // PushPull(0)      
       GPIOD->OSPEEDR       &=  ~(0x03<<(2*PIN)) ;     // Speed mask       
       GPIOD->OSPEEDR       |=    0x01<<(2*PIN) ;      // 2 MHz(01)                  
       GPIOD->PUPDR         &=  ~(0x03<<(2*PIN)) ;     // PUPD mask 
	   GPIOD->PUPDR     	|=   (0x00<<(2*PIN)) ;     // No PUPD(00)
       GPIOD->ODR           &=     ~(1<<PIN) ;                // Clear PIN		
       if(PIN<=7){
              GPIOD->AFR[0] &=  ~(0x0F<<(4*PIN)) ;            // AFR mask
              GPIOD->AFR[0]        |=    FUNC<<(4*PIN) ;             // Alt Func
              } else{
              GPIOD->AFR[1]        &=  ~(0x0F<<(4*(PIN-8))); // AFR mask
              GPIOD->AFR[1]        |=    FUNC<<(4*(PIN-8)) ; // Alt Func
              } 
}		
		
void LCD_init(void)
{
	   uint8_t i;
       //  LCD Configuration             
       RCC->APB1ENR |=  RCC_APB1ENR_LCDEN ;   
	   
       for(i=0;i<4;i++){   PinCfgA(Apins[i],2,11); }
       for(i=0;i<8;i++){ 	PinCfgB(Bpins[i],2,11); }
       for(i=0;i<13;i++){  PinCfgC(Cpins[i],2,11); }
	   for(i=0;i<1;i++){ 	PinCfgD(Dpins[i],2,11); } 
		///////////////////////////////////////////////////////
		//LCD init
		///////////////////////////////////////////////////////
		// external voltage source DUTY 1/4 BIAS 1/4
	   //LCD->CR &= ~LCD_CR_VSEL | (~LCD_CR_DUTY_2 | ~LCD_CR_DUTY_1 | ~LCD_CR_DUTY_0) | ~LCD_CR_BIAS_0 | ~LCD_CR_BIAS_1 | ~LCD_CR_MUX_SEG;  
	   LCD->CR |= LCD_CR_VSEL | LCD_CR_DUTY_1 | LCD_CR_DUTY_0;  
		
		// clock prescale 8 divider 19 blink enabled flcd/64 contrast VLCD3 pulse on duration 3
      // LCD->FCR &= ~LCD_FCR_PS_3 | ~LCD_FCR_PS_2 | ~LCD_FCR_PS_1 | ~LCD_FCR_PS_0 | ~LCD_FCR_DIV_3 | ~LCD_FCR_DIV_2 | ~LCD_FCR_DIV_1 | ~LCD_FCR_DIV_0 | //~LCD_FCR_DEAD_0 |              ~LCD_FCR_DEAD_1  | ~LCD_FCR_DEAD_2	|  ~LCD_FCR_BLINK_1 | ~LCD_FCR_BLINK_0 | ~LCD_FCR_BLINKF_2 | ~LCD_FCR_BLINKF_1 |// ~LCD_FCR_BLINKF_0 | ~LCD_FCR_CC_2 | ~LCD_FCR_CC_1 |     ~LCD_FCR_CC_0 | ~LCD_FCR_PON_2 | ~LCD_FCR_PON_1 | ~LCD_FCR_PON_0;
		LCD->FCR |= LCD_FCR_PS_1 | LCD_FCR_DIV_3 | LCD_FCR_DEAD_0 | LCD_FCR_CC_2 | LCD_FCR_CC_1 | LCD_FCR_CC_0 | LCD_FCR_PON_2 | LCD_FCR_PON_1 | LCD_FCR_PON_0;
		
		// LCD enable
       LCD->CR |= LCD_CR_LCDEN;
	   
	   while((LCD->SR&LCD_SR_RDY) == 0); // Wait till ready
	   
	   // INIT
		RAM24[0] = 0;
		RAM24[1] = 0;
		RAM24[2] = 0;	
		RAM24[3] = 0;
		        
}

void LCD_off(void)
{
	// LCD enable
    LCD->CR &= ~LCD_CR_LCDEN;
	while((LCD->SR&LCD_SR_ENS) != 0); // Wait till ready
	RCC->APB1ENR &= ~RCC_APB1ENR_LCDEN;   
}

void LCD_sign(uint8_t LCD_special, uint8_t state)
{
	uint32_t temp[4];
	temp[0] = 0;
	temp[1] = 0;
	temp[2] = 0;	
	temp[3] = 0;
	switch(LCD_special)
	{
		case LCD_SPECIAL_MEM:
			temp[3] = 0x00200000;	
		break;
		case LCD_SPECIAL_MINUS:
			temp[2] = 0x00200000;	
		break;
		case LCD_SPECIAL_ERR:
			temp[1] = 0x00200000;	
		break;
		case LCD_SPECIAL_DOL:
			temp[0] = 0x00200000;	
		break;
		case LCD_SPECIAL_BC8:
			temp[3] = 0x00100000;	
		break;
		case LCD_SPECIAL_RX:
			temp[2] = 0x00100000;	
		break;
		case LCD_SPECIAL_TX:
			temp[1] = 0x00100000;	
		break;
		case LCD_SPECIAL_ENV:
			temp[0] = 0x00100000;	
		break;		
		case LCD_SPECIAL_A0:
			temp[3] = 0x00080000;	
		break;
		case LCD_SPECIAL_A1:
			temp[2] = 0x00080000;	
		break;
		case LCD_SPECIAL_A2:
			temp[1] = 0x00080000;	
		break;
		case LCD_SPECIAL_ANT:
			temp[0] = 0x00080000;	
		break;
		case LCD_SPECIAL_BB:
			temp[3] = 0x00040000;	
		break;
		case LCD_SPECIAL_B0:
			temp[2] = 0x00040000;	
		break;
		case LCD_SPECIAL_B1:
			temp[1] = 0x00040000;	
		break;
		case LCD_SPECIAL_BT:
			temp[0] = 0x00040000;	
		break;
		case LCD_SPECIAL_AL:
			temp[3] = 0x00020000;	
		break;
		case LCD_SPECIAL_AD:
			temp[2] = 0x00020000;	
		break;
		case LCD_SPECIAL_AR:
			temp[1] = 0x00020000;	
		break;
		case LCD_SPECIAL_AU:
			temp[0] = 0x00020000;	
		break;
		case LCD_SPECIAL_P2:
			temp[3] = 0x00010000;	
		break;
		case LCD_SPECIAL_P1:
			temp[2] = 0x00010000;
		break;
		case LCD_SPECIAL_P0:
			temp[1] = 0x00010000;	
		break;
		case LCD_SPECIAL_PL:
			temp[0] = 0x00010000;	
		break;
		case LCD_SPECIAL_F4:
			temp[3] = 0x00008000;	
		break;
		case LCD_SPECIAL_F3:
			temp[2] = 0x00008000;	
		break;
		case LCD_SPECIAL_F2:
			temp[1] = 0x00008000;	
		break;
		case LCD_SPECIAL_F1:
			temp[0] = 0x00008000;	
		break;
		case LCD_SPECIAL_P3:
			temp[3] = 0x00004000;	
		break;
		case LCD_SPECIAL_P4:
			temp[2] = 0x00004000;	
		break;
		case LCD_SPECIAL_PR:
			temp[1] = 0x00004000;	
		break;
		case LCD_SPECIAL_F5:
			temp[0] = 0x0000400;	
		break;
		default:	
			temp[0] = 0;
			temp[1] = 0;
			temp[2] = 0;	
			temp[3] = 0;
		break;
	}
	if(state){	
		// set
		RAM24[0] |= temp[2];
		RAM24[1] |= temp[1];
		RAM24[2] |= temp[0];
		RAM24[3] |= temp[3];
	}else{
		// clear
		RAM24[0] &= ~temp[2];
		RAM24[1] &= ~temp[1];
		RAM24[2] &= ~temp[0];
		RAM24[3] &= ~temp[3];
	}
	
	while((LCD->SR&LCD_SR_UDR));
	LCD96map();
	LCD->SR |= LCD_SR_UDR;
}

void LCD_put(char LCD_char, uint8_t LCD_seg)
{
	uint32_t temp[4];
	switch (LCD_char)
	{	
		//GRES PO COM-IH
		//TEMP[3] - sovpada COM3
		case '0':
			temp[0] = 0x03;
			temp[1] = 0x02;
			temp[2] = 0x03;
			temp[3] = 0x02;
		break;
		case '1':
			temp[0] = 0x00000000;
			temp[1] = 0x00000002;
			temp[2] = 0x00000002;
			temp[3] = 0x00000000;
		break;
		case '2':
			temp[0] = 0x02;
			temp[1] = 0x03;
			temp[2] = 0x01;
			temp[3] = 0x02;
		break;
		case '3':
			temp[0] = 0x00000002;
			temp[1] = 0x00000003;
			temp[2] = 0x00000002;
			temp[3] = 0x00000002;
		break;
		case '4':
			temp[0] = 0x00000001;
			temp[1] = 0x00000003;
			temp[2] = 0x00000002;
			temp[3] = 0x00000000;
		break;
		case '5':
			temp[0] = 0x03;
			temp[1] = 0x01;
			temp[2] = 0x02;
			temp[3] = 0x02;
		break;
		case '6':
			temp[0] = 0x00000003;
			temp[1] = 0x00000001;
			temp[2] = 0x00000003;	
			temp[3] = 0x00000002;
		break;
		case '7':
			temp[0] = 0x00000002;
			temp[1] = 0x00000002;
			temp[2] = 0x00000002;
			temp[3] = 0x00000000;
		break;
		case '8':
			temp[0] = 0x00000003;
			temp[1] = 0x00000003;
			temp[2] = 0x00000003;	
			temp[3] = 0x00000002;
		break;
		case '9':
			temp[0] = 0x00000003;
			temp[1] = 0x00000003;
			temp[2] = 0x00000002;	
			temp[3] = 0x00000002;
		break;
		case 'A':
		case 'a':
			temp[0] = 0x00000003;
			temp[1] = 0x00000003;
			temp[2] = 0x00000003;	
			temp[3] = 0x00000000;
		break;
		case 'b':
		case 'B':
			temp[0] = 0x00000001;
			temp[1] = 0x00000001;
			temp[2] = 0x00000003;	
			temp[3] = 0x00000002;
		break;
		case 'C':
		case 'c':
			temp[0] = 0x00000000;
			temp[1] = 0x00000001;
			temp[2] = 0x00000001;	
			temp[3] = 0x00000002;
		break;
		case 'D':
		case 'd':
			temp[0] = 0x00;
			temp[1] = 0x03;
			temp[2] = 0x03;
			temp[3] = 0x02;
		break;
		case 'E':
		case 'e':
			temp[0] = 0x00000003;
			temp[1] = 0x00000001;
			temp[2] = 0x00000001;	
			temp[3] = 0x00000002;
		break;
		case 'F':
		case 'f':
			temp[0] = 0x00000003;
			temp[1] = 0x00000001;
			temp[2] = 0x00000001;	
			temp[3] = 0x00000000;
		break;
		case 'G':
		case 'g':
			temp[0] = 0x03;
			temp[1] = 0x00;
			temp[2] = 0x03;
			temp[3] = 0x02;
		break;
		case 'H':
		case 'h':
			temp[0] = 0x01;
			temp[1] = 0x01;
			temp[2] = 0x03;	
			temp[3] = 0x00;
		break;
		case 'i':
		case 'I':
			temp[0] = 0x01;
			temp[1] = 0x00;
			temp[2] = 0x01;
			temp[3] = 0x00;
		break;
		case 'j':
		case 'J':
			temp[0] = 0x00;
			temp[1] = 0x02;
			temp[2] = 0x02;
			temp[3] = 0x02;
		break;
		case 'K':
		case 'k':
			temp[0] = 0x03;
			temp[1] = 0x01;
			temp[2] = 0x03;
			temp[3] = 0x00;
		break;
		case 'L':
		case 'l':
			temp[0] = 0x00000001;
			temp[1] = 0x00000000;
			temp[2] = 0x00000001;	
			temp[3] = 0x00000002;
		break;
		case 'M':
		case 'm':
			temp[0] = 0x02;
			temp[1] = 0x00;
			temp[2] = 0x03;
			temp[3] = 0x00;
		break;
		case 'n':
		case 'N':
			temp[0] = 0x00;
			temp[1] = 0x01;
			temp[2] = 0x03;
			temp[3] = 0x00;
		break;
		case 'O':
		case 'o':
			temp[0] = 0x00000000;
			temp[1] = 0x00000001;
			temp[2] = 0x00000003;	
			temp[3] = 0x00000002;
		break;
		case 'P':
		case 'p':
			temp[0] = 0x00000003;
			temp[1] = 0x00000003;
			temp[2] = 0x00000001;	
			temp[3] = 0x00000000;
		break;
		case 'Q':
		case 'q':
			temp[0] = 0x03;
			temp[1] = 0x03;
			temp[2] = 0x00;
			temp[3] = 0x02;
		break;
		case 'r':
		case 'R':
			temp[0] = 0x00000000;
			temp[1] = 0x00000001;
			temp[2] = 0x00000001;	
			temp[3] = 0x00000000;
		break;
		case 's':
		case 'S':
			temp[0] = 0x03;
			temp[1] = 0x01;
			temp[2] = 0x02;
			temp[3] = 0x02;
		break;
		case 'T':
		case 't':
			temp[0] = 0x01;
			temp[1] = 0x01;
			temp[2] = 0x01;
			temp[3] = 0x02;
		break;
		case 'U':
		case 'u':
			temp[0] = 0x00000001;
			temp[1] = 0x00000002;
			temp[2] = 0x00000003;	
			temp[3] = 0x00000002;
		break;
		case 'V':
		case 'v':
			temp[0] = 0x00000000;
			temp[1] = 0x00000000;
			temp[2] = 0x00000003;	
			temp[3] = 0x00000002;
		break;
		case 'W':
		case 'w':
			temp[0] = 0x01;
			temp[1] = 0x02;
			temp[2] = 0x00;
			temp[3] = 0x02;
		break;
		case 'x':
		case 'X':
			temp[0] = 0x01;
			temp[1] = 0x03;
			temp[2] = 0x03;
			temp[3] = 0x00;
		break;
		case 'y':
		case 'Y':
			temp[0] = 0x01;
			temp[1] = 0x02;
			temp[2] = 0x02;
			temp[3] = 0x02;
		break;
		case 'z':
		case 'Z':
			temp[0] = 0x02;
			temp[1] = 0x03;
			temp[2] = 0x01;
			temp[3] = 0x02;
		break;
		case '.':
		case ':':
			temp[0] = 0x00000000;
			temp[1] = 0x00000000;
			temp[2] = 0x00000000;	
			temp[3] = 0x00000001;
		break;
		case ' ':
			temp[0] = 0x00000000;
			temp[1] = 0x00000000;
			temp[2] = 0x00000000;	
			temp[3] = 0x00000000;
		break;
		case '*':
			temp[0] = 0x03;
			temp[1] = 0x00;
			temp[2] = 0x00;	
			temp[3] = 0x00;
		break;
		case '#':
			temp[0] = 0x02;
			temp[1] = 0x01;
			temp[2] = 0x00;	
			temp[3] = 0x00;
		break;
		case '!':
			temp[0] = 0x00;
			temp[1] = 0x02;
			temp[2] = 0x02;	
			temp[3] = 0x01;
		break;
		case '-':
			temp[0] = 0x00;
			temp[1] = 0x01;
			temp[2] = 0x00;	
			temp[3] = 0x00;
		break;
		case '+':
			temp[0] = 0x01;
			temp[1] = 0x01;
			temp[2] = 0x01;	
			temp[3] = 0x00;
		break;
		case '/':
			temp[0] = 0x00;
			temp[1] = 0x03;
			temp[2] = 0x01;	
			temp[3] = 0x00;
		break;
		case '(':
			temp[0] = 0x03;
			temp[1] = 0x01;
			temp[2] = 0x00;	
			temp[3] = 0x02;
		break;
		case ')':
			temp[0] = 0x02;
			temp[1] = 0x02;
			temp[2] = 0x02;	
			temp[3] = 0x02;
		break;
		default:
			temp[0] = 0;
			temp[1] = 0;
			temp[2] = 0;	
			temp[3] = 0;
		break;
	}
	temp[0] <<= LCD_seg*2;
	temp[1] <<= LCD_seg*2;
	temp[2] <<= LCD_seg*2;
	temp[3] <<= LCD_seg*2;	
	// clear 
	if(LCD_char != '.' && LCD_char != ':'){
		RAM24[0] &= ~(0x03<<(LCD_seg*2));
		RAM24[1] &= ~(0x03<<(LCD_seg*2));
		RAM24[2] &= ~(0x03<<(LCD_seg*2));
		RAM24[3] &= ~(0x03<<(LCD_seg*2));
	}
	// set
	RAM24[0] |= temp[2];
	RAM24[1] |= temp[1];
	RAM24[2] |= temp[0];
	RAM24[3] |= temp[3];
	
	//RAM24[0] |= 0x03; //COM2
	//RAM24[1] |= 0x03; // COM1 none
	//RAM24[2] |= 0x03; //COM0
	//RAM24[3] |= 0x03; // COM3
	
	while((LCD->SR&LCD_SR_UDR));
	LCD96map();
	LCD->SR |= LCD_SR_UDR;
}

void LCD_clear(void)
{
	RAM24[0] = 0;
	RAM24[1] = 0;
	RAM24[2] = 0;
	RAM24[3] = 0;
}

void LCD96map(void){
	uint8_t i,b ;   //5,6,7,8,9,15,16,17,18,19,20,21,22,23,24,25,26,27,40,41,42,43   29,16,9,8,7,32,31,30      27,26,25,24,15,6,5,23,22,21,17,20,19,18
   
	for(i=0;i<4;i++){
        LCD->RAM[2*i+1] = 0;
		LCD->RAM[2*i] = 0;
		
		for(b=0;b<22;b++){
			if(MAP[b] > 31){	
				if((RAM24[i] & (1<<b))){
					LCD->RAM[2*i+1] |= (1 << (MAP[b]-32));			//|= (RAM24[i]&(1<<b)) ? 1 <<(MAP[b]) : 0;
				}
			}else{
				if((RAM24[i] & (1<<b))){
					LCD->RAM[2*i] |= (1 << MAP[b]);			//|= (RAM24[i]&(1<<b)) ? 1 <<(MAP[b]) : 0;
				}
			}
		}
	}  
}