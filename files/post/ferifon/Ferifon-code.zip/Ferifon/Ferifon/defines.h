#ifndef DEFINES_H
#define DEFINES_H 1

#define GENERAL_TIMEOUT 5000

//Uart
#define BUFFER_SIZE 1024
#define PC_DEBUG 1
#define FOWARD_TO_PC 1

//GPIO
//Names
#define PIN_STATUS 13
#define PORT_STATUS GPIOC

#define PIN_SIM_RESET 15 
#define PORT_SIM_RESET GPIOC

#define PIN_POWERDOWN 14
#define PORT_POWERDOWN GPIOC

#define PIN_DTR 2
#define PORT_DTR GPIOB

#define EXTI_RING		1
#define EXTI_RING_CLEAR	SYSCFG_EXTICR2_EXTI7
#define EXTI_RING_MASK	SYSCFG_EXTICR2_EXTI7_PB
#define RING_IRQn		EXTI9_5_IRQn

#define RING_IRQHandler	EXTI9_5_IRQHandler

#define RING_IMR		EXTI_IMR_MR7	
#define RING_EMR		EXTI_EMR_MR7
#define RING_RTSR		EXTI_RTSR_TR7
#define RING_FTSR		EXTI_FTSR_TR7
#define RING_PR			EXTI_PR_PR7

#define PIN_RING 7
#define PORT_RING GPIOB

#define PIN_XTAL_EN 1
#define PORT_XTAL_EN GPIOH

#define PIN_XTAL 0
#define PORT_XTAL GPIOH

#define PIN_USB_M 11
#define PORT_USB_M GPIOA

#define PIN_USB_P 12
#define PORT_USB_M GPIOA

//KEY GPIO
//Names
#define EXTI_OK			3
#define EXTI_OK_CLEAR	SYSCFG_EXTICR4_EXTI12
#define EXTI_OK_MASK	SYSCFG_EXTICR4_EXTI12_PB
#define OK_IRQn			EXTI15_10_IRQn

#define OK_IRQHandler	EXTI15_10_IRQHandler

#define OK_IMR		EXTI_IMR_MR12	
#define OK_EMR		EXTI_EMR_MR12
#define OK_RTSR		EXTI_RTSR_TR12
#define OK_FTSR		EXTI_FTSR_TR12
#define OK_PR		EXTI_PR_PR12

#define PIN_KEY_OK 12
#define PORT_KEY_OK GPIOB

#define PIN_KEY_BACK 0
#define PORT_KEY_BACK GPIOA

#define PIN_KEY_R1 1
#define PORT_KEY_R1 GPIOA

#define PIN_KEY_R2 2
#define PORT_KEY_R2 GPIOA

#define PIN_KEY_R3 3
#define PORT_KEY_R3 GPIOA

#define PIN_KEY_R4 4
#define PORT_KEY_R4 GPIOA

#define PIN_KEY_C1 5
#define PORT_KEY_C1 GPIOA

#define PIN_KEY_C2 6
#define PORT_KEY_C2 GPIOA

#define PIN_KEY_C3 7
#define PORT_KEY_C3 GPIOA

//REGEX
#define REGEX_TIMEOUT GENERAL_TIMEOUT
#define MAX_GENERAL 10

//SIM900
#define READ_TIMEOUT GENERAL_TIMEOUT
#define PRINT_NUMBER_MAX 10
//#define FAILSAFE 1

//UI
#define MIN_PIN_SIZE	4
#define MAX_PIN_SIZE	8
#define MAX_NUMBER_SIZE	40

#define MAX_SMS 160
#define MAX_SMS_STORE 20
#define SMS_SAME_CHAR_TIMEOUT 1200

#define MAX_CONTACTS 40 //MUST BE LESS THAN 250
#define MAX_CONTACT_NAME 16

#define LOCK_TIMEOUT 2000

#define SMS_SEEK_AMMOUNT 5

#endif