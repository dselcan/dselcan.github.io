#ifndef INET_H
#define INET_H 1

//Other files
#include "defines.h"
#include "cgpio.h"

#include "regex.h"
#include "sim_misc.h"
#include "usart.h"
#include "rtc.h"

typedef uint8_t sim_error;
#define SIM_NO_ERROR 0
#define SIM_TIMEOUT_ERROR 1
#define SIM_CONNECTION_ERROR 2
#define SIM_DEVICE_ERROR 3

extern uint8_t status; //Each bit is a warning
#define STATUS_NORMAL 0x00
#define STATUS_ON_CALL 0x01
#define STATUS_SIM_OK 0x02
#define STATUS_NET_OK 0x04

void reset_sim(void);
sim_error status_wait(uint16_t timeout);

sim_error sim_sleep(void);
sim_error sim_stop_sleep(void);

sim_error sim_powerdown(void);
sim_error sim_stop_powerdown(void);
sim_error sim_at_powerdown(void);


sim_error sim_flush_stream(void);
sim_error check_sim_module(void);
sim_error setup_sim_module(void);
sim_error save_sim_settings(void);

sim_error setup_sim_card(char pin[MAX_PIN_SIZE], uint8_t pin_num, uint8_t puk_now);
sim_error check_sim_card_status(uint8_t* sim_card_status);
#define SIM_CARD_STATUS_OK 0
#define SIM_CARD_STATUS_NO_PIN 1
#define SIM_CARD_STATUS_NO_CARD 2
#define SIM_CARD_STATUS_PUK 3

sim_error check_network_status(uint8_t* network_status);
#define SIM_NETWORK_STATUS_OK 0
#define SIM_NETWORK_STATUS_ERROR 1

sim_error sim_start_call(char* number, uint8_t size);
sim_error sim_read_call(char* number, uint8_t* size);
sim_error sim_accept_call(void);
sim_error sim_end_call(void);
sim_error sim_send_busy(void);

sim_error sim_check_call(uint8_t* call_status, uint16_t timeout);
#define SIM_CALL_NO_CALL 0x01
#define SIM_CALL_RINGING 0x02
#define SIM_CALL_CALLING 0x03
#define SIM_CALL_MASK_V 0x0f

//These act like flags
#define SIM_CALL_M_RINGING 0x10
#define SIM_CALL_M_CALLING 0x20
#define SIM_CALL_M_NO_CALL 0x40

sim_error sim_send_sms(char* message, uint8_t length, char* number, uint8_t number_length);
sim_error sim_sms_details(uint8_t index, uint8_t* status, char* number, uint8_t* number_length);
sim_error sim_read_sms(uint8_t index, char* message, uint8_t* length);
sim_error sim_sms_ammount(uint8_t* size);
sim_error sim_sms_enumerate(uint8_t* status);
sim_error sim_delete_sms(void);

#define SIM_NO_SMS		0x00
#define SIM_SMS_READ 	0x01
#define SIM_SMS_UNREAD 	0x02
#define SIM_SMS_SENT 	0x03
#define SIM_SMS_UNSENT 	0x04

#define SIM_SMS_STATUS_ALL_READ 	0x00
#define SIM_SMS_STATUS_ONE_UNREAD 	0x01

sim_error sim_add_contact(uint8_t index, char* name, uint8_t name_length, char* number, uint8_t number_length);
sim_error sim_check_contact(uint8_t index); //Will return device error if contact is not present
sim_error sim_check_all_contacts(); //Will return device error if no contact is present
sim_error sim_delete_contact(uint8_t index);
sim_error sim_read_contact(uint8_t index, char* name, uint8_t* name_length, char* number, uint8_t* number_length);

sim_error sim_play_sound(uint16_t frequency, uint16_t duration);
sim_error sim_get_battery(uint16_t* voltage);
sim_error sim_get_signal(uint8_t* signal);
sim_error sim_set_pwm(uint8_t channel, uint8_t ammount);




#endif