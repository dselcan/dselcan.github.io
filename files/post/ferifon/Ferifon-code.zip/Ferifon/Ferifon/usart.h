#ifndef USART_H
#define USART_H 1

#include <stm32l1xx.h>
//Other files
#include "defines.h"
#include "cgpio.h"




#define BUFFER_MAX BUFFER_SIZE
typedef struct{
	char buffer[BUFFER_SIZE];
	uint16_t start;
	uint16_t end;
	//uint16_t fill;
} usart_buffer;


extern usart_buffer sim_buffer;

void init_usart(void);

void start_usart_pc(void);
void stop_usart_pc(void);

void pc_putchar(char c);
void pc_putstring(char* s);
void pc_putint(uint32_t num);

void start_usart_sim(void);
void stop_usart_sim(void);
void usart_sim_baud_rate_override(uint16_t val, uint8_t flow);

char sim_getchar(void);
char sim_filled(void);
void sim_putchar(char c);
void sim_putstring(char* s);
void sim_putstring_const(char const* const sc);

void USART3_IRQHandler(void);


#endif