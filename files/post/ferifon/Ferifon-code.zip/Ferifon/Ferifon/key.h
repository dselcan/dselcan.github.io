#ifndef KEY_HD
#define KEY_HD 1

#include <stm32l1xx.h>
//Other files
#include "defines.h"
#include "cgpio.h"
#include "event.h"

//KEYS 1 to Hash in order of read (4 by 4 by 4).
#define KEY_OK 0
#define KEY_BACK 1
#define KEY_1 2
#define KEY_4 3
#define KEY_7 4
#define KEY_A 5
#define KEY_2 6
#define KEY_5 7
#define KEY_8 8
#define KEY_0 9
#define KEY_3 10
#define KEY_6 11
#define KEY_9 12
#define KEY_H 13

#define KEY_TEMP_OK 0
#define KEY_TEMP_BACK 4

void init_keys(void);

void update_all_keys(void);

uint8_t check_key_state(uint8_t key);

#endif