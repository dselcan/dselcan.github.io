//Other files
#include "defines.h"
#include "usart.h"
#include "regex.h"
#include "rtc.h"
#include "sim900.h"
#include "ui.h"
#include "key.h"
#include "event.h"
#include "player.h"

#include "cgpio.h"


//extern usart_buffer rn_buffer;



void enable_gpio_clocks(void)
{
	//enable clocks to ports
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN;
	RCC->AHBENR |= RCC_AHBENR_GPIOBEN;
	RCC->AHBENR |= RCC_AHBENR_GPIOCEN;
	RCC->AHBENR |= RCC_AHBENR_GPIODEN;
	RCC->AHBENR |= RCC_AHBENR_GPIOHEN;
}

void init_gpio(void)
{
	//ENABLE SYSCFG clock
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;

	GPIO_INPUT(PORT_KEY_OK, PIN_KEY_OK);
	GPIO_PULLUP(PORT_KEY_OK, PIN_KEY_OK);
	GPIO_SPEED_400K(PORT_KEY_OK, PIN_KEY_OK);
	GPIO_FUNCTION(PORT_KEY_OK, PIN_KEY_OK, 0x00);
	
	SYSCFG->EXTICR[EXTI_OK] &= ~EXTI_OK_CLEAR;
	SYSCFG->EXTICR[EXTI_OK] |= EXTI_OK_MASK;
	
	EXTI->IMR |= OK_IMR;
	EXTI->EMR &= ~OK_EMR;
	EXTI->RTSR &= ~OK_RTSR;
	EXTI->FTSR |= OK_FTSR; //Configure EXTI As rising edge Interrupt mode
	EXTI->PR |= OK_PR;
	
	NVIC->IP[OK_IRQn] = 0x3; //Priority 3
	// >> 0x05 take top 3 bits = 32 bits per register, &0x1f - 32 bit mask
    NVIC->ISER[OK_IRQn >> 0x05] = 0x01 << (OK_IRQn & 0x1F); //Enable interrupt - can assing due to it being positive edge triggered
    //NVIC->ICER[OK_IRQn >> 0x05] = 0x01 << (OK_IRQn & 0x1F);

	GPIO_INPUT(PORT_RING, PIN_RING);
	GPIO_SPEED_10M(PORT_RING, PIN_RING);
	GPIO_FUNCTION(PORT_RING, PIN_RING, 0x00);
	
	SYSCFG->EXTICR[EXTI_RING] &= ~EXTI_RING_CLEAR;
	SYSCFG->EXTICR[EXTI_RING] |= EXTI_RING_MASK;
	
	EXTI->IMR |= RING_IMR;
	EXTI->EMR &= ~RING_EMR;
	EXTI->RTSR &= ~RING_RTSR;
	EXTI->FTSR |= RING_FTSR; //Configure EXTI As rising edge Interrupt mode
	EXTI->PR |= RING_PR;
	
	NVIC->IP[RING_IRQn] = 0x3; //Priority 3
	// >> 0x05 take top 3 bits = 32 bits per register, &0x1f - 32 bit mask
    NVIC->ISER[RING_IRQn >> 0x05] = 0x01 << (RING_IRQn & 0x1F); //Enable interrupt - can assing due to it being positive edge triggered
    //NVIC->ICER[RING_IRQn >> 0x05] = 0x01 << (RING_IRQn & 0x1F);
	
	GPIO_INPUT(PORT_STATUS, PIN_STATUS);
	GPIO_SPEED_10M(PORT_STATUS, PIN_STATUS);
	GPIO_FUNCTION(PORT_STATUS, PIN_STATUS, 0x00);
	
	GPIO_RESET(PORT_SIM_RESET, PIN_SIM_RESET);
	GPIO_INPUT(PORT_SIM_RESET, PIN_SIM_RESET);
	GPIO_PUSHPULL(PORT_SIM_RESET, PIN_SIM_RESET);
	GPIO_SPEED_10M(PORT_SIM_RESET, PIN_SIM_RESET);
	GPIO_FUNCTION(PORT_SIM_RESET, PIN_SIM_RESET, 0x00);
	
	GPIO_RESET(PORT_POWERDOWN, PIN_POWERDOWN);
	GPIO_INPUT(PORT_POWERDOWN, PIN_POWERDOWN);
	GPIO_PUSHPULL(PORT_POWERDOWN, PIN_POWERDOWN);
	GPIO_SPEED_10M(PORT_POWERDOWN, PIN_POWERDOWN);
	GPIO_FUNCTION(PORT_POWERDOWN, PIN_POWERDOWN, 0x00);
	
	GPIO_RESET(PORT_DTR, PIN_DTR);
	GPIO_OUTPUT(PORT_DTR, PIN_DTR);
	GPIO_PUSHPULL(PORT_DTR, PIN_DTR);
	GPIO_SPEED_10M(PORT_DTR, PIN_DTR);
	GPIO_FUNCTION(PORT_DTR, PIN_DTR, 0x00);

	GPIO_RESET(PORT_XTAL_EN, PIN_XTAL_EN);
	GPIO_OUTPUT(PORT_XTAL_EN, PIN_XTAL_EN);
	GPIO_PUSHPULL(PORT_XTAL_EN, PIN_XTAL_EN);
	GPIO_SPEED_10M(PORT_XTAL_EN, PIN_XTAL_EN);
	GPIO_FUNCTION(PORT_XTAL_EN, PIN_XTAL_EN, 0x00);
}

void configure_interrupts(void)
{
	//Got values from misc.c
	//Priorities 0x700 to 0x300, Group_0 = 0x700 - no priority; Group_4 = 0x300 - all priority
	SCB->AIRCR = 0x05FA0000 | 0x300;
}

void enter_sleep(void)
{
	__WFI();
}

void OK_IRQHandler(void)
{
	if(EXTI->PR&OK_PR){
		if(!reset){
			pc_putchar('O');
			sim_stop_sleep();
			if(!tick_timer){
				enable_tick_interrupt();
			}
		}else{
			reset = 0;
			NVIC_SystemReset();
		}
		EXTI->PR |= OK_PR;
	}
}

void RING_IRQHandler(void)
{
	if(EXTI->PR&RING_PR){
		pc_putchar('C');
		update_flags |= (1<<UPDATE_RING);
		sim_stop_sleep();
		if(!tick_timer){
			enable_tick_interrupt();
		}
	
		EXTI->PR |= RING_PR;
	}
}

int main ( void )
{
	SCB->SCR &= ~SCB_SCR_SLEEPDEEP;
	PWR->CR &= ~PWR_CR_LPSDSR;
	reset = 0;
	sim_error error;
	
	configure_interrupts();
	enable_gpio_clocks();
	init_usart();
	init_rtc();
	init_gpio();
	
	uint32_t reset_vector = RCC->CSR;
	pc_putstring("\nR-");
	if(reset_vector & RCC_CSR_LPWRRSTF){// Low-Power reset flag
		pc_putchar('L');
	}
	if(reset_vector & RCC_CSR_OBLRSTF){ // Option Bytes Loader reset flag
		pc_putchar('O');
	}
	if(reset_vector & RCC_CSR_PINRSTF){ // PIN reset flag
		pc_putchar('N');
	}
	if(reset_vector & RCC_CSR_PORRSTF){ // POR/PDR reset flag
		pc_putchar('P');
	}
	if(reset_vector & RCC_CSR_SFTRSTF){ // Software Reset flag
		pc_putchar('S');
	}
	if(reset_vector & RCC_CSR_IWDGRSTF){ // Independent Watchdog reset flag
		pc_putchar('I');
	}
	if(reset_vector & RCC_CSR_WWDGRSTF){ // Window watchdog reset flag
		pc_putchar('W');
	}
	pc_putchar('\n');
	RCC->CSR |= RCC_CSR_RMVF; // Reset flags
	
	
	init_keys();
	update_flags &= ~(1<<UPDATE_RING);
	LCD_init();
	
	sim_powerdown();
	delay_ms(2000);
	sim_stop_powerdown();
	
	
	pc_putstring("ALL OK.\r\n");
	//reset_sim();
	while(status_wait(GENERAL_TIMEOUT)){
		delay_ms(1000);
		sim_powerdown();
		delay_ms(2000);
		sim_stop_powerdown();
	}
	
	error = check_sim_module();
	sim_error error_temp = setup_sim_module();
	if(error_temp){
		//problem
	}
	
	if(error == SIM_DEVICE_ERROR){
		error = save_sim_settings();
	}
	
	if(error){
		//Probably reset the module
	}
	
	
	
	uint8_t current_ui = UI_NONE;
	uint8_t next_ui = UI_NONE;
	uint8_t new;
	set_event(EVENT_FORCE_CALL_RESET);
	
	while(1){
		if(current_ui == UI_NONE){
			new = 1;
			current_ui = UI_INTRO;
		}
		
		if(update_flags&(1<<UPDATE_SOUND)){
			update_flags &= ~(1<<UPDATE_SOUND);
			error = sim_play_sound(sound_sequence[current_sound].frequency[current_sound_frame], sound_sequence[current_sound].duration[current_sound_frame]);
			if(error){
				//Doesn't really matter anyway
			}
		}
		
		if(update_flags&(1<<UPDATE_LED)){
			update_flags &= ~(1<<UPDATE_LED);
			error = sim_set_pwm(2, led_sequence[current_led].brightness[current_led_frame]);
			if(error){
				//Doesn't really matter anyway
			}
		}
		
		//Important update checks!
		if((update_flags&(1<<UPDATE_RING)) || check_event(EVENT_CALL_RING_ERROR)){
			if (current_ui != UI_DURING_CALL){
				//First check if call
				uint8_t call_status;
				error = sim_check_call(&call_status, READ_TIMEOUT);
				if(!error){
					if(call_status == SIM_CALL_RINGING){
						set_event(EVENT_CALL_RING);
					}
				}else{
					//Maybe do something with error
				}
				
				if(!check_event(EVENT_CALL_RING)){
					update_flags &= ~(1<<UPDATE_RING);
					
					//Then check SMS
					uint8_t sms_status;
					error = sim_sms_enumerate(&sms_status);
					if(!error){
						if(sms_status == SIM_SMS_STATUS_ONE_UNREAD){
							schedule_sound(SOUND_SMS, 1);
							schedule_led(LED_BLINK, 5);
							LCD_sign(LCD_SPECIAL_ENV, LCD_ON);
						}
					}else{
						//Same as above
					}	
					
					if(check_event(EVENT_CALL_RING_ERROR)){
						clear_event(EVENT_CALL_RING_ERROR);
						pc_putstring("R-R\n");
					}
				}
			}
		}
		
		if(update_flags&(1<<UPDATE_MISC)){
			update_flags &= ~(1<<UPDATE_MISC);
			uint8_t put_to_sleep = 0;
			if(!tick_timer){
				put_to_sleep = 1;
				sim_stop_sleep();
			}
			uint16_t voltage;
			uint8_t signal;
			error = sim_get_battery(&voltage);
			if(error){
				//I dunno
			}
			if(voltage > 4200){
				display_battery(4);
			}else if(voltage > 4000){
				display_battery(3);
			}else if(voltage > 3800){
				display_battery(2);
			}else{
				display_battery(1);
			}
			error = sim_get_signal(&signal);
			if(error){
				//I dunno
			}
			if(signal == 99){
				display_signal(0);
			}else if(signal > 20){
				display_signal(3);
			}else if(signal > 10){
				display_signal(2);
			}else if(signal > 5){
				display_signal(1);
			}else{
				display_signal(0);
			}
			
			if(put_to_sleep){
				sim_sleep();
			}
		}
		
		//UI handle
		
		next_ui = handle_critical(current_ui);
		if(next_ui){
			clear_event_user();
			new = 1;
			current_ui = next_ui;
		}
		
		next_ui = handle_ui(current_ui, new);
		if(next_ui){
			clear_event_user();
			new = 1;
			current_ui = next_ui;
		}else{
			new = 0;
		}
		
		//Draw screen
		if(update_flags&(1<<UPDATE_SCREEN)){
			update_flags &= ~(1<<UPDATE_SCREEN);
			display_message();
		}
		
		enter_sleep();
	}
}

void NMI_Handler(void){
while(1);
}
void HardFault_Handler(void){
while(1);
}
void MemMange_Handler(void){
while(1);
}
void BusFault_Handler(void){
while(1);
}
void UsageFault_Handler(void){
while(1);
}
void SVC_Handler(void){
while(1);
}
void DebugMon_Handler(void){
while(1);
}
void PendSV_Handler(void){
while(1);
}
void WWDG_IRQHandler(void){
while(1);
}
void PVD_IRQHandler(void){
while(1);
}
void TAMPER_STAMP_IRQHandler(void){
while(1);
}
void RTC_WKUP_IRQHandler(void){
while(1);
}
void FLASH_IRQHandler(void){
while(1);
}

# ifdef USE_FULL_ASSERT
void assert_failed ( uint8_t * file , uint32_t line )
{
/* Infinite loop */
/* Use GDB to find out why we 're here */
while (1) ;
}
# endif