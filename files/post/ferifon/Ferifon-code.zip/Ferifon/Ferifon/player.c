#include "player.h"


uint16_t ring_frequency_sequence[10] = {0, 400, 350, 350, 300, 400, 350, 300, 300, 0};
uint16_t ring_duration_sequence[10] = {500, 200, 200, 200, 200, 100, 200, 200, 200, 500};

uint16_t sms_frequency_sequence[3] = {400, 350, 300};
uint16_t sms_duration_sequence[3] = {500, 500, 500};

sound_play_sequence sound_sequence[SOUND_SEQUENCES] = 	{{ring_frequency_sequence, ring_duration_sequence, 10},
														{sms_frequency_sequence, sms_duration_sequence, 3}};
														
uint8_t led_on_sequence[1] = {100};
uint16_t led_on_duration[1] = {10};

uint8_t led_off_sequence[1] = {0};
uint16_t led_off_duration[1] = {10};

uint8_t led_blink_sequence[9] = {0, 100};
uint16_t led_blink_duration[9] = {350, 350};

uint8_t led_slow_blink_sequence[9] = {0, 33, 66, 88, 100, 88, 66, 33, 0};
uint16_t led_slow_blink_duration[9] = {390, 120, 120, 240, 120, 120, 120, 390};

led_play_sequence led_sequence[LED_SEQUENCES] = 	{{led_on_sequence, led_on_duration, 1},
													{led_off_sequence, led_off_duration, 1},
													{led_blink_sequence, led_blink_duration, 2},
													{led_slow_blink_sequence, led_slow_blink_duration, 9}};

uint8_t current_sound = 0;
int8_t current_sound_repeat = 0;
uint16_t volatile current_sound_pos = 0;
uint8_t current_sound_frame = 0;

uint8_t current_led = 0;
int8_t current_led_repeat = 0;
uint16_t volatile current_led_pos = 0;
uint8_t current_led_frame = 0;

void schedule_sound(uint8_t position, int8_t repeat)
{
	current_sound = position;
	if(current_sound_repeat > 0){
		current_sound_repeat = repeat;
	}else{
		current_sound_repeat = repeat;
	}
	current_sound_frame = 0;
	current_sound_pos = sound_sequence[current_sound].duration[current_sound_frame];
}

void schedule_led(uint8_t position, int8_t repeat)
{
	current_led = position;
	if(current_led_repeat > 0){
		current_led_repeat = repeat;
	}else{
		current_led_repeat = repeat;
	}
	current_led_frame = 0;
	current_led_pos = led_sequence[current_led].duration[current_led_frame];
}
