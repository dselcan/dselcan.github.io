#ifndef RTC_H
#define RTC_H 1

#include <stm32l1xx.h>
//Other files
#include "defines.h"
#include "cgpio.h"
#include "event.h"
#include "screen.h"
#include "key.h"
#include "player.h"
//#include "usart.h"


extern uint8_t update_flags;
#define UPDATE_MISC 1
#define UPDATE_SCREEN 2
#define UPDATE_RING 3
#define UPDATE_SOUND 4
#define UPDATE_LED 5

#define UPDATE_START_STATE ((1<<UPDATE_MISC) | (1<<UPDATE_SCREEN))

#define MISC_UPDATE_INTERVAL 1000
#define SCREEN_UPDATE_INTERVAL 10

void init_rtc(void);

void delay_ms(uint16_t delay);

void set_timeout(uint16_t timeout);

void set_event_timeout(uint16_t timeout);

uint8_t timeout_occured();


extern uint8_t tick_timer;

void enable_tick_interrupt(void);
uint8_t disable_tick_interrupt(void);


#endif