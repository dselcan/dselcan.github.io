#ifndef PLAYER_H
#define PLAYER_H 1

#include <stm32l1xx.h>
//Other files
#include "defines.h"

typedef struct{
	uint16_t* frequency;
	uint16_t* duration;
	uint8_t size;
} sound_play_sequence;

typedef struct{
	uint8_t* brightness;
	uint16_t* duration;
	uint8_t size;
} led_play_sequence;

#define SOUND_SEQUENCES 2
#define SOUND_RING 0
#define SOUND_SMS 1

#define LED_SEQUENCES 4
#define LED_ON 0
#define LED_OFF 1
#define LED_BLINK 2
#define LED_SLOW_BLINK 3


extern sound_play_sequence sound_sequence[SOUND_SEQUENCES];
extern led_play_sequence led_sequence[LED_SEQUENCES];

extern uint8_t current_sound;
extern int8_t current_sound_repeat;
extern volatile uint16_t current_sound_pos;
extern uint8_t current_sound_frame;

extern uint8_t current_led;
extern int8_t current_led_repeat;
extern volatile uint16_t current_led_pos;
extern uint8_t current_led_frame;

void schedule_sound(uint8_t position, int8_t repeat);
void schedule_led(uint8_t position, int8_t repeat);


#endif