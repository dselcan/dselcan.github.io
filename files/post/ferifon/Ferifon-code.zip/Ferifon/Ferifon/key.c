
#include "key.h"

uint16_t key_pressed;

uint16_t key_previous_num; //1-12 for the matrix
uint8_t key_previous_sel; //1-3 for the ok and 4-6 for back
uint8_t current;

//KEY_1 0 KEY_4 1 KEY_7 2 KEY_A 3 KEY_2 4 KEY_5 5 KEY_8 6 KEY_0 7 KEY_3 8 KEY_6 9 KEY_9 10 KEY_H 11 KEY_OK 12 KEY_BACK 13

uint8_t const key_pin_map[14] = {PIN_KEY_OK, PIN_KEY_BACK, PIN_KEY_R1, PIN_KEY_R2, PIN_KEY_R3, PIN_KEY_R4,
	PIN_KEY_R1, PIN_KEY_R2, PIN_KEY_R3, PIN_KEY_R4,	PIN_KEY_R1, PIN_KEY_R2, PIN_KEY_R3, PIN_KEY_R4};
GPIO_TypeDef* const key_port_map[14] = {PORT_KEY_OK, PORT_KEY_BACK, PORT_KEY_R1, PORT_KEY_R2, PORT_KEY_R3, PORT_KEY_R4,
	PORT_KEY_R1, PORT_KEY_R2, PORT_KEY_R3, PORT_KEY_R4,	PORT_KEY_R1, PORT_KEY_R2, PORT_KEY_R3, PORT_KEY_R4};
uint8_t const key_event_map[14] = {EVENT_KEY_OK, EVENT_KEY_BACK, EVENT_KEY_1, EVENT_KEY_4, EVENT_KEY_7, EVENT_KEY_A,
	EVENT_KEY_2, EVENT_KEY_5, EVENT_KEY_8, EVENT_KEY_0,	EVENT_KEY_3, EVENT_KEY_6, EVENT_KEY_9, EVENT_KEY_H};
uint8_t const key_temp_map[2] = {KEY_TEMP_OK, KEY_TEMP_BACK};
uint8_t const key_sel_dir[2] = {0, 1};

void init_keys(void)
{
	//KEY OK INITED IN MAIN
	
	GPIO_INPUT(PORT_KEY_BACK, PIN_KEY_BACK);
	GPIO_PULLDOWN(PORT_KEY_BACK, PIN_KEY_BACK);
	GPIO_SPEED_400K(PORT_KEY_BACK, PIN_KEY_BACK);
	GPIO_FUNCTION(PORT_KEY_BACK, PIN_KEY_BACK, 0x00);
	
	GPIO_INPUT(PORT_KEY_R1, PIN_KEY_R1);
	GPIO_PULLDOWN(PORT_KEY_R1, PIN_KEY_R1);
	GPIO_SPEED_400K(PORT_KEY_R1, PIN_KEY_R1);
	GPIO_FUNCTION(PORT_KEY_R1, PIN_KEY_R1, 0x00);
	
	GPIO_INPUT(PORT_KEY_R2, PIN_KEY_R2);
	GPIO_PULLDOWN(PORT_KEY_R2, PIN_KEY_R2);
	GPIO_SPEED_400K(PORT_KEY_R2, PIN_KEY_R2);
	GPIO_FUNCTION(PORT_KEY_R2, PIN_KEY_R2, 0x00);
	
	GPIO_INPUT(PORT_KEY_R3, PIN_KEY_R3);
	GPIO_PULLDOWN(PORT_KEY_R3, PIN_KEY_R3);
	GPIO_SPEED_400K(PORT_KEY_R3, PIN_KEY_R3);
	GPIO_FUNCTION(PORT_KEY_R3, PIN_KEY_R3, 0x00);
	
	GPIO_INPUT(PORT_KEY_R4, PIN_KEY_R4);
	GPIO_PULLDOWN(PORT_KEY_R4, PIN_KEY_R4);
	GPIO_SPEED_400K(PORT_KEY_R4, PIN_KEY_R4);
	GPIO_FUNCTION(PORT_KEY_R4, PIN_KEY_R4, 0x00);
	
	GPIO_SET(PORT_KEY_C1, PIN_KEY_C1);
	//GPIO_INPUT(PORT_KEY_C1, PIN_KEY_C1);
	GPIO_OUTPUT(PORT_KEY_C1, PIN_KEY_C1);
	GPIO_PUSHPULL(PORT_KEY_C1, PIN_KEY_C1);
	GPIO_SPEED_400K(PORT_KEY_C1, PIN_KEY_C1);
	GPIO_FUNCTION(PORT_KEY_C1, PIN_KEY_C1, 0x00);
	
	GPIO_SET(PORT_KEY_C2, PIN_KEY_C2);
	GPIO_INPUT(PORT_KEY_C2, PIN_KEY_C2);
	GPIO_PUSHPULL(PORT_KEY_C2, PIN_KEY_C2);
	GPIO_SPEED_400K(PORT_KEY_C2, PIN_KEY_C2);
	GPIO_FUNCTION(PORT_KEY_C2, PIN_KEY_C2, 0x00);
	
	GPIO_SET(PORT_KEY_C3, PIN_KEY_C3);
	GPIO_INPUT(PORT_KEY_C3, PIN_KEY_C3);
	GPIO_PUSHPULL(PORT_KEY_C3, PIN_KEY_C3);
	GPIO_SPEED_400K(PORT_KEY_C3, PIN_KEY_C3);
	GPIO_FUNCTION(PORT_KEY_C3, PIN_KEY_C3, 0x00);
	
	current = 0;
	key_pressed = 0x0000;
	key_previous_num = 0x00;
	key_previous_sel = 0x00;
}

uint8_t check_key_sel_on(uint8_t offset)
{
	return (((key_previous_sel&(0x07<<offset))>>offset) == 0x07);
}

uint8_t check_key_sel_off(uint8_t offset)
{
	return (((key_previous_sel&(0x07<<offset))>>offset) == 0x00);
}

uint8_t key_update_sel(uint8_t key){
	uint8_t now;
	if(GPIO_READ(key_port_map[key], key_pin_map[key]) ? key_sel_dir[key] : !key_sel_dir[key]){ //A complex way to differ between the pullup and pulldown on ok and back
		now = 1;
		if(!(key_pressed&(1<<key)) && check_key_sel_on(key_temp_map[key])){ //Not previous and all to 1
			key_pressed |= (1<<key);
			set_event(key_event_map[key]);
		}
	}else{
		now = 0;
		if((key_pressed&(1<<key)) && check_key_sel_off(key_temp_map[key])){
			key_pressed &= ~(1<<key);
		}	
	}
	if(now){
		key_previous_sel |= (1 << (key_temp_map[key] + current));
	}else{
		key_previous_sel &= ~(1 << (key_temp_map[key] + current));
	}
	return now;
}

uint8_t key_update_num(uint8_t key){
	uint8_t now;
	if(GPIO_READ(key_port_map[key], key_pin_map[key])){
		now = 1;
		if(!(key_pressed&(1<<key)) &&  (key_previous_num&(1<<key))){
			key_pressed |= (1<<key);
			set_event(key_event_map[key]);
		}
	}else{
		now = 0;
		if((key_pressed&(1<<key)) &&  !(key_previous_num&(1<<key))){
			key_pressed &= ~(1<<key);
		}
	}
	if(now){
		key_previous_num |= (1<<key);
	}else{
		key_previous_num &= ~(1<<key);
	}
	return now;
}


//Runs in the rtc loop to read the values, then updates the events
void update_all_keys(void)
{
	//Key OK
	key_update_sel(KEY_OK);
	
	//Key BACK
	key_update_sel(KEY_BACK);
	
	//KEY 1,4,7,A
	if(current == 0){
		key_update_num(KEY_1);
		
		key_update_num(KEY_4);

		key_update_num(KEY_7);

		key_update_num(KEY_A);
		
		GPIO_INPUT(PORT_KEY_C1, PIN_KEY_C1);
		GPIO_OUTPUT(PORT_KEY_C2, PIN_KEY_C2);
		GPIO_INPUT(PORT_KEY_C3, PIN_KEY_C3);
		current = 1;
	//KEY 2,5,8,0
	}else if(current == 1){
		key_update_num(KEY_2);

		key_update_num(KEY_5);
		
		key_update_num(KEY_8);

		key_update_num(KEY_0);
		
		GPIO_INPUT(PORT_KEY_C1, PIN_KEY_C1);
		GPIO_INPUT(PORT_KEY_C2, PIN_KEY_C2);
		GPIO_OUTPUT(PORT_KEY_C3, PIN_KEY_C3);
		current = 2;
	//Key 3,6,9,H
	}else if(current == 2){
		key_update_num(KEY_3);

		key_update_num(KEY_6);

		key_update_num(KEY_9);

		key_update_num(KEY_H);
		
		GPIO_OUTPUT(PORT_KEY_C1, PIN_KEY_C1);
		GPIO_INPUT(PORT_KEY_C2, PIN_KEY_C2);
		GPIO_INPUT(PORT_KEY_C3, PIN_KEY_C3);
		current = 0;
	}
	
}

uint8_t check_key_state(uint8_t key)
{
	return (key_pressed&(1<<key) ? 0x01 : 0x00);
}