#ifndef LCD_H
#define LCD_H 1

#include <stm32l1xx.h>
//Other files
#include "defines.h"
#include "cgpio.h"
#include "usart.h"

#define LCD_CHARS 7

//////////////////////////////////////////////
//LCD register variables ni jih v knji�njici stm32lxx.h
//////////////////////////////////////////////
#define LCDE 12 
#define LCD_FCR_DIV_0               ((uint32_t)0x00040000)     /*!< DIV[3:0] bits (Divider) */
#define LCD_FCR_DIV_1				((uint32_t)0x00080000)
#define LCD_FCR_DIV_2				((uint32_t)0x00100000)
#define LCD_FCR_DIV_3				((uint32_t)0x00200000)
#define LCD_FCR_PS_0                ((uint32_t)0x00400000)      /*!< PS[3:0] bits (Prescaler) */
#define LCD_FCR_PS_1				((uint32_t)0x00800000)
#define LCD_FCR_PS_2                ((uint32_t)0x01000000)     /*!< PS[3:0] bits (Prescaler) */
#define LCD_FCR_PS_3				((uint32_t)0x02000000)

//////////////////////////////////////////////
//LCD special defines
//////////////////////////////////////////////

#define LCD_SPECIAL_MEM 						0	
#define LCD_SPECIAL_MINUS						1	
#define LCD_SPECIAL_ERR							2	
#define LCD_SPECIAL_DOL							3	
#define LCD_SPECIAL_BC8							4
#define LCD_SPECIAL_RX							5	
#define LCD_SPECIAL_TX							6
#define LCD_SPECIAL_ENV							7
#define LCD_SPECIAL_A0							8
#define LCD_SPECIAL_A1							9
#define LCD_SPECIAL_A2							10
#define LCD_SPECIAL_ANT							12
#define LCD_SPECIAL_BB							13
#define LCD_SPECIAL_B0							14
#define LCD_SPECIAL_B1							15
#define LCD_SPECIAL_BT							16
#define LCD_SPECIAL_AL							17
#define LCD_SPECIAL_AD							18
#define LCD_SPECIAL_AR							19
#define LCD_SPECIAL_AU							20
#define LCD_SPECIAL_P2							21
#define LCD_SPECIAL_P1							22
#define LCD_SPECIAL_P0							23
#define LCD_SPECIAL_PL							24
#define LCD_SPECIAL_F4							25
#define LCD_SPECIAL_F3							26
#define LCD_SPECIAL_F2							27
#define LCD_SPECIAL_F1							28
#define LCD_SPECIAL_P3							29
#define LCD_SPECIAL_P4							30
#define LCD_SPECIAL_PR							31
#define LCD_SPECIAL_F5							32	

#define LCD_ON 									1
#define LCD_OFF									0

// LCD init
void LCD_init(void);
void LCD_off(void);

// LCD contol functions 
void LCD_put(char LCD_char, uint8_t LCD_seg);
void LCD_sign(uint8_t LCD_special, uint8_t state);
void LCD_clear(void);
void LCD96map(void);

#endif
