#ifndef SIM_MISC_H
#define SIM_MISC_H 1

#include <stm32l1xx.h>
//Other files
#include "defines.h"
#include "cgpio.h"
#include "usart.h"
#include "rtc.h"

uint8_t is_number(char c);
uint8_t is_callable_char(char c);

char add_to_number_16(uint16_t* number, char terminator);
char add_to_number_8(uint8_t* number, char terminator);

char print_number_16(uint16_t number);
char print_number_8(uint8_t number);

#endif
