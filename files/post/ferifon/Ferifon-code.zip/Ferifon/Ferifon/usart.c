#include "usart.h"

char usart_pc_on = 0;
char usart_sim_on = 0;

usart_buffer sim_buffer;

void init_usart(void)
{
	RCC->APB1ENR |= RCC_APB1ENR_USART3EN;
	RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
	 
	//U3 TX 10
	GPIO_ALTERNATE(GPIOB, 10);
	GPIO_PUSHPULL(GPIOB, 10);
	GPIO_SPEED_40M(GPIOB, 10);
	GPIO_FUNCTION(GPIOB, 10, 0x07);
	
	//U3 RX 11
	GPIO_ALTERNATE(GPIOB, 11);
	GPIO_PUSHPULL(GPIOB, 11);
	GPIO_SPEED_40M(GPIOB, 11);
	GPIO_FUNCTION(GPIOB, 11, 0x07);
	
	//U3 RTS 13
	GPIO_ALTERNATE(GPIOB, 13);
	GPIO_PUSHPULL(GPIOB, 13);
	GPIO_SPEED_40M(GPIOB, 13);
	GPIO_FUNCTION(GPIOB, 13, 0x07);
	
	//U3 CTS 14
	GPIO_ALTERNATE(GPIOB, 14);
	GPIO_PUSHPULL(GPIOB, 14);
	GPIO_SPEED_40M(GPIOB, 14);
	GPIO_FUNCTION(GPIOB, 14, 0x07);
	
	//U1 TX 6
	GPIO_ALTERNATE(GPIOB, 6);
	GPIO_PUSHPULL(GPIOB, 6);
	GPIO_SPEED_40M(GPIOB, 6);
	GPIO_FUNCTION(GPIOB, 6, 0x07);
	
	//UART1 - PC
	USART1->CR1 |= (USART_CR1_TE); //Enable transmit
	//CR2 Allready OK
	//CR3 Allready OK
	USART1->BRR = 73; //57.6k
	
	USART1->CR1 |= USART_CR1_UE;
	usart_pc_on = 1;
	
	//USART3 - SIM900
	USART3->CR1 |= (USART_CR1_RE | USART_CR1_TE); //Enable recieve and transmit
	//CR2 OK
	//CR3 OK//USART3->CR3 |= (USART_CR3_CTSE | USART_CR3_RTSE); //Enable Flow control
	USART3->BRR =73; //57.6k

	//USART3 Interrupt
	NVIC->IP[USART3_IRQn] = 0x0; //Priority 4
	// >> 0x05 take top 3 bits = 32 bits per register, &0x1f - 32 bit mask
    NVIC->ISER[USART3_IRQn >> 0x05] = 0x01 << (USART3_IRQn & 0x1F); //Enable interrupt - can assing due to it being positive edge triggered
	USART3->CR1 |= USART_CR1_RXNEIE; //Enable RX interrupt
	
	//sim_buffere init
	sim_buffer.start = 0x0000;
	sim_buffer.end = 0x0000;
	//sim_buffer.fill = 0x0000;
	
	USART3->CR1 |= USART_CR1_UE;
	usart_sim_on = 1;
	
}

void start_usart_pc(void)
{
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	//USART_Cmd(USART1, ENABLE);
	RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
	USART1->CR1 |= USART_CR1_UE;

	usart_pc_on = 1;
}
void stop_usart_pc(void)
{
	//USART_Cmd(USART1, DISABLE);
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE);
	USART1->CR1 &= ~USART_CR1_UE;
	RCC->APB2ENR &= ~RCC_APB2ENR_USART1EN;
	
	usart_pc_on = 0;
}

void pc_putchar(char c)
{
	assert_param(usart_pc_on);
	//while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
	while(!(USART1->SR & USART_SR_TXE));
	USART1->DR = (c & 0xff);
}

void pc_putint(uint32_t num)
{
	char s[10];
	uint8_t i = 0;
	while(num){
		s[i] = (num%10) + 0x30;
		num /= 10;
		i++;
	}
	for(; i; i--){
		pc_putchar(s[i-1]);
	}
}

void pc_putstring(char* s)
{
	while(*s != '\0'){
		pc_putchar(*(s++));
	}
}

void start_usart_sim(void)
{
	//RCC->APB1ENR |= RCC_APB1ENR_USART3EN;
	USART3->CR1 |= USART_CR1_UE;
	
	usart_sim_on = 1;
	NVIC->ISER[USART3_IRQn >> 0x05] = 0x01 << (USART3_IRQn & 0x1F); //Enable interrupt - can assing due to it being positive edge triggered
}
void stop_usart_sim(void)
{
	NVIC->ICER[USART3_IRQn >> 0x05] = 0x01 << (USART3_IRQn & 0x1F); //Disable interrupt - can assing due to it being positive edge triggered
	USART3->CR1 &= ~USART_CR1_UE;
	//RCC->APB1ENR &= ~RCC_APB1ENR_USART3EN;
	
	usart_sim_on = 0;
}

void usart_sim_baud_rate_override(uint16_t val, uint8_t flow)
{
	USART3->CR1 &= ~USART_CR1_UE;
	USART3->BRR = val;
	USART3->CR1 |= USART_CR1_UE;
	if( flow ){
		USART3->CR3 |= (USART_CR3_CTSE | USART_CR3_RTSE); //Enable Flow control
	}else{
		USART3->CR3 &= ~(USART_CR3_CTSE | USART_CR3_RTSE); //Disable Flow control
	}
}

//This function must not be called when the buffer is empty, it is NOT blocking
char sim_getchar(void)
{
	char temp;	//Edge case filled
	assert_param(usart_sim_on);
	#ifdef DOUBLE_CHECK
	assert_param(sim_buffer.start != sim_buffer.end);
	#endif
	
	temp = sim_buffer.buffer[sim_buffer.start++]; //return current char and set position to the next one
	if (((BUFFER_SIZE + sim_buffer.end) - sim_buffer.start)%BUFFER_SIZE >= BUFFER_SIZE - 1){ //In case ISR went trough and couldn't write next char to the buffer
		sim_buffer.buffer[sim_buffer.end++] = USART3->DR;
		
		if(sim_buffer.end >= BUFFER_SIZE){
			sim_buffer.end = sim_buffer.end - BUFFER_SIZE;
		}
	}
	//sim_buffer.fill--;
	
	if(sim_buffer.start >= BUFFER_SIZE){
		sim_buffer.start = sim_buffer.start - BUFFER_SIZE;
	}
	
	#ifdef FOWARD_TO_PC
	pc_putchar(temp);
	#endif
	return temp;
}

char sim_filled(void)
{
	return (sim_buffer.start != sim_buffer.end);
}

//Currently send is blocking, due to the fact that more probably isn't required
void sim_putchar(char c)
{
	assert_param(usart_sim_on);
	//while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
	while(!(USART3->SR & USART_SR_TXE));
	
	#ifdef FOWARD_TO_PC
	pc_putchar(c);
	#endif
	
	USART3->DR = (c);
}

void sim_putstring(char* s)
{
	while(*s != '\0'){
		sim_putchar(*(s++));
	}
}

void sim_putstring_const(char const* const sc)
{
	char const* s;
	s = sc;
	while(*s != '\0'){
		sim_putchar(*(s++));
	}
}

void USART3_IRQHandler(void)
{
	if(USART3->SR & USART_SR_RXNE){
		//sim_buffer.fill++;
		
		if (((BUFFER_SIZE + sim_buffer.end) - sim_buffer.start)%BUFFER_SIZE < BUFFER_SIZE - 1){
			sim_buffer.buffer[sim_buffer.end++] = USART3->DR;
			if (sim_buffer.end >= BUFFER_SIZE){
				sim_buffer.end = sim_buffer.end - BUFFER_SIZE;
			}
		}
	}
}
