#ifndef USART_H
#define USART_H 1

#include <stm32l1xx.h>
//Other files
#include "defines.h"
#include "cgpio.h"

#define BUFFER_MAX BUFFER_SIZE
typedef struct{
	uint8_t timezone;
	uint8_t seconds;
	uint8_t minutes;
	uint8_t hours;
	uint8_t days;
	uint8_t months;
	uint8_t years;
} time;

extern time current_time;

#endif