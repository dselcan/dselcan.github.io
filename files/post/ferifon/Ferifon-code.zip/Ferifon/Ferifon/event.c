
#include "event.h"

uint32_t event_register[EVENT_REGISTERS] = {0};


uint8_t check_event(uint8_t event)
{
	uint8_t reg;
	uint8_t bit;
	reg = event/EVENT_REGISTER_WIDTH;
	bit = event%EVENT_REGISTER_WIDTH;
	return event_register[reg]&(1<<bit) ? event : 0;
}

uint8_t check_event_range(uint8_t min, uint8_t max) //min inclusive, max exclusive
{
	uint8_t i;
	uint8_t reg;
	uint8_t bit;
	for(i = min; i < max; i++){
		reg = i/EVENT_REGISTER_WIDTH;
		bit = i%EVENT_REGISTER_WIDTH;
		if(event_register[reg]&(1<<bit)){
			return i;
		}
	}
	return 0x00;
}

uint8_t check_event_all()
{
	uint8_t i;
	for(i = 0; i < EVENT_REGISTERS; i++){
		if(event_register[i]){
			return 0x01;
		}
	}
	return 0x00;
}

void set_event(uint8_t event)
{
	uint8_t reg;
	uint8_t bit;
	reg = event/EVENT_REGISTER_WIDTH;
	bit = event%EVENT_REGISTER_WIDTH;
	event_register[reg] |= (1<<bit);
}

void clear_event(uint8_t event)
{
	uint8_t reg;
	uint8_t bit;
	reg = event/EVENT_REGISTER_WIDTH;
	bit = event%EVENT_REGISTER_WIDTH;
	event_register[reg] &= ~(1<<bit);
}

void clear_event_range(uint8_t min, uint8_t max)
{
	uint8_t i;
	uint8_t reg;
	uint8_t bit;
	for(i = min; i < max; i++){
		reg = i/EVENT_REGISTER_WIDTH;
		bit = i%EVENT_REGISTER_WIDTH;
		event_register[reg] &= ~(1<<bit);
	}
}

void clear_event_all()
{
	uint8_t i;
	for(i = 0; i < EVENT_REGISTERS; i++){
		event_register[i] = 0;
	}
}

void clear_event_user()
{
	clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
	clear_event(EVENT_KEY_OK);
	clear_event(EVENT_KEY_BACK);
}