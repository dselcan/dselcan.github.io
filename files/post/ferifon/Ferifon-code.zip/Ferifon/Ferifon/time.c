#include "time.h"

time current_time;