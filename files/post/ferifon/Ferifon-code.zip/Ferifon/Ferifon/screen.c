
#include "screen.h"

char current_message[MAX_MESSAGE_SIZE];
uint8_t current_dots[MAX_MESSAGE_SIZE];

uint8_t current_location = 0;
uint8_t current_size = 0;
uint8_t current_direction = MESSAGE_FORWARD;
uint8_t update_delay = 0;

void display_message()
{
	uint8_t i;
	uint8_t location = current_location;
	for(i = 0; i < SCREEN_SIZE; i++){ //Goes from front to back
		if(i < current_size){
			LCD_put(current_message[i+location], SCREEN_SIZE-i-1);
			if(current_dots[i+location]){
				LCD_put('.', SCREEN_SIZE-i-1);
			}
		}else{
			LCD_put(' ', SCREEN_SIZE-i-1);
		}
	}
	
	//Display less if needed.
}

void message_update()
{
	if(update_delay > 0){
		update_delay--;
	}else{
		if(current_size > SCREEN_SIZE ){
			if(current_direction == MESSAGE_FORWARD){
				if(current_location < (current_size - SCREEN_SIZE)){
					current_location++;
				}
				update_delay = MESSAGE_UPDATE_DELAY;
				if(current_location >= (current_size - SCREEN_SIZE)){
					current_direction = MESSAGE_BACKWARD;
					update_delay = MESSAGE_TURN_DELAY;
				}
			}else{
				if(current_location > 0){
					current_location--;
				}
				update_delay = MESSAGE_UPDATE_DELAY;
				if(current_location <= 0){
					current_direction = MESSAGE_FORWARD;
					update_delay = MESSAGE_TURN_DELAY;
				}
			}
		}else{
			current_location = 0;
			current_direction = MESSAGE_FORWARD;
			update_delay = 0;
		}
	}
}

void message_seek(uint8_t location)
{
	message_seek_dir(location, MESSAGE_FORWARD);
}

void message_seek_dir(uint8_t location, uint8_t direction)
{
	if(current_size < SCREEN_SIZE){
		location = 0;
	}else if(location > current_size - SCREEN_SIZE){
		location = current_size - SCREEN_SIZE;
	}
	current_location = location;
	current_direction = direction;
	update_delay = MESSAGE_TURN_DELAY;
}

void message_seek_ammount(uint8_t ammount, uint8_t direction){
	if(direction == MESSAGE_FORWARD){
		message_seek_dir(current_location + ammount, direction);
	}else{
		if(current_location > ammount){
			message_seek_dir(current_location - ammount, direction);
		}else{
			message_seek_dir(0, direction);
		}
	}
}

void set_message(char const* message, uint8_t size)
{
	current_size = size;
	uint8_t i;
	for(i = 0; i < size; i++){
		current_message[i] = message[i];
		current_dots[i] = 0x00;
	}
	message_seek(MESSAGE_START);
}

void set_message_dots(char const* message, uint8_t* dots, uint8_t size)
{
	uint8_t i;
	current_size = size;
	for(i = 0; i < size; i++){
		current_message[i] = message[i];
		current_dots[i] = dots[i];
	}
	message_seek(MESSAGE_START);
}

void message_add(char const* message, uint8_t size)
{
	if(current_size + size > MAX_MESSAGE_SIZE){
		size = MAX_MESSAGE_SIZE - current_size;
	}
	uint8_t i;
	for(i = 0; i < size; i++){
		current_message[current_size + i] = message[i];
		current_dots[current_size + i] = 0x00;
	}
	current_size += size;
	message_seek(MESSAGE_END);
}

void message_remove(uint8_t size)
{
	if(size > current_size){
		size = current_size;
	}
	current_size -= size;
	message_seek(MESSAGE_END);
}

void set_message_string(char const* message)
{
	uint8_t i = 0;
	while(message[i] != '\0'){
		current_dots[i] = 0x00;
		current_message[i] = message[i];
		i++;
	}
	current_size = i;
	message_seek(MESSAGE_START);
}

void interpret_message(char const* message) //A string!
{
	uint8_t i = 0;
	uint8_t j = 0;
	while(message[i] != '\0'){
		if(message[i] == '.' || message[i] == ':'){
			current_dots[j] = 0x01;
			i++;
		}else{
			current_dots[j] = 0x00;
			current_message[j] = message[i];
			i++;
			j++;
		}
	}
	current_size = j;
	message_seek(MESSAGE_START);
}