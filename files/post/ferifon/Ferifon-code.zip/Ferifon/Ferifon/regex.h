#ifndef REGEX_H
#define REGEX_H 1

//Other files
#include "defines.h"
#include "cgpio.h"
#include "usart.h"
#include "rtc.h"

//Returns 0 if timeout
char block_until_sequence(char* s);
char block_until_sequence2(char* s1, char* s2);
char block_until_sequence3(char* s1, char* s2, char* s3);

char block_until_found(char const* const s_array[], uint8_t length);

char block_until_found_configurable(char const* const s_array[], uint8_t length, uint16_t timeout);

void empty_buffer();
//extern usart_buffer rn_buffer;


#endif