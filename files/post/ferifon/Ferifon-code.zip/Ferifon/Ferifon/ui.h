#ifndef UI_H
#define UI_H 1

#include <stm32l1xx.h>
//Other files
#include "defines.h"
#include "cgpio.h"
#include "screen.h"
#include "event.h"
#include "sim900.h"
#include "rtc.h"
#include "player.h"

#define UI_NONE				0
#define UI_INTRO 			1
#define UI_PIN 				2
#define UI_STANDBY 			3
#define UI_MENU				4
#define UI_START_CALL		5
#define UI_DURING_CALL		6
#define UI_WARNING			7
#define UI_SHUTDOWN	 		8
#define UI_LOCK				9
#define UI_SMS_MENU			10
#define UI_SMS_READ			11
#define UI_SMS_SEND			12
#define UI_CONTACTS_MENU	13
#define UI_CONTACTS_MODIFY	14
#define UI_CONTACTS_SHOW	15

extern char e_pin[MAX_PIN_SIZE];
extern char e_number[MAX_NUMBER_SIZE];
extern uint8_t e_number_num;

extern uint8_t call_details;
extern uint8_t volatile reset;

#define CALL_DETAILS_NONE 	0
#define CALL_DETAILS_RX 	1
#define CALL_DETAILS_TX 	2



uint8_t handle_critical(uint8_t ui);
uint8_t handle_ui(uint8_t ui, uint8_t new);

void display_battery(uint8_t level);
void display_signal(uint8_t level);

#endif