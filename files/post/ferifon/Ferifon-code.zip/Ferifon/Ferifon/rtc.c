
#include "rtc.h"

//RTS timer bound vars
static __IO uint16_t delay_counter;
static __IO uint16_t timeout_counter;

uint16_t misc_time;
uint8_t screen_time;

uint8_t update_flags;

uint8_t tick_timer;


void delay_ms(uint16_t delay)
{
	delay_counter = (delay/10);
	while(delay_counter > 0);
}

void set_timeout(uint16_t timeout)
{
	delay_counter = (timeout/10);
}

uint8_t timeout_occured()
{
	if(delay_counter > 0){
		return 0;
	}else{
		return 1;
	}
}

void set_event_timeout(uint16_t timeout)
{
	clear_event(EVENT_TIMEOUT);
	timeout_counter = (timeout/10);
}

void enable_tick_interrupt(void)
{
	tick_timer = 1;
	SysTick_Config(SystemCoreClock/100);
}

//Force screen update
//Don't do it if ring interrupt occured.
//Returns 1 if disable, 0 if still enabled
uint8_t disable_tick_interrupt(void)
{
	if(!(update_flags&(1<<UPDATE_RING))){
		SysTick_Config(SystemCoreClock/1);
		if(update_flags&(1<<UPDATE_RING)){
			enable_tick_interrupt();
		}
		tick_timer = 0;
		return 1;
	}
	return 0;
}

void init_rtc(void)
{
	
	RCC->APB1ENR |= RCC_APB1ENR_PWREN;
	PWR->CR |= PWR_CR_DBP; //Disable write protection
	
	RCC->CSR |= RCC_CSR_LSION; //Enable LSI
	while(!(RCC->CSR & RCC_CSR_LSIRDY)); //Wait for LSI
	
	RCC->CSR &= ~RCC_CSR_RTCSEL;
	RCC->CSR |= (RCC_CSR_RTCSEL_1 | RCC_CSR_RTCEN); //LSI as RTC clock, enable RTC
	//RCC->CSR |= RCC_CSR_RTCEN; //Enable RTC
	
	
	/*RTC->WPR = 0xCA;
	RTC->WPR = 0x53; //Disable the write protection for RTC register
	RTC->ISR &= ~RTC_ISR_RSF;
	while(!(RTC->ISR & RTC_ISR_RSF)); //Wait for synchro, I think
	
	//RTC->CR &= ~RTC_CR_WUTE; //Disable RTC wakeup
	//while(!(RTC->ISR & RTC_ISR_WUTWF));
	
	EXTI->IMR |= EXTI_IMR_MR20;
	EXTI->EMR &= ~EXTI_EMR_MR20;
	EXTI->RTSR |= EXTI_RTSR_TR20;
	EXTI->FTSR &= ~EXTI_FTSR_TR20; //Configure EXTI As rising edge Interrupt mode
	EXTI->PR |= EXTI_PR_PR20;
	
	NVIC->IP[RTC_WKUP_IRQn] = 0x4; //Priority 4
	// >> 0x05 take top 3 bits = 32 bits per register, &0x1f - 32 bit mask
    NVIC->ISER[RTC_WKUP_IRQn >> 0x05] = 0x01 << (RTC_WKUP_IRQn & 0x1F); //Enable interrupt - can assing due to it being positive edge triggered
    //NVIC->ICER[RTC_WKUP_IRQn >> 0x05] = 0x01 << (RTC_WKUP_IRQn & 0x1F); //Disable interrupt
	
	
	RTC->CR &= ~RTC_CR_WUCKSEL; //Set wakeup to CLK/16
	RTC->CR &= ~RTC_CR_WUTE; //Enable RTC wakeup
	while(!(RTC->ISR&RTC_ISR_WUTWF));
	RTC->WUTR = 24; //10 ms wakeup
	
	//Enable interrupt
	RTC->CR |= RTC_CR_WUTIE;
	RTC->CR |= RTC_CR_WUTE; //Enable RTC wakeup*/
	
	SysTick_Config(SystemCoreClock/100);
	
	update_flags = UPDATE_START_STATE;
	misc_time = 0;
	screen_time = 0;
	tick_timer = 1;
	
	//RTC->WPR = 0xFF; //Enable write protection
	//PWR->CR &= ~PWR_CR_DBP; //Disable write protection
}

void decrement_delays(void)
{
	if(delay_counter > 0){
		delay_counter--;
		
	}
	if(timeout_counter > 0){
		timeout_counter--;
		if(timeout_counter == 0){
			set_event(EVENT_TIMEOUT);
		}
	}
}

void player_tick(void)
{
	if(current_sound_repeat != 0){
		if(current_sound_pos > 0){
			if(current_sound_pos > 10){
				current_sound_pos -= 10;
			}else{
				current_sound_pos = 0;
			}
		}else{
			current_sound_frame++;
			if(current_sound_frame >= sound_sequence[current_sound].size){
				if(current_sound_repeat > 0){
					current_sound_repeat--;
				}
				current_sound_frame = 0;
			}
			current_sound_pos = sound_sequence[current_sound].duration[current_sound_frame];
			update_flags |= (1<<UPDATE_SOUND);
		}	
	}
	
	if(current_led_repeat != 0){
		if(current_led_pos > 0){
			if(current_led_pos > 10){
				current_led_pos -= 10;
			}else{
				current_led_pos = 0;
			}
		}else{
			current_led_frame++;
			if(current_led_frame >= led_sequence[current_led].size){
				if(current_led_repeat > 0){
					current_led_repeat--;
				}
				current_led_frame = 0;
			}
			current_led_pos = led_sequence[current_led].duration[current_led_frame];
			update_flags |= (1<<UPDATE_LED);
		}	
	}
	
	//ADD SAME FOR LED
}

void SysTick_Handler(void)
{
	//pc_putchar('S');
	if(tick_timer){
		update_all_keys();
		
		player_tick();
	}
	
	decrement_delays();
	
	message_update();
	
	misc_time++;
	if(misc_time > MISC_UPDATE_INTERVAL){
		misc_time = 0;
		update_flags |= (1<<UPDATE_MISC);
	}
	
	screen_time++;
	if(screen_time > SCREEN_UPDATE_INTERVAL){
		pc_putchar('s');
		screen_time = 0;
		update_flags |= (1<<UPDATE_SCREEN);
	}
}