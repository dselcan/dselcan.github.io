#ifndef SCREEN_H
#define SCREEN_H 1

#include <stm32l1xx.h>
//Other files
#include "defines.h"
#include "cgpio.h"
#include "lcd.h"

#define MAX_MESSAGE_SIZE MAX_SMS //
#define SCREEN_SIZE 7
//Can be enabled if needed
//extern char current_message[MAX_MESSAGE_SIZE]; // +1 for the \n char at the end, just in case
//extern uint8_t current_dots[MAX_MESSAGE_SIZE]; // +1 for the \n char at the end, just in case

#define MESSAGE_START 0
#define MESSAGE_END 255

#define MESSAGE_FORWARD 1
#define MESSAGE_BACKWARD 0

#define MESSAGE_UPDATE_DELAY 30
#define MESSAGE_TURN_DELAY 100

void display_message();
void message_update();
void message_seek(uint8_t location);
void message_seek_dir(uint8_t location, uint8_t direction);
void message_seek_ammount(uint8_t ammount, uint8_t direction);


void set_message(char const* message, uint8_t size);
void set_message_dots(char const* message, uint8_t* dots, uint8_t size);
void message_add(char const* message, uint8_t size);
void message_remove(uint8_t size);

void set_message_string(char const* message);
void interpret_message(char const* message); //A string!

#endif