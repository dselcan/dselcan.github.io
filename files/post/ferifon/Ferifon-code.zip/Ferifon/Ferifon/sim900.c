#include "sim900.h"

//Misc functions

uint8_t status = 0;

void reset_sim(void)
{
	GPIO_OUTPUT(PORT_SIM_RESET, PIN_SIM_RESET);
	delay_ms(10);
	GPIO_INPUT(PORT_SIM_RESET, PIN_SIM_RESET);
	delay_ms(1200);

}

sim_error status_wait(uint16_t timeout)
{
	set_timeout(timeout);
	while(1){
		if(GPIO_READ(PORT_STATUS, PIN_STATUS)){
			return SIM_NO_ERROR;
		}
		if(timeout_occured()){
			return SIM_DEVICE_ERROR;
		}
	}
}

sim_error sim_sleep(void)
{
	GPIO_SET(PORT_DTR, PIN_DTR);
	return SIM_NO_ERROR;
}

sim_error sim_stop_sleep(void)
{
	GPIO_RESET(PORT_DTR, PIN_DTR);
	return SIM_NO_ERROR;
}

sim_error sim_powerdown(void)
{
	GPIO_OUTPUT(PORT_POWERDOWN, PIN_POWERDOWN);
	return SIM_NO_ERROR;
}

sim_error sim_stop_powerdown(void)
{
	GPIO_INPUT(PORT_POWERDOWN, PIN_POWERDOWN);
	return SIM_NO_ERROR;
}

sim_error sim_at_powerdown(void)
{
char err;
	//Check uart rate
	sim_putstring("AT+CPOWD=1\r\n");
	err = block_until_sequence("NORMAL POWER DOWN");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}

	return SIM_NO_ERROR;
}


//Main functions

sim_error sim_flush_stream(void)
{
	char err;
	//Check uart rate
	sim_putstring("AT+IPR?\r\n");
	err = block_until_sequence("+IPR:");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}

	return SIM_NO_ERROR;
}

sim_error check_sim_module(void)
{
	char err;
	sim_error error;
	
	//Verify link
	sim_putstring("AT\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		//Verify link
		sim_putstring("AT\r\n");
		err = block_until_sequence("OK");
		if(err != 1){
			return SIM_TIMEOUT_ERROR;
		}
	}
	
	sim_putstring("AT+IPR?\r\n");
	err = block_until_sequence("+IPR: ");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	uint16_t baud_rate;
	baud_rate = 0;
	err = add_to_number_16(&baud_rate, 0x00);
	if(err){
		return SIM_TIMEOUT_ERROR;
	}
	
	if(baud_rate != 57600){
		error = SIM_DEVICE_ERROR;
	}else{
		error = SIM_NO_ERROR;
	}
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return error;
}

sim_error setup_sim_module(void)
{
	uint8_t err;
	
	//Disable echo
	sim_putstring("ATE0\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Set baud rate
	sim_putstring("AT+IPR=57600\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Disable handshaking
	sim_putstring("AT+IFC=0,0\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Enable DTR controlled sleep
	sim_putstring("AT+CSCLK=1\r\n"); 
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Set sound level
	sim_putstring("ATL9\r\n"); 
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Set sound level
	sim_putstring("AT+CLVL=100\r\n"); 
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Set sidetone level
	sim_putstring("AT+SIDET=0,16\r\n"); 
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Alarm sound level
	sim_putstring("AT+CRSL=3\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Alarm sound mode
	sim_putstring("AT+CALS=2\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Error to text
	sim_putstring("AT+CMEE=2\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Notify on call pickup
	sim_putstring("AT+MORING=1\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Error to text
	sim_putstring("AT+CSDT=1\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//Report termination
	sim_putstring("AT+CDRIND=1\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	//SMS text mode
	sim_putstring("AT+CMGF=1\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error save_sim_settings(void)
{
	char err;
	
	//Save settings
	sim_putstring("AT&W\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}

	return SIM_NO_ERROR;
}

sim_error setup_sim_card(char pin[MAX_PIN_SIZE], uint8_t pin_num, uint8_t puk_now)
{
	uint8_t err;
	
	sim_putstring("AT+CPIN=\"");
	uint8_t i;
	for(i = 0; i < pin_num; i++){
		sim_putchar(pin[i]);
	}
	if(puk_now){
		sim_putstring("\",\"1234");
	}
	sim_putstring("\"\r\n");
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	if(puk_now){
		err = block_until_sequence("Call Ready");
	}else{
		err = block_until_sequence("Call Ready"); //Could need double timeout - is implemented
	}
	if(err != 1){
		err = block_until_sequence("Call Ready");
		if(err != 1){
			return SIM_TIMEOUT_ERROR;
		}
	}
	
	return SIM_NO_ERROR;
}

char const* pin_status_strings[4] = {"SIM PIN", "READY", "ERROR", "SIM PUK"};

sim_error check_sim_card_status(uint8_t* sim_card_status)
{
	uint8_t err;
	*sim_card_status = SIM_CARD_STATUS_OK;
	
	sim_putstring("AT+CPIN?\r\n");
	err = block_until_found(pin_status_strings, 4);
	if(err == 0){
		*sim_card_status = SIM_CARD_STATUS_NO_CARD;
		return SIM_TIMEOUT_ERROR;
	}else if(err == 1){
		*sim_card_status = SIM_CARD_STATUS_NO_PIN;
	}else if(err == 4){ //PUK
		*sim_card_status = SIM_CARD_STATUS_PUK;
	}else if(err != 2){ //ERROR
		err = block_until_sequence2("SIM not", "SIM PIN");
		if(err == 2){
			*sim_card_status = SIM_CARD_STATUS_NO_PIN;
		}else{
			*sim_card_status = SIM_CARD_STATUS_NO_CARD;
		}
	}
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_start_call(char* number, uint8_t size)
{
	delay_ms(10);
	uint8_t err;
	//Verify link
	sim_putstring("AT\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	delay_ms(10);
	
	sim_putstring("ATD");
	uint8_t i;
	for(i = 0; i < size; i++){
		if(!is_callable_char(number[i])){
			break;
		}
		sim_putchar(number[i]);
	}
	sim_putstring(";\r\n");
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	delay_ms(100);
	
	return SIM_NO_ERROR;
}

sim_error sim_read_call(char* number, uint8_t* size)
{
	char err;
	sim_putstring("AT+CLCC\r\n");
	
	err = block_until_sequence2("+CLCC: 1,1,4,0,0,\"", "OK"); //Maybe expand this!
	if(err == 0){
		return SIM_TIMEOUT_ERROR;
	}else if(err == 1){
		uint8_t i = 0;
		char c;
		while(1){ //break when not a number
			set_timeout(READ_TIMEOUT);
			while(!sim_filled()){
				if(timeout_occured()){
					return SIM_TIMEOUT_ERROR;
				}
			}
			c = sim_getchar();
			if(!is_callable_char(c)){
				break;
			}
			number[i] = c;
			i++;
		}
		*size = i;
		
		err = block_until_sequence("OK");
		if(err != 1){
			return SIM_TIMEOUT_ERROR;
		}
	}else if(err == 2){
		return SIM_CONNECTION_ERROR;
	}else{
		return SIM_DEVICE_ERROR;
	}
	return SIM_NO_ERROR;
}

sim_error sim_accept_call(void)
{	
	sim_putstring("ATA\r\n");
	/*err = block_until_sequence2("OK", "NO CARRIER");
	if(err == 0){
		return SIM_TIMEOUT_ERROR;
	}else if(err == 2){
		return SIM_DEVICE_ERROR;
	}	*/
	
	return SIM_NO_ERROR;
}

char const* const check_string[5] = {"+CPAS: ", "MO RING", "MO CONNECTED", "NO CARRIER", "ERROR"};

sim_error sim_check_call(uint8_t* call_status, uint16_t timeout) //Don't call without first starting!;
{
	uint8_t err;
	
	sim_putstring("AT+CPAS\r\n");
	
	*call_status = 0x00; //Since we are OR-ing the flags
	while(1){ //Breaks out when timeout, ERROR or CPAS is retreived
		err = block_until_found_configurable(check_string, 5, timeout);
		if(err == 0){
			return SIM_TIMEOUT_ERROR;
		}
		if(err == 5){
			return SIM_DEVICE_ERROR;
		}
	
		if(err == 1){
			char val;
			set_timeout(REGEX_TIMEOUT);
			while(!sim_filled()){
				if(timeout_occured()){
					return SIM_TIMEOUT_ERROR;
				}
			}
			val = sim_getchar();

			*call_status &= ~SIM_CALL_MASK_V;
			if(val == '4'){
				*call_status |= SIM_CALL_CALLING;
			}else if(val == '3'){
				*call_status |= SIM_CALL_RINGING;
			}else{
				*call_status |= SIM_CALL_NO_CALL;
			}
			
			err = block_until_sequence("OK"); //To flush the stream
			if(err != 1){
				return SIM_TIMEOUT_ERROR;
			}
			
			return SIM_NO_ERROR;
		}else if(err == 2){
			*call_status |= SIM_CALL_M_RINGING;
		}else if(err == 3){
			*call_status |= SIM_CALL_M_CALLING;
		}else if(err == 4){
			*call_status |= SIM_CALL_M_NO_CALL;
		}
	}
}

sim_error sim_end_call(void)
{
	char err;
	sim_error error;
	
	uint8_t call_status;
	error = sim_check_call(&call_status, REGEX_TIMEOUT);
	if(error){
		return error;
	}
	
	if((call_status&SIM_CALL_MASK_V) != SIM_CALL_NO_CALL){
		sim_putstring("ATH\r\n");
		err = block_until_sequence("OK");
		if(err != 1){
			return SIM_TIMEOUT_ERROR;
		}
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_send_busy(void)
{
	char err;
	sim_error error;
	
	uint8_t call_status;
	error = sim_check_call(&call_status, REGEX_TIMEOUT);
	if(error){
		return error;
	}
	
	if((call_status&SIM_CALL_MASK_V) != SIM_CALL_NO_CALL){
		sim_putstring("AT+CHLD=0\r\n");
		err = block_until_sequence("OK");
		if(err != 1){
			return SIM_TIMEOUT_ERROR;
		}
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_send_sms(char* message, uint8_t length, char* number, uint8_t number_length)
{
	char err;
	uint8_t i;
	
	//SMS charset
	sim_putstring("AT+CSCS=\"GSM\"\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	sim_putstring("AT+CMGS=\"");
	for(i = 0; i < number_length; i++){
		sim_putchar(number[i]);
	}
	sim_putstring("\"\r\n");
	err = block_until_sequence(">");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	for(i = 0; i < length; i++){
		sim_putchar(message[i]);
	}
	
	sim_putchar(0x1a); //CTRL+Z
	
	err = block_until_sequence("+CMGS: ");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	return SIM_NO_ERROR;
}

char const* const sms_details_string[5] = {"REC READ", "REC UNREAD", "STO SENT", "STO UNSENT"};
sim_error sim_sms_details(uint8_t index, uint8_t* status, char* number, uint8_t* number_length)
{
	char err;
	uint8_t i;

	sim_putstring("AT+CMGR=");
	print_number_8(index+1);
	sim_putstring(",1\r\n");
	
	err = block_until_sequence2("+CMGR: \"", "OK");
	if(err == 0){
		return SIM_TIMEOUT_ERROR;
	}else if(err == 2){
		*status = SIM_NO_SMS;
		return SIM_NO_ERROR;
	}
	
	err = block_until_found(sms_details_string, 4);
	if(err == 0){
		return SIM_TIMEOUT_ERROR;
	}
	*status = err;
	
	err = block_until_sequence(",\"");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	i = 0;
	while(i < MAX_NUMBER_SIZE){
		char c;
		set_timeout(READ_TIMEOUT);
		while(!sim_filled()){
			if(timeout_occured()){
				return SIM_TIMEOUT_ERROR;
			}
		}
		c = sim_getchar();
		if(!is_callable_char(c)){
			break;
		}
		number[i++] = c;
	}
	*number_length = i;
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_read_sms(uint8_t index, char* message, uint8_t* length)
{
	char err;
	uint8_t i;

	sim_putstring("AT+CMGR=");
	print_number_8(index+1);
	sim_putstring("\r\n");
	
	err = block_until_sequence("+CMGR: \"");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	err = block_until_sequence("\n");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	i = 0;
	while(i < MAX_SMS){
		char c;
		set_timeout(READ_TIMEOUT);
		while(!sim_filled()){
			if(timeout_occured()){
				return SIM_TIMEOUT_ERROR;
			}
		}
		c = sim_getchar();
		if(c == '\r'){
			break;
		}
		message[i++] = c;
	}
	*length = i;
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_sms_ammount(uint8_t* size)
{
	char err;
	
	sim_putstring("AT+CPMS?\r\n");

	err = block_until_sequence("+CPMS: \"SM\",");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	*size = 0;
	err = add_to_number_8(size, 0x00);
	if(err){
		return SIM_TIMEOUT_ERROR;
	}
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_sms_enumerate(uint8_t* status)
{
	sim_error error;
	
	uint8_t i;
	uint8_t details;
	char number[MAX_NUMBER_SIZE];
	uint8_t number_num;
	for(i = 0; i < MAX_SMS_STORE; i++){ //Maybe use a constant
		error = sim_sms_details(i, &details, number, &number_num);
		if(error){
			return error;
		}
		if(details == SIM_SMS_UNREAD){
			*status = SIM_SMS_STATUS_ONE_UNREAD;
			return SIM_NO_ERROR;
		}
	}
	
	*status = SIM_SMS_STATUS_ALL_READ;
	return SIM_NO_ERROR;
}

sim_error sim_delete_sms(void)
{
	char err;
	
	sim_putstring("AT+CMGD=1,2\r\n");
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_add_contact(uint8_t index, char* name, uint8_t name_length, char* number, uint8_t number_length)
{
	char err;
	sim_error error;
	uint8_t i;
	
	sim_putstring("AT+CPBW=");
	if(index){
		print_number_8(index);
	}
	sim_putstring(",\"");
	for(i = 0; i < number_length; i++){
		sim_putchar(number[i]);
	}
	sim_putstring("\",,\"");
	for(i = 0; i < name_length; i++){
		sim_putchar(name[i]);
	}
	sim_putstring("\"\r\n");

	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	if(!index){
		error = sim_check_contact(MAX_CONTACTS + 1);
		if(error == SIM_DEVICE_ERROR){
			return SIM_NO_ERROR;
		}else{
			if(error){
				return error;
			}else{
				return SIM_DEVICE_ERROR;
			}
		}
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_check_contact(uint8_t index) //Will return device error if contact is not present
{
	char err;
	if(index <= 0){
		return SIM_DEVICE_ERROR;
	}
	
	sim_putstring("AT+CPBR=");
	print_number_8(index);
	sim_putstring("\r\n");

	err = block_until_sequence3("+CPBR: ", "+CME ERROR: not found", "OK");
	if(err == 0){
		return SIM_TIMEOUT_ERROR;
	}else if(err == 2 || err == 3){
		return SIM_DEVICE_ERROR;
	}
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_check_all_contacts() //Will return device error if no contact is present
{
	char err;
	
	sim_putstring("AT+CPBR=1,");
	print_number_8(MAX_CONTACTS);
	sim_putstring("\r\n");

	err = block_until_sequence3("+CPBR: ", "+CME ERROR: not found", "OK");
	if(err == 0){
		return SIM_TIMEOUT_ERROR;
	}else if(err == 2 || err == 3){
		return SIM_DEVICE_ERROR;
	}
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_delete_contact(uint8_t index)
{
	char err;
	if(index <= 0){
		return SIM_DEVICE_ERROR;
	}

	sim_putstring("AT+CPBW=");
	print_number_8(index);
	sim_putstring("\r\n");

	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_read_contact(uint8_t index, char* name, uint8_t* name_length, char* number, uint8_t* number_length)
{
	char err;
	uint8_t i;
	if(index <= 0){
		return SIM_DEVICE_ERROR;
	}
	
	sim_putstring("AT+CPBR=");
	print_number_8(index);
	sim_putstring("\r\n");

	
	err = block_until_sequence3("+CPBR: ", "+CME ERROR: not found", "OK");
	if(err == 0){
		return SIM_TIMEOUT_ERROR;
	}else if(err == 2 || err == 3){
		return SIM_DEVICE_ERROR;
	}//Else ommited, err is 1
	
	err = block_until_sequence(",\"");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	i = 0;
	while(i < MAX_NUMBER_SIZE){
		char c;
		set_timeout(READ_TIMEOUT);
		while(!sim_filled()){
			if(timeout_occured()){
				return SIM_TIMEOUT_ERROR;
			}
		}
		c = sim_getchar();
		if(c == '"'){
			break;
		}
		number[i++] = c;
	}
	*number_length = i;
	
	err = block_until_sequence(",");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	err = block_until_sequence(",\"");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	i = 0;
	while(i < MAX_CONTACT_NAME){
		char c;
		set_timeout(READ_TIMEOUT);
		while(!sim_filled()){
			if(timeout_occured()){
				return SIM_TIMEOUT_ERROR;
			}
		}
		c = sim_getchar();
		if(c == '"'){
			break;
		}
		name[i++] = c;
	}
	*name_length = i;
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_play_sound(uint16_t frequency, uint16_t duration)
{
	if(frequency > 0 && duration > 0){
		char err;
		sim_putstring("AT+SIMTONE=1,");
		err = print_number_16(frequency);
		if(err){
			return SIM_TIMEOUT_ERROR;
		}
		sim_putstring(",200,0,");
		err = print_number_16(duration);
		if(err){
			return SIM_TIMEOUT_ERROR;
		}
		sim_putstring("\r\n");
		err = block_until_sequence("OK");
		if(err != 1){
			sim_set_pwm(1, 50);
			return SIM_TIMEOUT_ERROR;
		}
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_get_battery(uint16_t* voltage)
{
	char err;
	*voltage = 0;
	
	sim_putstring("AT+CBC\r\n");
	err = block_until_sequence("+CBC: ");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	err = block_until_sequence(",");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	err = block_until_sequence(",");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	err = add_to_number_16(voltage, 0x00);
	if(err){
		return SIM_TIMEOUT_ERROR;
	}
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_get_signal(uint8_t* signal)
{
	char err;
	*signal = 0;
	
	sim_putstring("AT+CSQ\r\n");
	err = block_until_sequence("+CSQ: ");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	err = add_to_number_8(signal, 0x00);
	if(err){
		return SIM_TIMEOUT_ERROR;
	}
	
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}

sim_error sim_set_pwm(uint8_t channel, uint8_t ammount)
{
	char err;
	sim_putstring("AT+SPWM=");
	//We are forcing the channel to 2, due to the fact that channel 1 is wired incorrectly.
	err = print_number_8(2);
	if(err){
		return SIM_TIMEOUT_ERROR;
	}
	sim_putstring(",60,");
	if(ammount > 0){
		err = print_number_8(ammount);
	}else{
		err = 0;
		sim_putchar('0');
	}
	if(err){
		return SIM_TIMEOUT_ERROR;
	}
	sim_putstring("\r\n");
	err = block_until_sequence("OK");
	if(err != 1){
		return SIM_TIMEOUT_ERROR;
	}
	
	return SIM_NO_ERROR;
}