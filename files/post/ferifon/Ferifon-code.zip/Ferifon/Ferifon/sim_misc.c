
#include "sim_misc.h"

uint8_t is_number(char c){
	if(c < 0x30){
		return 0;
	}
	if(c > 0x39){
		return 0;
	}
	return 1;
}

uint8_t is_callable_char(char c){
	if(is_number(c) || c == '#' || c == '*' || c== '+'){
		return 1;
	}else{
		return 0;
	}
}

//add_to_number adds the number stream to the number, shifts the numbers in by the number of additions.
//If terminator is supplied, it waits for it specifically, else it takes any non number as a terminator.
char add_to_number_16(uint16_t* number, char terminator){
	char c;
	while(1){
		set_timeout(READ_TIMEOUT);
		while(!sim_filled()){
			if(timeout_occured()){
				return 1;
			}
		}
		c = sim_getchar();
		if(terminator){
			if(c == terminator){
				return 0;
			}else if(!is_number(c)){
				return 1;
			}
		}else{
			if(!is_number(c)){
				return 0;
			}
		}
		*number *= 10;
		*number += c - 0x30;
	}
}

//add_to_number adds the number stream to the number, shifts the numbers in by the number of additions.
//If terminator is supplied, it waits for it specifically, else it takes any non number as a terminator.
//Reads the first non-numeric character as well!
char add_to_number_8(uint8_t* number, char terminator)
{
	uint16_t temp;
	char error;
	
	temp = (uint16_t)(*number);
	error = add_to_number_16(&temp, terminator);
	
	*number = (uint8_t)(temp);
	return error;
}

char print_number_16(uint16_t number)
{
	char s[PRINT_NUMBER_MAX];
	uint16_t temp;
	uint8_t i = 0;
	while(number){
		temp = number%10;
		number /= 10;
		s[i] = temp + 0x30;
		i++;
	}
	for(; i; i--){
		sim_putchar(s[i-1]);
	}
	return 0;
}

char print_number_8(uint8_t number)
{
	return print_number_16((uint16_t)number);
}