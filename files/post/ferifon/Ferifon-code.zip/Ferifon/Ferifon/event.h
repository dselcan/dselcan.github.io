#ifndef EVENT_H
#define EVENT_H 1

#include <stm32l1xx.h>
//Other files
#include "defines.h"
#include "cgpio.h"

#define EVENT_COLD_START 		0 //Not used
#define EVENT_HOT_START 		1 //Not used

#define EVENT_CALL_START 		2	 
#define EVENT_CALL_RING_ERROR 	3
#define EVENT_CALL_RING 		4
#define EVENT_FORCE_CALL_RESET 	5 //Not used

#define EVENT_TIMEOUT 			6

#define EVENT_LOCK 				7
#define EVENT_UNLOCK 			8 //Not used


#define EVENT_KEY_OK 			18
#define EVENT_KEY_BACK 			19

#define EVENT_KEY_0 20
#define EVENT_KEY_START EVENT_KEY_0
#define EVENT_KEY_1 21
#define EVENT_KEY_2 22
#define EVENT_KEY_3 23
#define EVENT_KEY_4 24
#define EVENT_KEY_5 25
#define EVENT_KEY_6 26
#define EVENT_KEY_7 27
#define EVENT_KEY_8 28
#define EVENT_KEY_9 29
#define EVENT_KEY_NUM_END (EVENT_KEY_9 + 1)
#define EVENT_KEY_A 30
#define EVENT_KEY_H 31
#define EVENT_KEY_END (EVENT_KEY_H + 1)

#define EVENT_REGISTERS 2
#define EVENT_REGISTER_WIDTH 32
//Can be enabled if needed
//extern uint32_t event_register[EVENT_REGISTERS];


uint8_t check_event(uint8_t event);
uint8_t check_event_range(uint8_t min, uint8_t max); //min inclusive, max exclusive
uint8_t check_event_all();

void set_event(uint8_t event);

void clear_event(uint8_t event);
void clear_event_range(uint8_t min, uint8_t max);
void clear_event_all();
void clear_event_user();

#endif
