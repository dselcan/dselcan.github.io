#include "ui.h"

uint8_t ui_intro_function(uint8_t new);
uint8_t ui_pin_function(uint8_t new);
uint8_t ui_standby_function(uint8_t new);
uint8_t ui_menu_function(uint8_t new);
uint8_t ui_lock_function(uint8_t new);

uint8_t ui_start_call_function(uint8_t new);
uint8_t ui_during_call_function(uint8_t new);

uint8_t ui_sms_menu_function(uint8_t new);
uint8_t ui_sms_read_function(uint8_t new);
uint8_t ui_sms_send_function(uint8_t new);

uint8_t ui_contacts_menu_function(uint8_t new);
uint8_t ui_contacts_modify_function(uint8_t new);
uint8_t ui_contacts_show_function(uint8_t new);

uint8_t ui_shutdown_function(uint8_t new);


uint8_t call_details;

uint8_t handle_critical(uint8_t ui)
{
	if(check_event(EVENT_CALL_START)){
		clear_event(EVENT_CALL_START);
		call_details = CALL_DETAILS_TX;
		return UI_DURING_CALL;
	}else if(check_event(EVENT_CALL_RING)){
		clear_event(EVENT_CALL_RING);
		if(ui != UI_DURING_CALL){
			call_details = CALL_DETAILS_RX;
			return UI_DURING_CALL;
		}else{
			sim_error error;
			error = sim_send_busy();
			if(error){
				//No idea.
			}
		}
	}else if(check_event(EVENT_FORCE_CALL_RESET)){
		clear_event(EVENT_FORCE_CALL_RESET);
	}else if(check_event(EVENT_LOCK)){
		clear_event(EVENT_LOCK);
		if(disable_tick_interrupt()){
			sim_sleep();
			update_flags |= (1<<UPDATE_SCREEN);
			return UI_LOCK;
		}
	}
	return UI_NONE;
}

uint8_t handle_ui(uint8_t ui, uint8_t new)
{
	switch(ui){
		case UI_INTRO:
			return ui_intro_function(new);
		break;
		case UI_PIN:
			return ui_pin_function(new);
		break;
		case UI_STANDBY:
			return ui_standby_function(new);
		break;
		case UI_MENU:
			return ui_menu_function(new);
		break;
		case UI_LOCK:
			return ui_lock_function(new);
		break;
		case UI_START_CALL:
			return ui_start_call_function(new);
		break;
		case UI_DURING_CALL:
			return ui_during_call_function(new);
		break;
		case UI_SMS_MENU:
			return ui_sms_menu_function(new);
		break;
		case UI_SMS_READ:
			return ui_sms_read_function(new);
		break;
		case UI_SMS_SEND:
			return ui_sms_send_function(new);
		break;
		case UI_CONTACTS_MENU:
			return ui_contacts_menu_function(new);
		break;
		case UI_CONTACTS_MODIFY:
			return ui_contacts_modify_function(new);
		break;
		case UI_CONTACTS_SHOW:
			return ui_contacts_show_function(new);
		break;
		case UI_SHUTDOWN:
			return ui_shutdown_function(new);
		break;
	}
	return UI_NONE;
}

void display_battery(uint8_t level){
	if(level > 0){
		LCD_sign(LCD_SPECIAL_BB, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_BB, LCD_OFF);
	}
	if(level > 1){
		LCD_sign(LCD_SPECIAL_B0, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_B0, LCD_OFF);
	}
	if(level > 2){
		LCD_sign(LCD_SPECIAL_B1, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_B1, LCD_OFF);
	}
	if(level > 3){
		LCD_sign(LCD_SPECIAL_BT, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_BT, LCD_OFF);
	}
}

void display_signal(uint8_t level){
	if(level > 0){
		LCD_sign(LCD_SPECIAL_A0, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_A0, LCD_OFF);
	}
	if(level > 1){
		LCD_sign(LCD_SPECIAL_A1, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_A1, LCD_OFF);
	}
	if(level > 2){
		LCD_sign(LCD_SPECIAL_A2, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_A2, LCD_OFF);
	}
}

void display_progress(uint8_t level){
	if(level > 0){
		LCD_sign(LCD_SPECIAL_P0, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_P0, LCD_OFF);
	}
	if(level > 1){
		LCD_sign(LCD_SPECIAL_P1, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_P1, LCD_OFF);
	}
	if(level > 2){
		LCD_sign(LCD_SPECIAL_P2, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_P2, LCD_OFF);
	}
	if(level > 3){
		LCD_sign(LCD_SPECIAL_P3, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_P3, LCD_OFF);
	}
	if(level > 4){
		LCD_sign(LCD_SPECIAL_P4, LCD_ON);
	}else{
		LCD_sign(LCD_SPECIAL_P4, LCD_OFF);
	}
}

void display_progress_side(uint8_t state){
	LCD_sign(LCD_SPECIAL_PL, state);
	LCD_sign(LCD_SPECIAL_PR, state);
	if(!state){
		display_progress(0);
	}
}


//Variables that are multi-UI:

char e_pin[MAX_PIN_SIZE];
uint8_t e_pin_num;

char e_number[MAX_NUMBER_SIZE];
uint8_t e_number_num = 0;

char get_call_char(uint8_t event){
	if(event == EVENT_KEY_A){
		return 0x2a;
	}else if(event == EVENT_KEY_H){
		return 0x23;
	}else{
		return event - EVENT_KEY_START + 0x30;
	}
}

uint8_t ui_intro_function(uint8_t new)
{
	static uint8_t step;
	if(new){
		step = 0;
		interpret_message("HELLO");
		set_event_timeout(250);
		schedule_sound(SOUND_SMS, 1);
		schedule_led(LED_ON, 1);
		return UI_NONE;
	}
	if(step >= 7){
		if(check_event(EVENT_KEY_OK) || check_event(EVENT_KEY_BACK) || check_event(EVENT_TIMEOUT)){// {
			clear_event(EVENT_KEY_OK);
			clear_event(EVENT_KEY_BACK);
			clear_event(EVENT_TIMEOUT);
			
			LCD_sign(LCD_SPECIAL_PR, 0);
			LCD_sign(LCD_SPECIAL_P0, 0);
			LCD_sign(LCD_SPECIAL_P1, 0);
			LCD_sign(LCD_SPECIAL_P2, 0);
			LCD_sign(LCD_SPECIAL_P3, 0);
			LCD_sign(LCD_SPECIAL_P4, 0);
			LCD_sign(LCD_SPECIAL_PL, 0);
			
			schedule_led(LED_OFF, 1);
			
			return UI_PIN;
		}
	}else if(check_event(EVENT_TIMEOUT)){
		clear_event(EVENT_TIMEOUT);
		if(step == 0){
			LCD_sign(LCD_SPECIAL_PL, LCD_ON);
		}else if(step == 1){
			LCD_sign(LCD_SPECIAL_P0, LCD_ON);
		}else if(step == 2){
			LCD_sign(LCD_SPECIAL_P1, LCD_ON);
		}else if(step == 3){
			LCD_sign(LCD_SPECIAL_P2, LCD_ON);
		}else if(step == 4){
			LCD_sign(LCD_SPECIAL_P3, LCD_ON);
		}else if(step == 5){
			LCD_sign(LCD_SPECIAL_P4, LCD_ON);
		}else if(step == 6){
			LCD_sign(LCD_SPECIAL_PR, LCD_ON);
			clear_event_user();
			set_event_timeout(3000);
			step++;
			return UI_NONE;
		}
		step++;
		set_event_timeout(250);
	}
	
	return UI_NONE;
}

#define STATE_CHECK_CARD 0
#define STATE_NO_CARD 1

#define STATE_ENTER_PIN 2
#define STATE_PIN_ENTERING 3

#define STATE_PIN_CHECK 4
#define STATE_PIN_OK 5
#define STATE_PIN_INVALID 6

uint8_t ui_pin_function(uint8_t new)
{
	static uint8_t state;
	static uint8_t puk_now;
	sim_error error;
	if(new){
		state = STATE_CHECK_CARD;
		puk_now = 0;
	}
	if(state == STATE_CHECK_CARD){
		uint8_t sim_card_status;
		error = check_sim_card_status(&sim_card_status);
		if(error){
			//Do something with error
		}
		if(sim_card_status == SIM_CARD_STATUS_NO_PIN){
			LCD_sign(LCD_SPECIAL_ANT, LCD_OFF);
			state = STATE_ENTER_PIN;
			interpret_message("Enter PIN");
			e_pin_num = 0;
		}else if(sim_card_status == SIM_CARD_STATUS_OK){
			LCD_sign(LCD_SPECIAL_ANT, LCD_ON);
			update_flags |= (1<<UPDATE_RING);
			return UI_STANDBY;
		}else if(sim_card_status == SIM_CARD_STATUS_PUK){
			LCD_sign(LCD_SPECIAL_ANT, LCD_OFF);
			state = STATE_ENTER_PIN;
			interpret_message("PUK");
			puk_now = 1;
			e_pin_num = 0;
		}else{ //IS no card
			LCD_sign(LCD_SPECIAL_ANT, LCD_OFF);
			state = STATE_NO_CARD;
			interpret_message("No SIM");
		}
	}else if(state == STATE_NO_CARD){
		if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			state = STATE_CHECK_CARD;
		}
	}else if(state == STATE_ENTER_PIN || state == STATE_PIN_ENTERING){ //IF NEW STATE ADDED, MODIFY THE CODE HERE - LOGIC A BIT COMPLICATED
		uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_NUM_END);
		if(ev){
			if(state == STATE_ENTER_PIN){
				interpret_message("");
				state = STATE_PIN_ENTERING;
			}
			clear_event_range(EVENT_KEY_START, EVENT_KEY_NUM_END);
			if(e_pin_num < MAX_PIN_SIZE){
				e_pin[e_pin_num] = ev - EVENT_KEY_START + 0x30;
				message_add(&(e_pin[e_pin_num]), 1);
				e_pin_num++;
			}
		}else if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			if(state == STATE_ENTER_PIN){
				interpret_message("");
				state = STATE_PIN_ENTERING;
			}else{ //STATE_PIN_ENTERING
				if(e_pin_num >= MIN_PIN_SIZE){
					state = STATE_PIN_CHECK;
					interpret_message("check");
					update_flags |= (1<<UPDATE_SCREEN);
				}
			}
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			if(state == STATE_PIN_ENTERING && e_pin_num > 0){
				message_remove(1);
				e_pin_num--;
			}
		}
	}else if(state == STATE_PIN_CHECK){
		error = setup_sim_card(e_pin, e_pin_num, puk_now);
		if(puk_now){
			puk_now = 0;
			if(error){
				interpret_message("Pin error");
				state = STATE_PIN_INVALID;
			}else{
				interpret_message("1234-New PIN");
				state = STATE_PIN_OK;
			}
		}else{
			if(error){
				interpret_message("Pin error");
				state = STATE_PIN_INVALID;
			}else{
				interpret_message("Pin OK");
				state = STATE_PIN_OK;
			}
			set_event_timeout(3000);
		}
	}else if(state == STATE_PIN_OK){
		if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			state = STATE_CHECK_CARD;
		}else if(check_event(EVENT_TIMEOUT)){
			clear_event(EVENT_TIMEOUT);
			state = STATE_CHECK_CARD;
		}
	}else if(state == STATE_PIN_INVALID){
		if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			state = STATE_CHECK_CARD;
		}else if(check_event(EVENT_TIMEOUT)){
			clear_event(EVENT_TIMEOUT);
			state = STATE_CHECK_CARD;
		}
	}
	return UI_NONE;
}



uint8_t ui_standby_function(uint8_t new)
{
	if(new){
		interpret_message("FeRIFon");
	}
	if(!GPIO_READ(PORT_RING, PIN_RING)){
		set_event(EVENT_CALL_RING_ERROR);
	}
	uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
	if(ev){
		clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
		e_number[0] = get_call_char(ev);
		e_number_num = 1;
		return UI_START_CALL;
	}else if(check_event(EVENT_KEY_OK)){
		clear_event(EVENT_KEY_OK);
		return UI_MENU;
	}
	return UI_NONE;
}

#define MENU_NUM 4

#define MENU_CALL 0
#define MENU_SMS 1
#define MENU_CONTANCTS 2
#define MENU_CONFIG 3

uint8_t const menu_navigation[MENU_NUM] = {UI_CONTACTS_MENU, UI_SMS_MENU, UI_START_CALL, UI_SHUTDOWN};
char const* menu_title[MENU_NUM] = {"CONTACTS", "SMS", "CALL", "SHUTDOWN"};
uint8_t menu_special[MENU_NUM] = {LCD_SPECIAL_F1, LCD_SPECIAL_F2, LCD_SPECIAL_F3, LCD_SPECIAL_F4};

uint8_t ui_menu_function(uint8_t new)
{
	static uint8_t menu;
	if(new){
		menu = MENU_CALL;
		interpret_message(menu_title[menu]);
		LCD_sign(menu_special[menu], LCD_ON);
	}
	
	uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
	if(ev){
		clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
		LCD_sign(menu_special[menu], LCD_OFF);
		if(ev >= EVENT_KEY_1 && ev <= EVENT_KEY_3){
			if(menu <= 0){
				menu = MENU_NUM;
			}
			menu--;
		//}else if(ev == EVENT_KEY_A){
		//	set_event(EVENT_LOCK);
		}else{
			menu++;
			if(menu >= MENU_NUM){
				menu = 0;
			}
		}
		LCD_sign(menu_special[menu], LCD_ON);
		interpret_message(menu_title[menu]);
	}else if(check_event(EVENT_KEY_OK)){
		clear_event(EVENT_KEY_OK);
		return menu_navigation[menu];
	}else if(check_event(EVENT_KEY_BACK)){
		clear_event(EVENT_KEY_BACK);
		LCD_sign(menu_special[menu], LCD_OFF);
		return UI_STANDBY;
	}
	return UI_NONE;
}

#define STATE_LOCK_IDLE 1
#define STATE_LOCK_UNLOCKING 2

uint8_t ui_lock_function(uint8_t new)
{
	static uint8_t state;
	if(new){
		state = STATE_LOCK_IDLE;
		interpret_message("LOCKED");
	}
	if(state == STATE_LOCK_IDLE){
		if(tick_timer){
			clear_event(EVENT_KEY_OK); //Just in case?
			interpret_message("PRESS * TO UNLOCK");
			state = STATE_LOCK_UNLOCKING;
			set_event_timeout(LOCK_TIMEOUT);
		}
	}else{ //STATE_LOCK_UNLOCKING
		if(check_event(EVENT_KEY_A)){
			clear_event(EVENT_KEY_A);
			return UI_STANDBY;
		}else if(check_event(EVENT_TIMEOUT)){
			clear_event(EVENT_TIMEOUT);
			set_event(EVENT_LOCK);
		}
	}
	return UI_NONE;
}

#define STATE_ENTER_NUMBER 0
#define STATE_ENTERING_NUMBER 1

uint8_t ui_start_call_function(uint8_t new)
{
	static uint8_t state;
	if(new){
		if(e_number_num > 0){
			interpret_message("");
			message_add(e_number, e_number_num);
			state = STATE_ENTERING_NUMBER;
		}else{
			state = STATE_ENTER_NUMBER;
			interpret_message("Enter number");
		}
		LCD_sign(LCD_SPECIAL_F3, LCD_ON);
	}
	
	uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
	if(ev && (e_number_num < MAX_NUMBER_SIZE)){
		if(state == STATE_ENTER_NUMBER){
			interpret_message("");
			state = STATE_ENTERING_NUMBER;
		}
		clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
		e_number[e_number_num] = get_call_char(ev);
		message_add(&(e_number[e_number_num]), 1);
		e_number_num++;
	}else if(check_event(EVENT_KEY_OK)){
		clear_event(EVENT_KEY_OK);
		if(state == STATE_ENTER_NUMBER){
			interpret_message("");
			state = STATE_ENTERING_NUMBER;
		}else if(e_number_num > 0){ //STATE_PIN_ENTERING
			//CALL NOW NOW NOW!
			set_event(EVENT_CALL_START);
		}
	}else if(check_event(EVENT_KEY_BACK)){
		clear_event(EVENT_KEY_BACK);
		if(e_number_num > 0){
			message_remove(1);
			e_number_num--;
		}else{
			LCD_sign(LCD_SPECIAL_F3, LCD_OFF);
			return UI_MENU;
		}
	}
	
	return UI_NONE;
}

#define STATE_MAKE_CALL		1
#define STATE_RECEIVE_CALL	2
#define STATE_RINGING		3
#define STATE_WAITING		4 //Ringing for incoming
#define STATE_CALLING		5
#define STATE_END_CALL		6

uint8_t ui_during_call_function(uint8_t new)
{
	static uint8_t state;
	sim_error error;
	if(new){
		LCD_sign(LCD_SPECIAL_F3, LCD_ON);
		if(call_details == CALL_DETAILS_RX){
			state = STATE_RECEIVE_CALL;
			schedule_sound(SOUND_RING, -1);
			schedule_led(LED_SLOW_BLINK, -1);
			LCD_sign(LCD_SPECIAL_RX, LCD_ON);
		}else if(call_details == CALL_DETAILS_TX){
			state = STATE_MAKE_CALL;
			LCD_sign(LCD_SPECIAL_TX, LCD_ON);
		}else{
			call_details = CALL_DETAILS_NONE;
			LCD_sign(LCD_SPECIAL_F3, LCD_OFF);
			return UI_STANDBY;
		}
	}
	
	if(state == STATE_MAKE_CALL){
		error = sim_start_call(e_number, e_number_num);
		if(error){
			//Do something with error
		}
		interpret_message("RING ");
		message_add(e_number, e_number_num);
		set_event_timeout(200);
		state = STATE_RINGING;
	}else if(state == STATE_RECEIVE_CALL){
		error = sim_read_call(e_number, &e_number_num);
		if(error){
			if(error == SIM_CONNECTION_ERROR){
				LCD_sign(LCD_SPECIAL_F3, LCD_OFF);
				LCD_sign(LCD_SPECIAL_RX, LCD_OFF);
				e_number_num = 0;
				schedule_sound(SOUND_RING, 0);
				schedule_led(LED_SLOW_BLINK, 1);
				call_details = CALL_DETAILS_NONE;
				return UI_STANDBY;
			}
			//No idea if timeout
		}
		interpret_message("INC ");
		message_add(e_number, e_number_num);
		set_event_timeout(500);
		state = STATE_WAITING;
	}else if(state == STATE_RINGING || state == STATE_CALLING || state == STATE_WAITING){
		if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			if(state == STATE_RINGING || state == STATE_CALLING){
				error = sim_end_call();
				if(error){
					//I really don't know why
				}
			}else{ //STATE_WAITING
				//error = sim_send_busy();
				schedule_sound(SOUND_RING, 0);
				schedule_led(LED_SLOW_BLINK, 1);
				error = sim_end_call();
				if(error){
					//No idea.
				}
			}
			state = STATE_END_CALL;
			set_event_timeout(3000);
			LCD_sign(LCD_SPECIAL_RX, LCD_OFF);
			LCD_sign(LCD_SPECIAL_TX, LCD_OFF);
			interpret_message("HANGED UP");
		}else if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			if(state == STATE_WAITING){
				schedule_sound(SOUND_RING, 0);
				schedule_led(LED_SLOW_BLINK, 1);
				error = sim_accept_call();
				if(error){
					if(error == SIM_CONNECTION_ERROR){
						LCD_sign(LCD_SPECIAL_F3, LCD_OFF);
						LCD_sign(LCD_SPECIAL_RX, LCD_OFF);
						e_number_num = 0;
						call_details = CALL_DETAILS_NONE;
						return UI_STANDBY;
					}
				}
				interpret_message("CALL ");
				message_add(e_number, e_number_num);
				LCD_sign(LCD_SPECIAL_TX, LCD_ON);
				state = STATE_CALLING;
			}
		}else if(check_event(EVENT_TIMEOUT)){
			clear_event(EVENT_TIMEOUT);
			
			uint8_t call_status;
			error = sim_check_call(&call_status, READ_TIMEOUT);
			if(error){
				//Handle error
			}
			if((call_status&SIM_CALL_MASK_V) == SIM_CALL_NO_CALL){
				schedule_sound(SOUND_RING, 0);
				schedule_led(LED_SLOW_BLINK, 1);
				state = STATE_END_CALL;
				set_event_timeout(3000);
				LCD_sign(LCD_SPECIAL_RX, LCD_OFF);
				LCD_sign(LCD_SPECIAL_TX, LCD_OFF);
				interpret_message("CALL INTERRUPTED");
				return UI_NONE;
			}else if(call_status&SIM_CALL_M_CALLING){
				if(state == STATE_RINGING){
					LCD_sign(LCD_SPECIAL_RX, LCD_ON);
					state = STATE_CALLING;
					interpret_message("CALL ");
					message_add(e_number, e_number_num);
				}
			}
			set_event_timeout(500);
		}
	}else if(state == STATE_END_CALL){
		if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			LCD_sign(LCD_SPECIAL_F3, LCD_OFF);
			e_number_num = 0;
			call_details = CALL_DETAILS_NONE;
			return UI_STANDBY;
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			LCD_sign(LCD_SPECIAL_F3, LCD_OFF);
			e_number_num = 0;
			call_details = CALL_DETAILS_NONE;
			return UI_STANDBY;
		}else if(check_event(EVENT_TIMEOUT)){
			clear_event(EVENT_TIMEOUT);
			LCD_sign(LCD_SPECIAL_F3, LCD_OFF);
			e_number_num = 0;
			call_details = CALL_DETAILS_NONE;
			return UI_STANDBY;
		}
	}
	
	return UI_NONE;	
}

char const* sms_menu_title[3] = {"SEND SMS", "READ SMS", "DELETE READ SMS"};

uint8_t ui_sms_menu_function(uint8_t new)
{
	static uint8_t index;
	if(new){
		index = 0;
		interpret_message("SEND SMS");
		LCD_sign(LCD_SPECIAL_F2, LCD_ON);
	}
	uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
	if(ev){
		clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
		if(ev >= EVENT_KEY_1 && ev <= EVENT_KEY_3){
			if(index <= 0){
				index = 3;
			}
			index--;
		}else{
			index++;
			if(index >= 3){
				index = 0;
			}
		}
		interpret_message(sms_menu_title[index]);
	}else if(check_event(EVENT_KEY_OK)){
		clear_event(EVENT_KEY_OK);
		if(index == 0){
			return UI_SMS_SEND;
		}else if(index == 1){
			return UI_SMS_READ;
		}else{ //index == 2
			sim_error error;
			error = sim_delete_sms();
			if(error){
				interpret_message("Could not delete SMS");
			}else{
				interpret_message("SMS DELETED");
			}
		}
	}else if(check_event(EVENT_KEY_BACK)){
		clear_event(EVENT_KEY_BACK);
		LCD_sign(LCD_SPECIAL_F2, LCD_OFF);
		return UI_MENU;
	}
	return UI_NONE;
}

#define STATE_SMS_READ 1
#define STATE_SMS_SELECT 2
#define STATE_SMS_NONE_HERE 3

#define SMS_DIR_U 1
#define SMS_DIR_D 2
#define SMS_DIR_N 0

//Returns index, 255 if error.
uint8_t next_read_sms(uint8_t index, uint8_t direction)
{
	char number[MAX_NUMBER_SIZE];
	uint8_t number_length;
	uint8_t status; 
	while(1){
		if(direction == SMS_DIR_D){
			index++;
			if(index >= MAX_SMS_STORE){
				index = 0;
			}
		}else if(direction == SMS_DIR_U){
			if(index <= 0){
				index = MAX_SMS_STORE;
			}
			index--;
		}else if(direction == SMS_DIR_N){
			direction = SMS_DIR_D;
		}
		sim_error error = sim_sms_details(index, &status, number, &number_length);
		if(error){
			return 0xff;
		}
		if(status != SIM_NO_SMS){
			if(status == SIM_SMS_UNREAD){
				LCD_sign(LCD_SPECIAL_ENV, LCD_ON);
			}else{
				LCD_sign(LCD_SPECIAL_ENV, LCD_OFF);
			}
			interpret_message("From ");
			message_add(number, number_length);
			message_seek(MESSAGE_START);
			//display_progress_side(LCD_ON);
			return index;
		}
	}
}

uint8_t ui_sms_read_function(uint8_t new)
{
	static uint8_t state;
	static uint8_t index;
	static uint8_t max;
	sim_error error;

	if(new){
		state = STATE_SMS_SELECT;
		index = 0;
		//display_progress_side(LCD_ON);
		error = sim_sms_ammount(&max);
		if(error){
			//Dunno
		}
		if(max == 0){
			interpret_message("NO SMS");
			state = STATE_SMS_NONE_HERE;
		}else{
			index = next_read_sms(index, SMS_DIR_N);
			if(index == 0xff){
				//error
			}
		}
	}
	if(state == STATE_SMS_SELECT){
		uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
		if(ev){
			clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
			if(ev >= EVENT_KEY_1 && ev <= EVENT_KEY_3){
				index = next_read_sms(index, SMS_DIR_U);
			}else{
				index = next_read_sms(index, SMS_DIR_D);
			}
			if(index == 0xff){
				//error
			}
		}else if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			char message[MAX_SMS];
			uint8_t sms_length;
			error = sim_read_sms(index, message, &sms_length);
			if(error){
				//Dunno
			}
			set_message(message, sms_length);
			state = STATE_SMS_READ;
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			//display_progress_side(LCD_OFF);
			LCD_sign(LCD_SPECIAL_F2, LCD_OFF);
			//check if any sms still not read
			uint8_t sms_status;
			error = sim_sms_enumerate(&sms_status);
			if(!error){
				if(sms_status == SIM_SMS_STATUS_ONE_UNREAD){
					LCD_sign(LCD_SPECIAL_ENV, LCD_ON);
				}else{
					LCD_sign(LCD_SPECIAL_ENV, LCD_OFF);
				}
			}else{
				//Same as above
			}	
			return UI_SMS_MENU;
		}
	}else if(state == STATE_SMS_READ){
		uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
		if(ev){
			clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
			if(ev == EVENT_KEY_1 || ev == EVENT_KEY_4 || ev == EVENT_KEY_7 || ev == EVENT_KEY_A){
				message_seek_ammount(SMS_SEEK_AMMOUNT, MESSAGE_BACKWARD);
			}else{
				message_seek_ammount(SMS_SEEK_AMMOUNT, MESSAGE_FORWARD);
			}
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			index = next_read_sms(index, SMS_DIR_N);
			if(index == 0xff){
				//error
			}
			state = STATE_SMS_SELECT;
		}
	}else if(state == STATE_SMS_NONE_HERE){
		if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			//display_progress_side(LCD_OFF);
			return UI_SMS_MENU;
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			//cdisplay_progress_side(LCD_OFF);
			return UI_SMS_MENU;
		}
	}
	return UI_NONE;
}

#define STATE_SMS_NUMBER 1
#define STATE_SMS_NUMBERING 2
#define STATE_SMS_WRITE 3
#define STATE_SMS_WRITING 4
#define STATE_SMS_SENT 5

char e_sms[MAX_SMS];
uint8_t e_sms_num = 0;

char e_sms_number[MAX_NUMBER_SIZE];
uint8_t e_sms_number_num;

					//A bit memory inefficient, don't know what's the nicer way to do this
char const sms_key_map[12][5] = {{' ', '0'},
								{'.', '?', '1'},
								{'a', 'b', 'c', '2'},
								{'d', 'e', 'f', '3'},
								{'g', 'h', 'i', '4'},
								{'j', 'k', 'l', '5'},
								{'m', 'n', 'o', '6'},
								{'p', 'q', 'r', 's', '7'},
								{'t', 'u', 'v', '8'},
								{'w', 'x', 'y', 'z', '9'},
								{'+', '-', '/', '*'},
								{'(', ')', '#'}};
uint8_t sms_key_map_size[12] = {2,3,4,4,4,4,4,5,4,5,4,3};

char handle_sms_char(uint8_t event, uint8_t* overwrite)
{
	static uint8_t previous_key = 0;
	static uint8_t index = 0;
	uint8_t key = event - EVENT_KEY_START;
	*overwrite = 0;
	if(key == previous_key){
		if(check_event(EVENT_TIMEOUT)){
			clear_event(EVENT_TIMEOUT);
			index = 0;
		}else{
			*overwrite = 1;
			index++;
			if(index >= sms_key_map_size[key]){
				index = 0;
			}
		}
	}else{
		clear_event(EVENT_TIMEOUT);
		previous_key = key;
		index = 0;
	}
	set_event_timeout(SMS_SAME_CHAR_TIMEOUT);
	return sms_key_map[key][index];
}

char get_sms_char(uint8_t event)
{
	uint8_t overwrite;
	return handle_sms_char(event, &overwrite);
}

uint8_t ui_sms_send_function(uint8_t new)
{
	static uint8_t state = STATE_SMS_WRITE;
	if(new){
		set_event(EVENT_TIMEOUT); //Used to enter new characters
		if(e_sms_num > 0){
			interpret_message("");
			message_add(e_sms, e_sms_num);
			state = STATE_SMS_WRITING;
		}else{
			interpret_message("Enter SMS");
			state = STATE_SMS_WRITE;
		}
	}
	if(state == STATE_SMS_WRITE || state == STATE_SMS_WRITING){
		uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
		if(ev && (e_sms_num < MAX_SMS)){
			clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
			if(state == STATE_SMS_WRITE){
				interpret_message("");
				state = STATE_SMS_WRITING;
			}
			char c;
			uint8_t overwrite;
			c = handle_sms_char(ev, &overwrite);
			if(overwrite && e_sms_num > 0){
				e_sms_num--;
				message_remove(1);
			}
			e_sms[e_sms_num] = c;
			message_add(&(e_sms[e_sms_num]), 1);
			e_sms_num++;
		}else if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			if(state == STATE_SMS_WRITE){
				interpret_message("");
				state = STATE_SMS_WRITING;
			}else if(e_sms_num > 0){ //STATE_PIN_ENTERING
				interpret_message("Enter number");
				state = STATE_SMS_NUMBER;
			}
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			set_event(EVENT_TIMEOUT);
			if(e_sms_num > 0){
				message_remove(1);
				e_sms_num--;
			}else{
				LCD_sign(LCD_SPECIAL_F2, LCD_OFF);
				return UI_SMS_MENU;
			}
		}
	}else if(state == STATE_SMS_NUMBER || state == STATE_SMS_NUMBERING){
		uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
		if(ev && (e_sms_number_num < MAX_NUMBER_SIZE)){
			if(state == STATE_SMS_NUMBER){
				interpret_message("");
				state = STATE_SMS_NUMBERING;
			}
			clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
			e_sms_number[e_sms_number_num] = get_call_char(ev);
			message_add(&(e_sms_number[e_sms_number_num]), 1);
			e_sms_number_num++;
		}else if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			if(state == STATE_SMS_NUMBER){
				interpret_message("");
				state = STATE_SMS_NUMBERING;
			}else if(e_sms_number_num > 0){ //STATE_SMS_NUMBERING
				sim_error error = sim_send_sms(e_sms, e_sms_num, e_sms_number, e_sms_number_num);
				if(error){
					interpret_message("SEND FAILED");
					state = STATE_SMS_SENT;
				}else{
					interpret_message("SMS SENT");
					e_sms_num = 0;
					state = STATE_SMS_SENT;
				}
			}
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			if(e_sms_number_num > 0){
				message_remove(1);
				e_sms_number_num--;
			}else{
				interpret_message("");
				message_add(e_sms, e_sms_num);
				state = STATE_SMS_WRITING;
			}
		}
	}else if(state == STATE_SMS_SENT){
		if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			LCD_sign(LCD_SPECIAL_F2, LCD_OFF);
			return UI_STANDBY;
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			LCD_sign(LCD_SPECIAL_F2, LCD_OFF);
			return UI_STANDBY;
		}
	}
	return UI_NONE;
}

char const* contacts_menu_title[2] = {"LIST CONTACTS", "ADD CONTACTS"};

uint8_t e_index = 0;

uint8_t ui_contacts_menu_function(uint8_t new)
{
	static uint8_t index;
	if(new){
		index = 0;
		interpret_message(contacts_menu_title[0]);
		LCD_sign(LCD_SPECIAL_F1, LCD_ON);
	}
	uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
	if(ev){
		clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
		if(ev >= EVENT_KEY_1 && ev <= EVENT_KEY_3){
			if(index <= 0){
				index = 2;
			}
			index--;
		}else{
			index++;
			if(index >= 2){
				index = 0;
			}
		}
		interpret_message(contacts_menu_title[index]);
	}else if(check_event(EVENT_KEY_OK)){
		clear_event(EVENT_KEY_OK);
		if(index == 0){
			return UI_CONTACTS_SHOW;
		}else{ //index == 1
			e_index = 0;
			return UI_CONTACTS_MODIFY;
		}
	}else if(check_event(EVENT_KEY_BACK)){
		clear_event(EVENT_KEY_BACK);
		LCD_sign(LCD_SPECIAL_F1, LCD_OFF);
		return UI_MENU;
	}
	return UI_NONE;
}

#define STATE_CONTACT_NUMBER 1
#define STATE_CONTACT_NUMBERING 2
#define STATE_CONTACT_WRITE 3
#define STATE_CONTACT_WRITING 4
#define STATE_CONTACT_SAVED 5

char e_contact[MAX_CONTACT_NAME];
uint8_t e_contact_num = 0;

char e_contact_number[MAX_NUMBER_SIZE];
uint8_t e_contact_number_num = 0;

uint8_t ui_contacts_modify_function(uint8_t new)
{
	static uint8_t state;
	if(new){
		set_event(EVENT_TIMEOUT); //Used to enter new characters
		if(e_index && (e_contact_number_num > 0)){
			if(e_contact_num > 0){
				interpret_message("");
				message_add(e_contact, e_contact_num);
				state = STATE_CONTACT_WRITING;
			}else{
				interpret_message("");
				message_add(e_contact_number, e_contact_number_num);
				state = STATE_CONTACT_NUMBERING;
			}
		}else{
			e_contact_number_num = 0;
			e_contact_num = 0;
			interpret_message("Enter contact number");
			state = STATE_CONTACT_NUMBER;
		}
	}
	if(state == STATE_CONTACT_NUMBER || state == STATE_CONTACT_NUMBERING){
		uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
		if(ev && (e_contact_number_num < MAX_NUMBER_SIZE)){
			if(state == STATE_CONTACT_NUMBER){
				interpret_message("");
				state = STATE_CONTACT_NUMBERING;
			}
			clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
			e_contact_number[e_contact_number_num] = get_call_char(ev);
			message_add(&(e_contact_number[e_contact_number_num]), 1);
			e_contact_number_num++;
		}else if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			if(state == STATE_CONTACT_NUMBER){
				interpret_message("");
				state = STATE_CONTACT_NUMBERING;
			}else if(e_contact_number_num > 0){ //STATE_CONTACT_NUMBERING
				interpret_message("Enter contact name");
				state = STATE_CONTACT_WRITE;
			}
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			if(e_contact_number_num > 0){
				message_remove(1);
				e_contact_number_num--;
			}else{
				LCD_sign(LCD_SPECIAL_F1, LCD_OFF);
				return UI_CONTACTS_MENU;
			}
		}
	}else if(state == STATE_CONTACT_WRITE || state == STATE_CONTACT_WRITING){
		uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
		if(ev && (e_sms_num < MAX_SMS)){
			clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
			if(state == STATE_CONTACT_WRITE){
				interpret_message("");
				state = STATE_CONTACT_WRITING;
			}
			char c;
			uint8_t overwrite;
			c = handle_sms_char(ev, &overwrite);
			if(overwrite && e_contact_num > 0){
				e_contact_num--;
				message_remove(1);
			}
			e_contact[e_contact_num] = c;
			message_add(&(e_contact[e_contact_num]), 1);
			e_contact_num++;
		}else if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			if(state == STATE_CONTACT_WRITE){
				interpret_message("");
				state = STATE_CONTACT_WRITING;
			}else if(e_contact_num > 0){ //STATE_PIN_ENTERING
				sim_error error = sim_add_contact(e_index, e_contact, e_contact_num, e_contact_number, e_contact_number_num);
				if(error){
					interpret_message("NOT ENOUGH SPACE");
					e_contact_num = 0;
					e_contact_number_num = 0;
					state = STATE_CONTACT_SAVED;
				}else{
					interpret_message("CONTACT SAVED");
					e_contact_num = 0;
					e_contact_number_num = 0;
					state = STATE_CONTACT_SAVED;
				}
			}
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			set_event(EVENT_TIMEOUT);
			if(e_contact_num > 0){
				message_remove(1);
				e_contact_num--;
			}else{
				interpret_message("");
				message_add(e_contact_number, e_contact_number_num);
				state = STATE_CONTACT_NUMBERING;
			}
		}
	}else if(state == STATE_CONTACT_SAVED){
		if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			LCD_sign(LCD_SPECIAL_F1, LCD_OFF);
			return UI_CONTACTS_MENU;
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			LCD_sign(LCD_SPECIAL_F1, LCD_OFF);
			return UI_CONTACTS_MENU;
		}
	}
	return UI_NONE;
}


#define STATE_CONTACTS_LIST 1
#define STATE_CONTACTS_ACTION 2
#define STATE_CONTACTS_EMPTY 3

#define CONTACTS_DIR_U 1
#define CONTACTS_DIR_D 2
#define CONTACTS_DIR_N 0

char const* contacts_action_names[3] = {"CALL", "EDIT", "DELETE"};

void next_show_contact(uint8_t direction)
{
	sim_error error;
	
	while(1){
		if(direction == CONTACTS_DIR_D){
			e_index++;
			if(e_index > MAX_CONTACTS){
				e_index = 1;
			}
		}else if(direction == CONTACTS_DIR_U){
			e_index--;
			if(e_index <= 0){
				e_index = MAX_CONTACTS;
			}
		}else if(direction == CONTACTS_DIR_N){
			direction = CONTACTS_DIR_D;
		}
		error = sim_check_contact(e_index);
		if(!error){
			error = sim_read_contact(e_index, e_contact, &e_contact_num, e_contact_number, &e_contact_number_num);
			
			interpret_message("");
			message_add(e_contact, e_contact_num);
			return;
		}
	}
}

uint8_t ui_contacts_show_function(uint8_t new)
{
	static uint8_t state;
	static uint8_t menu_index;
	sim_error error;
	//
	if(new){
		state = STATE_CONTACTS_LIST;
		error = sim_check_all_contacts();
		if(error){
			interpret_message("NO CONTACTS");
			state = STATE_CONTACTS_EMPTY;
		}else{
			next_show_contact(CONTACTS_DIR_N); //Think of using timeout to keep it from freezing, just in case?
		}
	}
	if(state == STATE_CONTACTS_LIST){
		uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
		if(ev){
			clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
			if(ev >= EVENT_KEY_1 && ev <= EVENT_KEY_3){
				next_show_contact(CONTACTS_DIR_U);
			}else{
				next_show_contact(CONTACTS_DIR_D);
			}
		}else if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			menu_index = 0;
			interpret_message(contacts_action_names[menu_index]);
			state = STATE_CONTACTS_ACTION;
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			//display_progress_side(LCD_OFF);
			LCD_sign(LCD_SPECIAL_F1, LCD_OFF);
			return UI_CONTACTS_MENU;
		}
	}else if(state == STATE_CONTACTS_ACTION){
		uint8_t ev = check_event_range(EVENT_KEY_START, EVENT_KEY_END);
		if(ev){
			clear_event_range(EVENT_KEY_START, EVENT_KEY_END);
			if(ev >= EVENT_KEY_1 && ev <= EVENT_KEY_3){
				if(menu_index <= 0){
					menu_index = 3;
				}
				menu_index--;
			}else{
				menu_index++;
				if(menu_index >= 3){
					menu_index = 0;
				}
			}
			interpret_message(contacts_action_names[menu_index]);
		}else if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			if(menu_index == 0){ //Call
				uint8_t i;
				for(i = 0; i < e_contact_number_num; i++){
					e_number[i] = e_contact_number[i];
				}
				e_number_num = e_contact_number_num;
				LCD_sign(LCD_SPECIAL_F1, LCD_OFF);
				set_event(EVENT_CALL_START);
				return UI_NONE;
			}else if(menu_index == 1){ //Edit
				return UI_CONTACTS_MODIFY;
			}else{ //menu_index == 2 //Delete
				error = sim_delete_contact(e_index);
				if(error){
					//Not really sure
				}
				return UI_CONTACTS_SHOW;
			}
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			next_show_contact(CONTACTS_DIR_N);
			state = STATE_CONTACTS_LIST;
		}
	}else if(state == STATE_CONTACTS_EMPTY){
		if(check_event(EVENT_KEY_OK)){
			clear_event(EVENT_KEY_OK);
			LCD_sign(LCD_SPECIAL_F1, LCD_OFF);
			return UI_CONTACTS_MENU;
		}else if(check_event(EVENT_KEY_BACK)){
			clear_event(EVENT_KEY_BACK);
			LCD_sign(LCD_SPECIAL_F1, LCD_OFF);
			return UI_CONTACTS_MENU;
		}
	}
	return UI_NONE;
}

uint8_t volatile reset = 0;

uint8_t ui_shutdown_function(uint8_t new)
{
	
	if(sim_at_powerdown()){
		return UI_STANDBY;
	}
	
	reset = 1;
	sim_sleep();
	
	//Maybe put this somwhere else
	//PWR->CR |= PWR_CR_CWUF;
	//PWR->CR &= ~PWR_CR_PDDS;
	//PWR->CR |= PWR_CR_LPSDSR;
	//PWR->CR |= PWR_CR_ULP;
	//SCB->SCR |= SCB_SCR_SLEEPDEEP;
	
	//LCD_off();
	LCD_clear();
	LCD_put('0', 5);
	LCD_put('f', 4);
	LCD_put('f', 3);
	
	NVIC->ICER[RING_IRQn >> 0x05] = 0x01 << (RING_IRQn & 0x1F); //Disable interrupt
	SysTick->CTRL = 0;
	
	//pc_putchar('S');
	stop_usart_sim();
	stop_usart_pc();
	
	__WFI();
	
	reset = 0;
	NVIC_SystemReset();
	return UI_INTRO;
}