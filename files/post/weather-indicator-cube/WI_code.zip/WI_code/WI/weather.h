#ifndef WEATHER_H
#define WEATHER_H 1

#include "time.h"

#define WEATHER_BRIGHTNESS_LENGTH 8
extern char const* const weather_brightness[WEATHER_BRIGHTNESS_LENGTH];

#define WEATHER_SPECIAL_LENGTH 19 //3 severity + 16 types
extern char const* const weather_special[WEATHER_SPECIAL_LENGTH];

#define CLEAR			1
#define MOST_CLEAR 		2
#define SLIGHT_CLOUDY	3
#define PART_CLOUDY		4
#define MOD_CLOUDY		5
#define PREV_CLOUDY		6
#define OVERCAST		7
#define FOG				8

#define NO_SPECIAL	0
#define SEV_LIGHT	1
#define SEV_MOD		2
#define SEV_HEAVY	3

#define FG			4
#define DZ			5
#define FZDZ		6
#define RA			7
#define FZRA		8
#define RASN		9
#define SN			10
#define SHRA		11
#define SHRASN		12
#define SHSN		13
#define SHGR		14
#define TS			15
#define TSRA		16
#define TSRASN		17
#define TSSN		18
#define TSGR		19


typedef struct{
	uint8_t brightness;
	uint8_t special;
	uint8_t severity;
	int8_t temperature;
	uint8_t wind;
} weather_type;

uint8_t get_weather(weather_type* weather_data);

//Special circs:
#define WIND_LINE 5

#define TEMP_LOW 0
#define TEMP_MOD 10
#define TEMP_HIGH 20

#define TOTAL_WEATHER 26 //25 for types + 1 error

#define WEATHER_SUNNY_HIGH	0
#define WEATHER_SUNNY_MOD	1
#define WEATHER_SUNNY_LOW	2
#define WEATHER_SUNNY_FR	3
#define WEATHER_SUNNY_WI	4

#define WEATHER_CLOUD_HIGH	5
#define WEATHER_CLOUD_MOD	6
#define WEATHER_CLOUD_LOW	7
#define WEATHER_CLOUD_FR	8
#define WEATHER_CLOUD_WI	9

#define WEATHER_FOG_MOD		10
#define WEATHER_FOG_WI		11

#define WEATHER_RAIN_HIGH	12
#define WEATHER_RAIN_MOD	13
#define WEATHER_RAIN_LOW	14
#define WEATHER_RAIN_MIC	15
#define WEATHER_RAIN_WI		16
#define WEATHER_RAIN_MWI	17

#define WEATHER_SNOW_HIGH	18
#define WEATHER_SNOW_MOD	19
#define WEATHER_SNOW_LOW	20
#define WEATHER_SNOW_WI		21

#define WEATHER_HAIL_HIGH	22
#define WEATHER_HAIL_MOD	23
#define WEATHER_HAIL_LOW	24

#define WEATHER_ERROR		0xff

extern uint8_t weather_slots[NUMBER_OF_SLOTS];


#endif