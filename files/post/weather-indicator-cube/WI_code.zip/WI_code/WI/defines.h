#ifndef DEFINES_H
#define DEFINES_H 1

//#define GLOBAL_INIT_STRUCTURES 1
//#define REINIT_PORT_CLK 1

//USART:
#define DOUBLE_CHECK 1
#define FOWARD_TO_PC 1
#define BUFFER_SIZE 2048

//REGEX:
#define REGEX_TIMEOUT 20000 //In ms
#define MAX_GENERAL 32

//INET:
#define READ_TIMEOUT 20000 //In ms
#define PRINT_NUMBER_MAX 10

//
//Should not be more than 64 slots total
#define NUMBER_OF_SLOTS 16 
#define HOURS_BETWEEN_SLOTS 3
#define SLOTS_PER_DAY (24/HOURS_BETWEEN_SLOTS)

//color
#define MAX_COLOR_FRAMES 20 

#define PC_DEBUG 1




#endif