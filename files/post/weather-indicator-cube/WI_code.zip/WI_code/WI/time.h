#ifndef TIME_H
#define TIME_H 1

//Other files
#include "defines.h"
#include "cgpio.h"


//Time is kept in UTC for ease of development
typedef struct{
	uint16_t year;
	uint8_t month;
	uint8_t day;
	uint8_t hour;
	uint8_t minute;
} time;

extern time current_time;
extern time previous_time;
extern time rough_time;
extern uint8_t current_slot; //This one should be set to only the 0-2 time period. Ala 0, 8 etc.


//assert_param(!(current_slot%SLOTS_PER_DAY))


void increment_rough_time(void);

void copy_time(time* t_source, time* t_dest);
uint8_t is_leap_year(uint16_t year);
uint8_t get_day_of_month(uint8_t month, uint16_t year);

uint8_t get_day_difference(time* t_old, time* t_new);
uint8_t get_prediction_slot(time* t);
uint8_t get_current_slot(void);



#endif