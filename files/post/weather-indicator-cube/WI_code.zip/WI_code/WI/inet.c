#include "inet.h"

//Misc functions

uint8_t status = 0;

uint8_t is_number(char c){
	if(c < 0x30){
		return 0;
	}
	if(c > 0x39){
		return 0;
	}
	return 1;
}

void reset_rn(void){
	GPIO_RESET(GPIOB, 1);
	delay_ms(20);
	GPIO_SET(GPIOB, 1);
	delay_ms(1000);
}

inet_error rn_sleep(void){
	uint8_t err;
	//Enter command mode
	delay_ms(250);
	rn_putstring("$$$");
	err = block_until_sequence("CMD");
	if(err != 1){
		return INET_TIMEOUT_ERROR;
	}
	
	rn_putstring("sleep\r"); //Put to sleep
	err = block_until_sequence2("AOK", "ERR");
	if (err != 1){
		return INET_RN_ERROR;
	}
	
	return INET_NO_ERROR;
}

inet_error rn_stop_sleep(void){
	GPIO_SET(GPIOB, 2);
	delay_ms(50);
	GPIO_RESET(GPIOB, 2);
	return INET_NO_ERROR;
}


//add_to_number adds the number stream to the number, shifts the numbers in by the number of additions.
//If terminator is supplied, it waits for it specifically, else it takes any non number as a terminator.
inet_error add_to_number_16(uint16_t* number, char terminator){
	char c;
	while(1){
		set_timeout(READ_TIMEOUT);
		while(!rn_filled()){
			if(timeout_occured()){
				return INET_TIMEOUT_ERROR;
			}
		}
		c = rn_getchar();
		if(terminator){
			if(c == terminator){
				return INET_NO_ERROR;
			}
		}else{
			if(!is_number(c)){
				return INET_NO_ERROR;
			}
		}
		*number *= 10;
		*number += c - 0x30;
	}
}

//add_to_number adds the number stream to the number, shifts the numbers in by the number of additions.
//If terminator is supplied, it waits for it specifically, else it takes any non number as a terminator.
//Reads the first non-numeric character as well!
inet_error add_to_number_8(uint8_t* number, char terminator)
{
	uint16_t temp;
	inet_error error;
	
	temp = (uint16_t)(*number);
	error = add_to_number_16(&temp, terminator);
	
	*number = (uint8_t)(temp);
	return error;
}

inet_error print_number_16(uint16_t number)
{
	char s[PRINT_NUMBER_MAX];
	uint16_t temp;
	uint8_t i = 0;
	while(number){
		temp = number%10;
		number /= 10;
		s[i] = temp + 0x30;
		i++;
	}
	for(; i; i--){
		rn_putchar(s[i-1]);
	}
	return INET_NO_ERROR;
}

inet_error print_number_8(uint8_t number)
{
	return print_number_16((uint16_t)number);
}


//Main functions

inet_error connect_to_network(uint8_t force_protection)
{
	char err;
	
	//Enter command mode
	delay_ms(250);
	rn_putstring("$$$");
	err = block_until_sequence("CMD");
	if(err != 1){
		return INET_TIMEOUT_ERROR;
	}
	
	rn_putstring("scan\r");
	/*err = block_until_sequence2("AOK", "ERR");
	if (err != 1){
		return INET_RN_ERROR;
	}*/
	
	//Scan trough wifi list
	err = block_until_sequence("SCAN");
	if (err == 0)
	{
		return INET_TIMEOUT_ERROR;
	}
	
	uint8_t best = 0;
	uint16_t best_rssi = 0xffff;
	uint8_t i = 0;
	uint16_t temp_rssi;
	uint8_t ssid_found;
	
	while(1){
		err = block_until_sequence2(",-", "END:");
		if (err == 0){
			return INET_TIMEOUT_ERROR;
		}else if (err == 2){
			break;
		}
		i++;
	
		temp_rssi = 0;
		add_to_number_16(&temp_rssi, 0x00);
		
		err = block_until_sequence2("0", "END:");
		if (err == 0){
			return INET_TIMEOUT_ERROR;
		}else if (err != 1){
			return INET_RN_ERROR;
		}
		
		set_timeout(REGEX_TIMEOUT);
		while(!rn_filled()){
			if(timeout_occured()){
				return INET_TIMEOUT_ERROR;
			}
		}
		
		if(rn_getchar() == '0' && !force_protection){
			if(temp_rssi < best_rssi){
				best_rssi = temp_rssi;
				best = i;
			}
		}else{
			/*ssid_found = block_until_found();
			if(ssid_found != 0 && ssid_found != 1){
				if(temp_rssi < best_rssi){
				best_rssi = temp_rssi;
				best = i;
				//ALSO STORE POINTER TO SSID PASSCODE
			}
			*/
		}
		
		err = block_until_sequence("\n");
		if (err == 0){
			return INET_TIMEOUT_ERROR;
		}
	}
	
	if( i != 0 ){
		rn_putstring("join # ");
		print_number_8(best);
		//rn_putstring("join RNTest");
		rn_putchar('\r');
		err = block_until_sequence2("IP=", "ERR");
		if (err == 0){
			return INET_TIMEOUT_ERROR;
		}else if (err != 1){
			return INET_RN_ERROR;
		}
	}else{
		return INET_CONNECTION_ERROR;
	}
	
	//Exit command mode
	rn_putstring("exit\r");
	err = block_until_sequence("EXIT");
	if(err != 1){
		return INET_TIMEOUT_ERROR;
	}
	
	return INET_NO_ERROR;
}

inet_error setup_rn_module(void)
{
	char err;
	
	//Enter command mode
	delay_ms(250);
	rn_putstring("$$$");
	err = block_until_sequence("CMD");
	if(err != 1){
		return INET_TIMEOUT_ERROR;
	}
	
	rn_putstring("set c r 0\r"); //Disable remote string (we don't want to send anything we don't want to)
	err = block_until_sequence2("AOK", "ERR");
	if (err != 1){
		return INET_RN_ERROR;
	}
	
	rn_putstring("set s p 0x4004\r"); //Set MCU friendly print of scan
	err = block_until_sequence2("AOK", "ERR");
	if (err != 1){
		return INET_RN_ERROR;
	}
	
	//Exit command mode
	rn_putstring("exit\r");
	err = block_until_sequence("EXIT");
	if(err != 1){
		return INET_TIMEOUT_ERROR;
	}
	
	return INET_NO_ERROR;
	
}

inet_error open_connection(char* ip, char* port)
{
	char err;
	
	//Enter command mode
	delay_ms(250);
	rn_putstring("$$$");
	err = block_until_sequence("CMD");
	if(err != 1){
		return INET_TIMEOUT_ERROR;
	}
	
	rn_putstring("show con\r");
	//rn_putstring("get everything\r");
	delay_ms(100);
	//rn_putstring("ping g\r");
	//delay_ms(5000);
	
	rn_putstring("open "); //Send the open string
	rn_putstring(ip);
	rn_putchar(' ');
	rn_putstring(port);
	rn_putchar('\r');
	
	err = block_until_sequence2("*OPEN", "*CLOS*");
	if (err != 1)
	{
		return INET_RN_ERROR;
	}
	
	//Exit command mode
	//rn_putstring("exit\r");
	//err = block_until_sequence("EXIT");
	//if(err != 1){
	//	return INET_TIMEOUT_ERROR;
	//}
	
	return INET_NO_ERROR;
}

inet_error close_connection(void)
{
	char err;
	
	//Enter command mode
	delay_ms(250);
	rn_putstring("$$$");
	err = block_until_sequence("CMD");
	if(err != 1){
		return INET_TIMEOUT_ERROR;
	}
	
	rn_putstring("close\r"); //Send the open string
	
	err = block_until_sequence("*CLOS*");
	if (err == 1){
	
		//Exit command mode
		rn_putstring("exit\r");
		err = block_until_sequence("EXIT");
		if(err != 1){
			return INET_TIMEOUT_ERROR;
		}
		return INET_NO_ERROR;
		
	}else if(err != 0){
		return INET_CONNECTION_ERROR;
	}else{
		return INET_TIMEOUT_ERROR;
	}
}




inet_error inet_get_time(time* t)
{

	inet_error error;
	uint8_t seq;
	//error = open_connection("12.10.191.251", "13");
	error = open_connection(DEFAULT_TIME_SERVER, TIME_SERVER_PORT);
	if(error){
		return error;
	}

	seq = block_until_sequence2(" ", "*CLOS*");
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}else if(seq != 1){
		return INET_CONNECTION_ERROR;
	}

	t->year = 20;
	error = add_to_number_16(&t->year, 0x00);
	if(error){
		return error;
	}

	t->month = 0;
	error = add_to_number_8(&t->month, 0x00);
	if(error){
		return error;
	}

	t->day = 0;
	error = add_to_number_8(&t->day, 0x00);
	if(error){
		return error;
	}

	t->hour = 0;
	error = add_to_number_8(&t->hour, 0x00);
	if(error){
		return error;
	}

	t->minute = 0;
	error = add_to_number_8(&t->minute, 0x00);
	if(error){
		return error;
	}
	
	seq = block_until_sequence("*CLOS*");
	if (seq == 1){
		return INET_NO_ERROR;
	}else if(seq != 0){
		return INET_CONNECTION_ERROR;
	}else{
		return INET_TIMEOUT_ERROR;
	}
}

inet_error read_location(int16_t* loc)
{	
	char c;
	inet_error error;
	uint8_t i;
	int16_t sign = 1;
	uint16_t uloc = 0;

	set_timeout(READ_TIMEOUT);
	while(!rn_filled()){
		if(timeout_occured()){
			return INET_TIMEOUT_ERROR;
		}
	}
	c = rn_getchar();
	if(is_number(c)){
		uloc *= 10;
		uloc += c - 0x30;
	}else if(c == '-'){
		sign = -1;
	}else{
		return INET_CONNECTION_ERROR;
	}
	
	error = add_to_number_16(&uloc, '.');
	if(error){
		return error;
	}
	
	for(i = 0; i < 2; i++){
		set_timeout(READ_TIMEOUT);
		while(!rn_filled()){
			if(timeout_occured()){
				return INET_TIMEOUT_ERROR;
			}
		}
		c = rn_getchar();
		if(!is_number(c)){
			uloc *= (2-i)*10;
			break;
		}
		uloc *= 10;
		uloc += c - 0x30;
	}

	*loc = ((int16_t)uloc&0x7fff)*sign;
	
	return INET_NO_ERROR;
}

inet_error inet_get_location(uint8_t* location)
{
	inet_error error;
	uint8_t seq;
	
	int16_t lat;
	int16_t log;
	
	error = open_connection(DEFAULT_LOCATION_SERVER, LOCATION_SERVER_PORT);
	if(error){
		return error;
	}
	
	rn_putstring("GET / HTTP/1.1\r\n");
	rn_putstring("Host: ");
	rn_putstring(DEFAULT_LOCATION_SERVER);
	rn_putstring("\r\n");
	//rn_putstring("User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:20.0) Gecko/20100101 Firefox/20.0");
	//rn_putstring("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n");
	rn_putstring("\r\n");

	seq = block_until_sequence2("HTTP/1.1 ", "*CLOS*");
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}else if(seq != 1){
		return INET_CONNECTION_ERROR;
	}

	set_timeout(REGEX_TIMEOUT);
	while(!rn_filled()){
		if(timeout_occured()){
			return INET_TIMEOUT_ERROR;
		}
	}
	if(rn_getchar() != '2'){
		return INET_CONNECTION_ERROR;
	}

	seq = block_until_sequence2("Latitude: </font>", "*CLOS*");
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}else if(seq != 1){
		return INET_CONNECTION_ERROR;
	}

	error = read_location(&lat);
	if(error){
		return error;
	}

	seq = block_until_sequence2("Longitude: </font>", "*CLOS*");
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}else if(seq != 1){
		return INET_CONNECTION_ERROR;
	}

	error = read_location(&log);
	if(error){
		return error;
	}

	*location = closest_location(lat, log);
	
	error = close_connection();
	if(error){
		return error;
	}
	return INET_NO_ERROR;
}

inet_error read_meteo_data(uint8_t* slot, uint8_t* weather)
{
	time data_time;
	weather_type weather_data;
	inet_error error;
	uint8_t seq; 
	seq = block_until_sequence3("<valid_UTC>", "<valid_UTC/>", "*CLOS*");
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}else if(seq != 1){
		return INET_CONNECTION_ERROR;
	}
	
	data_time.day = 0;
	error = add_to_number_8(&data_time.day, 0x00);
	if(error){
		return error;
	}

	data_time.month = 0;
	error = add_to_number_8(&data_time.month, 0x00);
	if(error){
		return error;
	}

	data_time.year = 0;
	error = add_to_number_16(&data_time.year, 0x00);
	if(error){
		return error;
	}

	data_time.hour = 0;
	error = add_to_number_8(&data_time.hour, 0x00);
	if(error){
		return error;
	}

	data_time.minute = 0;
	error = add_to_number_8(&data_time.minute, 0x00);
	if(error){
		return error;
	}
	
	*slot = get_prediction_slot(&data_time);
	
	seq = block_until_sequence3("<nn_icon-wwsyn_icon>", "<nn_icon-wwsyn_icon/>", "*CLOS*");
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}else if(seq != 1){
		return INET_CONNECTION_ERROR;
	}

	seq = block_until_found(weather_brightness, WEATHER_BRIGHTNESS_LENGTH);
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}
	weather_data.brightness = seq;

	set_timeout(REGEX_TIMEOUT);
	while(!rn_filled()){
		if(timeout_occured()){
			return INET_TIMEOUT_ERROR;
		}
	}
	if(rn_getchar() == '_'){
		seq = block_until_found(weather_special, WEATHER_SPECIAL_LENGTH);
		if(seq == 0){
			return INET_TIMEOUT_ERROR;
		}else if(seq <= SEV_HEAVY){
			weather_data.severity = seq;
			seq = block_until_found(weather_special, WEATHER_SPECIAL_LENGTH);
			if(seq == 0){
				return INET_TIMEOUT_ERROR;
			}
		}
		weather_data.special = seq;// - SEV_HEAVY;
	}else{
		weather_data.special = NO_SPECIAL;
		weather_data.severity = NO_SPECIAL;
	}

	seq = block_until_sequence3("<t>", "<t/>", "*CLOS*");
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}else if(seq != 1){
		return INET_CONNECTION_ERROR;
	}
	
	int8_t sign = 1;
	char temp;
	uint8_t temp_temp;
	
	set_timeout(REGEX_TIMEOUT);
	while(!rn_filled()){
		if(timeout_occured()){
			return INET_TIMEOUT_ERROR;
		}
	}
	
	weather_data.temperature = 0;
	temp = rn_getchar();
	if(temp == '-'){
		sign = -1;
	}else if(is_number(temp)){
		temp_temp += temp - 0x30;
	}else{
		return INET_CONNECTION_ERROR;
	}
	
	error = add_to_number_8(&temp_temp, 0x00);
	if(error){
		return error;
	}
	
	weather_data.temperature = ((int8_t)temp_temp)*sign;

	seq = block_until_sequence2("<ff_val>", "<ff_val/>" "*CLOS*");
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}else if(seq != 1){
		return INET_CONNECTION_ERROR;
	}
	
	weather_data.wind = 0;
	error = add_to_number_8(&weather_data.wind, 0x00);
	if(error){
		return error;
	}
	
	uint8_t max_wind;
	max_wind = 0;
	seq = block_until_sequence3("<ffmax_val>", "<ffmax_val/>", "*CLOS*");
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}else if((seq != 1) &&(seq != 2)){ //HARDCODED *CLOS*; BE CAREFULL!!!!
		return INET_CONNECTION_ERROR;
	}else if (seq == 1){
		error = add_to_number_8(&max_wind, 0x00);
		if(error){
			return error;
		}
	}
	
	if(max_wind > weather_data.wind){
		weather_data.wind = max_wind;
	}
	
	*weather = get_weather(&weather_data);
	
	return INET_NO_ERROR;
}

inet_error inet_get_weather_info(uint8_t weather_slots[NUMBER_OF_SLOTS])
{
	uint8_t read_data = 0;
	inet_error error;
	uint8_t seq;
	
	error = open_connection("www.meteo.si", "80");
	if(error){
		return error;
	}
	
	rn_putstring("GET /uploads/probase/www/fproduct/text/sl/forecast_");
	rn_putstring_const(location_string[current_location]);
	rn_putstring("_int3h.xml HTTP/1.1\r\n");
	rn_putstring("Host: www.meteo.si\r\n");
	rn_putstring("\r\n");

	seq = block_until_sequence2("HTTP/1.1 ", "*CLOS*");
	if(seq == 0){
		return INET_TIMEOUT_ERROR;
	}else if(seq != 1){
		return INET_CONNECTION_ERROR;
	}

	set_timeout(REGEX_TIMEOUT);
	while(!rn_filled()){
		if(timeout_occured()){
				return INET_TIMEOUT_ERROR;
			}
	}
	if(rn_getchar() != '2'){
		return INET_CONNECTION_ERROR;
	}
	//return INET_NO_ERROR;
	
	while(1){
		uint8_t slot;
		uint8_t weather;
		seq = block_until_sequence3("<metData>", "</data>", "*CLOS*");
		if (seq == 2){
			if(read_data > 0){ //Check if at least one data was read, if not there is probably an error.
				break;
			}else{
				return INET_CONNECTION_ERROR;
			}
		}else if(seq == 0){
			return INET_TIMEOUT_ERROR;
		}else if(seq != 1){
			return INET_CONNECTION_ERROR;
		}
		
		error = read_meteo_data(&slot, &weather);
		if(error){
			return error;
		}
		pc_putstring("\r\nGot weather data:");
		pc_putchar(0x30+((slot>>4)&0x0f));
		pc_putchar(0x30+((slot)&0x0f));
		pc_putchar('_');
		pc_putchar(0x30+((weather>>4)&0x0f));
		pc_putchar(0x30+((weather)&0x0f));
		pc_putstring("_SW\r\n");
		
		if(slot == 0xff){
			break;
		}else if(slot != (0xff-1)){
			read_data++;
		
			weather_slots[slot] = weather;
			
		}
		
	}
	
	error = close_connection();
	if(error){
		return INET_MILD_ERROR;
	}
	
	return INET_NO_ERROR;
}