#ifndef INET_H
#define INET_H 1

//Other files
#include "defines.h"
#include "cgpio.h"

#include "time.h"
#include "regex.h"
#include "usart.h"
#include "rtc.h"
#include "time.h"
#include "location.h"
#include "weather.h"

#define DEFAULT_TIME_SERVER 	"utcnist.colorado.edu"
#define TIME_SERVER_PORT 		"13"

#define DEFAULT_LOCATION_SERVER 	"www.showipinfo.net"
#define LOCATION_SERVER_PORT		"80"

typedef uint8_t inet_error;
#define INET_NO_ERROR 0
#define INET_TIMEOUT_ERROR 1
#define INET_CONNECTION_ERROR 2
#define INET_RN_ERROR 3
#define INET_MILD_ERROR 4

extern uint8_t status; //Each bit is a warning
#define STATUS_NORMAL 0x00
#define STATUS_WEATHER_SLOTS_EMPTY 0x01
#define STATUS_INIT 0x02

void reset_rn(void);

inet_error rn_sleep(void);
inet_error rn_stop_sleep(void);

inet_error setup_rn_module(void);
inet_error inet_get_time(time* t);
inet_error connect_to_network(uint8_t force_protection);
inet_error inet_get_time(time* t);
inet_error inet_get_location(uint8_t* location);
inet_error inet_get_weather_info(uint8_t weather_slots[NUMBER_OF_SLOTS]);





#endif