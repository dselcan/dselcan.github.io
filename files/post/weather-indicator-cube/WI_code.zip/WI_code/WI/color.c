#include "color.h"

color_frame weather_sequences[TOTAL_WEATHER][MAX_COLOR_FRAMES] = {
{{0,0,0,200},{0,166,0,100},{0,224,0,100},{50,255,0,200},{150,255,0,100},{130,224,0,100},{95,166,0,200},{0,0,0,250},{0,0,0,250}}, //ClearHi
{{0,0,0,200},{0,166,0,100},{0,224,0,100},{35,255,0,200},{90,255,0,100},{70,224,0,100},{45,166,0,200},{0,0,0,250},{0,0,0,250}}, //ClearMed
{{0,0,0,200},{0,166,0,100},{0,224,0,100},{0,255,0,200},{0,255,0,100},{0,224,0,100},{0,166,0,200},{0,0,0,250},{0,0,0,250}}, //ClearLow
{{0,0,0,200},{0,166,0,100},{0,224,0,100},{0,255,40,200},{0,255,120,100},{0,224,100,100},{0,166,75,200},{0,0,0,250},{0,0,0,250}}, //ClearFr
{{0,0,0,100},{0,166,0,50},{0,224,0,50},{0,255,0,200},{0,255,0,50},{0,224,0,50},{0,166,0,100},{0,0,0,250},{0,0,0,250}}, //ClearWi
{{0,0,0,200},{0,166,166,100},{0,224,224,100},{0,255,220,200},{0,255,110,100},{0,224,85,100},{0,166,40,200},{0,0,0,250},{0,0,0,250}}, //CloudHi
{{0,0,0,200},{0,166,166,100},{0,224,224,100},{0,255,240,200},{0,255,180,100},{0,224,120,100},{0,166,80,200},{0,0,0,250},{0,0,0,250}}, //CloudMed
{{0,0,0,200},{0,166,166,100},{0,224,224,100},{0,255,255,200},{0,255,255,100},{0,224,224,100},{0,166,166,200},{0,0,0,250},{0,0,0,250}}, //CloudLow
{{0,0,0,200},{0,166,166,100},{0,224,224,100},{0,220,255,200},{0,160,255,100},{0,110,224,100},{0,75,166,200},{0,0,0,250},{0,0,0,250}}, //CloudFr
{{0,0,0,100},{0,166,166,50},{0,224,224,50},{0,255,255,200},{0,255,255,50},{0,224,224,50},{0,166,166,100},{0,0,0,250},{0,0,0,250}}, //CloudLow
{{0,0,0,200},{0,0,166,100},{0,0,224,100},{0,0,255,200},{0,0,255,100},{0,0,224,100},{0,0,166,200},{0,0,0,250},{0,0,0,250}}, //Fog
{{0,0,0,100},{0,0,166,50},{0,0,224,50},{0,0,255,200},{0,0,255,50},{0,0,224,50},{0,0,166,100},{0,0,0,250},{0,0,0,250}}, //FogWi
{{0,0,0,200},{166,166,0,100},{224,224,0,100},{255,220,0,200},{255,110,0,100},{224,85,0,100},{166,40,0,200},{0,0,0,250},{0,0,0,250}}, //RainHi
{{0,0,0,200},{166,166,0,100},{224,224,0,100},{255,240,0,200},{255,180,0,100},{224,120,0,100},{166,80,0,200},{0,0,0,250},{0,0,0,250}}, //RainMed
{{0,0,0,200},{166,166,0,100},{224,224,0,100},{255,255,0,200},{255,255,0,100},{224,224,0,100},{166,166,0,200},{0,0,0,250},{0,0,0,250}}, //RainLow
{{0,0,0,200},{166,166,0,100},{224,224,0,100},{230,255,0,200},{180,255,0,100},{140,224,0,100},{90,166,0,200},{0,0,0,250},{0,0,0,250}}, //RainMic
{{0,0,0,100},{166,166,0,50},{224,224,0,50},{255,255,0,200},{255,255,0,50},{224,224,0,50},{166,166,0,100},{0,0,0,250},{0,0,0,250}}, //RainWi
{{0,0,0,100},{166,166,0,50},{224,224,0,50},{230,255,0,200},{180,255,0,50},{140,224,0,50},{90,166,0,100},{0,0,0,250},{0,0,0,250}}, //RainMWi
{{0,0,0,200},{166,0,166,100},{224,0,224,100},{255,0,240,200},{255,0,180,100},{224,0,120,100},{166,0,80,200},{0,0,0,250},{0,0,0,250}}, //SnowHi
{{0,0,0,200},{166,0,166,100},{224,0,224,100},{255,0,255,200},{255,0,255,100},{224,0,224,100},{166,0,166,200},{0,0,0,250},{0,0,0,250}}, //SnowMed
{{0,0,0,200},{166,0,166,100},{224,0,224,100},{240,0,255,200},{180,0,255,100},{120,0,224,100},{80,0,166,200},{0,0,0,250},{0,0,0,250}}, //SnowLow
{{0,0,0,100},{166,0,166,50},{224,0,224,50},{255,0,255,200},{255,0,255,50},{224,0,224,50},{166,0,166,100},{0,0,0,250},{0,0,0,250}}, //SnowMed
{{0,0,0,200},{166,0,0,100},{224,0,0,100},{255,0,0,200},{255,0,180,100},{224,0,130,100},{166,0,95,200},{0,0,0,250},{0,0,0,250}}, //HailHi
{{0,0,0,200},{166,0,0,100},{224,0,0,100},{255,0,35,200},{255,0,90,100},{224,0,70,100},{166,0,45,200},{0,0,0,250},{0,0,0,250}}, //HailMed
{{0,0,0,200},{166,0,0,100},{224,0,0,100},{255,0,0,200},{255,0,0,100},{224,0,0,100},{166,0,0,200},{0,0,0,250},{0,0,0,250}} //HailLow
};

uint8_t weather_lengths[TOTAL_WEATHER] = {
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9,
9
};

color_frame mode_sequences[TOTAL_MODES][MAX_COLOR_FRAMES] = {
{{0,0,0,200},{0,255,0,200}}, //IDLE
{{0,0,0,200},{255,255,0,200}}, //No_network
{{0,0,0,200},{255,0,0,200}} //RN_error
};

uint8_t mode_lengths[TOTAL_MODES] = {
2,
2,
2
};

uint8_t current_sequence = 0;
uint8_t current_index = 0;
uint8_t current_color = 0;
uint8_t current_status = 0;

void reset_color(void)
{
	current_sequence = 0;
	current_index = 0;
}


uint8_t get_current_mode()
{
	if(status & STATUS_INIT){
		return MODE_IDLE;
	}else if(status&STATUS_WEATHER_SLOTS_EMPTY){
		return MODE_RN_ERROR;
	}
	return MODE_IDLE;
}

uint8_t get_current_color(uint8_t start, uint8_t end, uint8_t step, uint8_t duration)
{
	uint8_t color;
	if(start > end){
		color = start - (uint16_t)(start - end)*step/duration;
	}else{
		color = start + (uint16_t)(end - start)*step/duration;
	}
	
	return color;
}


uint16_t get_divisor(uint8_t start, uint8_t end, uint8_t duration) //uint8_t step
{
	uint16_t diff;
	if(start > end){
		diff = start - end;
		//diff = start - (start - end)*step/duration;
	}else{
		diff = end - start;
		//diff = start + (end - start)*step/duration;
	}
	
	diff = (diff * 0xff)/duration;
	return diff;
}

void update_color_cycle(void)
{
	color_frame* current_frame;
	color_frame* next_frame;
	
	uint8_t temp_sequence;
	
	if(current_status){ //error
		current_frame = &mode_sequences[current_color][current_sequence];
	}else{
		current_frame = &weather_sequences[current_color][current_sequence];
	}
	
	current_index++;
	if(current_index >= current_frame->duration){
		current_index = 0;
		current_sequence++;
		if(current_status){ //error
			current_frame = &mode_sequences[current_color][current_sequence];
		}else{
			current_frame = &weather_sequences[current_color][current_sequence];
		}
	}
	
	temp_sequence = current_sequence + 1;
	
	if(current_status){ //An error or other exception
		if(current_sequence >= mode_lengths[current_color]){
			current_sequence = 0;
			
			//Update the cycle only on completion
			current_status = status;
			current_color = get_current_mode();
		}
		if(temp_sequence >= mode_lengths[current_color]){
			temp_sequence = 0;
		}
		
		next_frame = &mode_sequences[current_color][temp_sequence];
	}else{
		if(current_sequence >= weather_lengths[current_color]){
			current_sequence = 0;
			
			//Update the cycle only on completion
			current_status = status;
			current_color = weather_slots[get_current_slot()];
		}
		if(temp_sequence >= weather_lengths[current_color]){
			temp_sequence = 0;
		}
		
		next_frame = &weather_sequences[current_color][temp_sequence];
	}

	//Got everything needed.
	/*
	pc_putchar('i');
	pc_putint(current_index);
	pc_putchar('r');
	pc_putint(current_frame->red);
	pc_putchar('g');
	pc_putint(current_frame->green);
	pc_putchar('b');
	pc_putint(current_frame->blue);
	pc_putchar('d');
	pc_putint(current_frame->duration);
	pc_putchar('r');
	pc_putint(next_frame->red);
	pc_putchar('g');
	pc_putint(next_frame->green);
	pc_putchar('b');
	pc_putint(next_frame->blue);
	pc_putchar('d');
	pc_putint(next_frame->duration);
	pc_putchar('\r');
	pc_putchar('\n');
	*/
	
	uint8_t start;
	uint8_t end;
	uint8_t step;
	uint8_t duration;
	
	start = current_frame->red;
	end = next_frame->red;
	step = current_index;
	duration = current_frame->duration;
	set_red(get_current_color(start, end, step, duration));
	
	start = current_frame->green;
	end = next_frame->green;
	step = current_index;
	duration = current_frame->duration;
	set_green(get_current_color(start, end, step, duration));
	
	start = current_frame->blue;
	end = next_frame->blue;
	step = current_index;
	duration = current_frame->duration;
	set_blue(get_current_color(start, end, step, duration));
	
}