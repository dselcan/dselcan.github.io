
#include "rtc.h"

//RTS timer bound vars
static __IO uint16_t delay_counter;

uint8_t rn_time;
uint8_t rn_update;
uint8_t misc_time;
uint8_t misc_update;
uint8_t minute_time;


void delay_ms(uint16_t delay)
{
	delay_counter = (delay/10);
	while(delay_counter > 0);
}

void set_timeout(uint16_t timeout)
{
	delay_counter = (timeout/10);
}

uint8_t timeout_occured()
{
	if(delay_counter > 0){
		return 0;
	}else{
		return 1;
	}
}

void init_rtc(void)
{
	
	RCC->APB1ENR |= RCC_APB1ENR_PWREN;
	PWR->CR |= PWR_CR_DBP; //Disable write protection
	
	RCC->CSR |= RCC_CSR_LSION; //Enable LSI
	while(!(RCC->CSR & RCC_CSR_LSIRDY)); //Wait for LSI
	
	RCC->CSR &= ~RCC_CSR_RTCSEL;
	RCC->CSR |= (RCC_CSR_RTCSEL_1 | RCC_CSR_RTCEN); //LSI as RTC clock, enable RTC
	//RCC->CSR |= RCC_CSR_RTCEN; //Enable RTC
	
	
	RTC->WPR = 0xCA;
	RTC->WPR = 0x53; //Disable the write protection for RTC register
	RTC->ISR &= ~RTC_ISR_RSF;
	while(!(RTC->ISR & RTC_ISR_RSF)); //Wait for synchro, I think
	
	//RTC->CR &= ~RTC_CR_WUTE; //Disable RTC wakeup
	//while(!(RTC->ISR & RTC_ISR_WUTWF));
	
	EXTI->PR |= EXTI_PR_PR20;
	EXTI->IMR |= EXTI_IMR_MR20;
	EXTI->EMR &= ~EXTI_EMR_MR20;
	EXTI->RTSR |= EXTI_RTSR_TR20;
	EXTI->FTSR &= ~EXTI_FTSR_TR20; //Configure EXTI As rising edge Interrupt mode
	
	NVIC->IP[RTC_WKUP_IRQn] = 0x4; //Priority 4
	// >> 0x05 take top 3 bits = 32 bits per register, &0x1f - 32 bit mask
    NVIC->ISER[RTC_WKUP_IRQn >> 0x05] = 0x01 << (RTC_WKUP_IRQn & 0x1F); //Enable interrupt - can assing due to it being positive edge triggered
    //NVIC->ICER[RTC_WKUP_IRQn >> 0x05] = 0x01 << (RTC_WKUP_IRQn & 0x1F); //Disable interrupt
	
	
	RTC->CR &= ~RTC_CR_WUCKSEL; //Set wakeup to CLK/16
	RTC->WUTR = 24; //10 ms wakeup
	
	//Enable interrupt
	RTC->CR |= RTC_CR_WUTIE;
	RTC->CR |= RTC_CR_WUTE; //Enable RTC wakeup
	
	rn_time = 0;
	rn_update = 1;
	minute_time = 0;
	misc_time = 0;
	misc_update = 0; //No need if rn_update up
	
	RTC->WPR = 0xFF; //Enable write protection
	//PWR->CR &= ~PWR_CR_DBP; //Disable write protection
}

void decrement_delay(void)
{
	if(delay_counter > 0){
		delay_counter--;
	}
}

void RTC_WKUP_IRQHandler(void)
{
	if(RTC->ISR & RTC_ISR_WUTF){
		decrement_delay();
		
		update_color_cycle();
		misc_time++;
		if(misc_time > MISC_UPDATE_INTERVAL){
			misc_time = 0;
			misc_update = 1;
			
			minute_time++;
			if(minute_time > MINUTE_UPDATE_INTERVAL){
				minute_time = 0;
				increment_rough_time();
				
				rn_time++;
				if(rn_time > RN_UPDATE_INTERVAL){
					rn_time = 0;
					rn_update = 1;
				}
			}
		}
		
		RTC->ISR &= ~RTC_ISR_WUTF;
		EXTI->PR |= EXTI_PR_PR20;
	}
}