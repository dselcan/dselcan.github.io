#include "adc.h"

void enable_gpio_clocks_a(void)
{
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN;
}

void disable_gpio_clocks_a(void)
{
	RCC->AHBENR |= ~RCC_AHBENR_GPIOAEN;
}

void init_adc( void )
{
	RCC->CR |= RCC_CR_HSION; //Enable HSI
	RCC->APB2ENR |= RCC_APB2ENR_ADC1EN; //Enable ADC clock
	while(!(RCC->CR & RCC_CR_HSIRDY)); //Wait for HSI
	
	enable_gpio_clocks_a();
	
	//BAT_VOLTAGE ADC pin - 15
	GPIO_ANALOG(GPIOB, 15);
	GPIO_SPEED_10M(GPIOB, 15);
	GPIO_PUSHPULL(GPIOB, 15);
	
	//KEY1- A6
	GPIO_ANALOG(GPIOA, 6);
	GPIO_SPEED_10M(GPIOA, 6);
	GPIO_PUSHPULL(GPIOA, 6);
	
	//KEY2 - A7
	GPIO_ANALOG(GPIOA, 7);
	GPIO_SPEED_10M(GPIOA, 7);
	GPIO_PUSHPULL(GPIOA, 7);
	
	disable_gpio_clocks_a();
	
	ADC1->CR1 |= (ADC_CR1_PDD | ADC_CR1_PDI); //enable both powerdowns
	ADC1->CR2 |= (ADC_CR2_DELS_0);	//Delay untill read
	//SQR1 ok - 1 channel regular
	
	ADC1->SQR5 |= 0x15;		//Set channel 21 1st in line
	ADC1->SMPR1 |= (0x03<<3); //Max cycles per conversion for 21 channel
	ADC1->SMPR3 |= (0x03<<18); //Max cycles per conversion for 6 channel
	ADC1->SMPR3 |= (0x03<<21); //Max cycles per conversion for 7 channel
	
	ADC1->CR2 |= ADC_CR2_ADON; //Enable the ADC
	while(!(ADC1->SR & ADC_SR_ADONS));
}
//Add start adc and stop adc routines to lower power.
//Should probably do that for everything
void start_adc(void)
{
	RCC->CR |= RCC_CR_HSION; //Enable HSI
	RCC->APB2ENR |= RCC_APB2ENR_ADC1EN; //Enable ADC clock
	while(!(RCC->CR & RCC_CR_HSIRDY)); //Wait for HSI
	
	ADC1->CR2 |= ADC_CR2_ADON; //Enable the ADC
	while(!(ADC1->SR & ADC_SR_ADONS));//Wait for ADC
}

void stop_adc(void)
{
	ADC1->CR2 &= ~ADC_CR2_ADON; //Disable the ADC
	RCC->APB2ENR &= ~RCC_APB2ENR_ADC1EN; //Disable ADC clock
	RCC->CR &= ~RCC_CR_HSION; //Enable HSI
}

uint16_t measure_battery(void)
{
	ADC1->SQR5 |= 0x15;		//Set channel 21 1st in line
	ADC1->SMPR1 |= (0x03<<3); //Max cycles per conversion

	ADC1->CR2 |= ADC_CR2_SWSTART; //Start conv
	while(ADC1->CR2 & ADC_CR2_SWSTART);
	while(!(ADC1->SR & ADC_FLAG_EOC)); //Wait for conversion
	return ADC1->DR;
}

uint16_t measure_key_1(void)
{
	//Measure 1.2 ref -- fill capacitor
	ADC1->SQR5 |= 0x15;		//Set channel 21 1st in line
	ADC1->SMPR1 |= (0x03<<3); //Max cycles per conversion

	ADC1->CR2 |= ADC_CR2_SWSTART; //Start conv
	while(ADC1->CR2 & ADC_CR2_SWSTART);
	
	//Pullup key
	GPIO_OUTPUT(GPIOA, 6);
	GPIO_SET(GPIOA, 6);
	GPIO_FUNCTION(GPIOA, 6, 0x00);
	
	//Complete cap fill
	while(!(ADC1->SR & ADC_FLAG_EOC)); //Wait for conversion
	
	uint16_t reference;
	reference = ADC1->DR;
	
	//Measure key
	GPIO_ANALOG(GPIOA, 6);
	
	//Measure voltage on key
	ADC1->SQR5 |= 0x07;		//Set channel 7 1st in line

	ADC1->CR2 |= ADC_CR2_SWSTART; //Start conv
	while(ADC1->CR2 & ADC_CR2_SWSTART);
	while(!(ADC1->SR & ADC_FLAG_EOC)); //Wait for conversion
	
	uint16_t value;
	value = ADC1->DR;
	
	return value;
}