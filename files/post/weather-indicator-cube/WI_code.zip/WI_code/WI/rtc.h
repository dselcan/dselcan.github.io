#ifndef RTC_H
#define RTC_H 1

//Other files
#include "defines.h"
#include "cgpio.h"
#include "color.h"
#include "time.h"


extern uint8_t rn_update;
extern uint8_t misc_update;


#define RN_UPDATE_INTERVAL 60
#define MISC_UPDATE_INTERVAL 200
#define MINUTE_UPDATE_INTERVAL 30

void init_rtc(void);

void delay_ms(uint16_t delay);

void set_timeout(uint16_t timeout);

uint8_t timeout_occured();


#endif