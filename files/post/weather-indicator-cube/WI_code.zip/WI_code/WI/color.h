#ifndef COLOR_H
#define COLOR_H 1

#include "weather.h"
#include "defines.h"
#include "inet.h"
#include "timer.h"
#include "usart.h"

//Error codes
//Move to colors
#define TOTAL_MODES			5 //Mode normal doesn't count

#define MODE_IDLE			0
#define MODE_NO_NETWORK		1
#define MODE_RN_ERROR		2
#define MODE_USB_ACCEPT		3
#define MODE_LOW_BATTERY	4


typedef struct{
	uint8_t red;
	uint8_t green;
	uint8_t blue;
	uint8_t duration;
} color_frame;

extern color_frame weather_sequences[TOTAL_WEATHER][MAX_COLOR_FRAMES];
extern uint8_t weather_lengths[TOTAL_WEATHER];
extern color_frame mode_sequences[TOTAL_MODES][MAX_COLOR_FRAMES];
extern uint8_t mode_lengths[TOTAL_MODES];

//uint8_t get_current_color(uint8_t start, uint8_t end, uint8_t step, uint8_t duration);

void update_color_cycle(void);

#endif