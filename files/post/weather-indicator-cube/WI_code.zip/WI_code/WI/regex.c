
#include "regex.h"

char block_until_sequence(char* s)
{
	char current;
	char* s_orig = s;
	while(1){
		if(*s == '\0'){
			return 1;
		}
		set_timeout(REGEX_TIMEOUT);
		while(!rn_filled()){
			if(timeout_occured()){
				return 0;
			}
		}
		current = rn_getchar();
		if(*s == current){
			s++;
		}else{
			s = s_orig;
		}
	}
}

char block_until_sequence2(char* s1, char* s2)
{
	char current;
	char* s1_orig = s1;
	char* s2_orig = s2;
	while(1){
		if(*s1 == '\0'){
			return 1;
		}
		if(*s2 == '\0'){
			return 2;
		}
		set_timeout(REGEX_TIMEOUT);
		while(!rn_filled()){
			if(timeout_occured()){
				return 0;
			}
		}
		current = rn_getchar();
		if(*s1 == current){
			s1++;
		}else{
			s1 = s1_orig;
		}
		if(*s2 == current){
			s2++;
		}else{
			s2 = s2_orig;
		}
	}
}

char block_until_sequence3(char* s1, char* s2, char* s3)
{
	char current;
	char* s1_orig = s1;
	char* s2_orig = s2;
	char* s3_orig = s3;
	while(1){
		if(*s1 == '\0'){
			return 1;
		}
		if(*s2 == '\0'){
			return 2;
		}
		if(*s3 == '\0'){
			return 3;
		}
		set_timeout(REGEX_TIMEOUT);
		while(!rn_filled()){
			if(timeout_occured()){
				return 0;
			}
		}
		current = rn_getchar();
		if(*s1 == current){
			s1++;
		}else{
			s1 = s1_orig;
		}
		if(*s2 == current){
			s2++;
		}else{
			s2 = s2_orig;
		}
		if(*s3 == current){
			s3++;
		}else{
			s3 = s3_orig;
		}
	}
}

//Max length defined in defines.h
char block_until_found(char const* const s_array[], uint8_t length)
{
	assert_param(length <= MAX_GENERAL);
	char const* s_inc[MAX_GENERAL];
	char current;
	uint8_t i;
	
	for(i = 0; i < length; i++){
		s_inc[i] = s_array[i];
	}
	
	while(1){
		for(i = 0; i < length; i++){
			if(*(s_inc[i]) == '\0'){
				return i + 1;
			}
		}
		
		set_timeout(REGEX_TIMEOUT);
		while(!rn_filled()){
			if(timeout_occured()){
				return 0;
			}
		}
		current = rn_getchar();
		
		for(i = 0; i < length; i++){
			if(*(s_inc[i]) == current){
				s_inc[i]++;
			}else{
				s_inc[i] = s_array[i];
			}
		}
	}
}

void empty_buffer(void)
{
	while(rn_filled()){
		rn_getchar();
	}
}

