#include "weather.h"

char const* const weather_brightness[WEATHER_BRIGHTNESS_LENGTH] = {
"clear",		//1
"mostClear",	//2
"slightCloudy",	//3
"partCloudy",	//4
"modCloudy",	//5
"prevCloudy",	//6
"overcast",		//7
"FG"			//8
};

char const* const weather_special[WEATHER_SPECIAL_LENGTH] = {
"light",		//1
"mod",			//2
"heavy",		//3
"FG",			//4
"DZ",			//5
"FZDZ",			//6
"RA",			//7
"FZRA",			//8
"RASN",			//9
"SN",			//10
"SHRA",			//11
"SHRASN",		//12
"SHSN",			//13
"SHGR",			//14
"TS",			//15
"TSRA",			//16
"TSRASN",		//17
"TSSN",			//18
"TSGR"			//19
};

uint8_t weather_slots[NUMBER_OF_SLOTS] = {0};

uint8_t get_weather(weather_type* weather_data)
{
	//Fog handle
	if(weather_data->special == FG){
		weather_data->special = NO_SPECIAL;
		weather_data->brightness = FOG;
	}

	if (weather_data->special == NO_SPECIAL){
		switch (weather_data->brightness){
			case CLEAR:
			case MOST_CLEAR:
			case SLIGHT_CLOUDY:
			case PART_CLOUDY:
				if(weather_data->wind > WIND_LINE){
					return WEATHER_SUNNY_WI;
				}else if(weather_data->temperature <= TEMP_LOW){
					return WEATHER_SUNNY_FR;
				}else if(weather_data->temperature <= TEMP_MOD){
					return WEATHER_SUNNY_LOW;
				}else if(weather_data->temperature <= TEMP_HIGH){
					return WEATHER_SUNNY_MOD;
				}else{
					return WEATHER_SUNNY_HIGH;
				}
				break;
			case MOD_CLOUDY:
			case PREV_CLOUDY:
			case OVERCAST:
				if(weather_data->wind > WIND_LINE){
					return WEATHER_CLOUD_WI;
				}else if(weather_data->temperature <= TEMP_LOW){
					return WEATHER_CLOUD_FR;
				}else if(weather_data->temperature <= TEMP_MOD){
					return WEATHER_CLOUD_LOW;
				}else if(weather_data->temperature <= TEMP_HIGH){
					return WEATHER_CLOUD_MOD;
				}else{
					return WEATHER_CLOUD_HIGH;
				}
				break;
			case FOG:
				if(weather_data->wind > WIND_LINE){
					return WEATHER_FOG_WI;
				}else{
					return WEATHER_FOG_MOD;
				}
				break;
			default:
				return 0;
			break;
		}
	}else{
		switch( weather_data->special ){
			//Fog
			//case FG:
			//Handled at start -> assigned to brightness instead
			//break;
			//Drizzle
			case DZ:
			case FZDZ:
				if(weather_data->severity == SEV_HEAVY){
					if(weather_data->wind > WIND_LINE){
						return WEATHER_RAIN_WI;
					}else{
						return WEATHER_RAIN_LOW;
					}
				}else{
					if(weather_data->wind > WIND_LINE){
						return WEATHER_RAIN_MWI;
					}else{
						return WEATHER_RAIN_MIC;
					}
				}
			break;
			//Rain
			case RA:
			case SHRA:
			case FZRA:
			case RASN:
			case SHRASN:
				if(weather_data->severity == SEV_LIGHT){
					if(weather_data->wind > WIND_LINE){
						return WEATHER_RAIN_MWI;
					}else{
						return WEATHER_RAIN_MIC;
					}
					
				}else if(weather_data->severity == SEV_MOD){
					if(weather_data->wind > WIND_LINE){
						return WEATHER_RAIN_WI;
					}else{
						return WEATHER_RAIN_LOW;
					}
				}else{ //SEV_HIGH
					return WEATHER_RAIN_MOD;
				}
			break;
			//Snow
			case SN:
			case SHSN:
				if(weather_data->severity == SEV_HEAVY){
					return WEATHER_SNOW_MOD;
				}else{
					if(weather_data->wind > WIND_LINE){
						return WEATHER_SNOW_LOW;
					}else{
						return WEATHER_SNOW_WI;
					}
				}
			break;
			//Thunderstorm
			case TS:
			case TSRA:
			case TSRASN:
				if(weather_data->severity == SEV_LIGHT){
					return WEATHER_RAIN_MOD;
				}else{
					return WEATHER_RAIN_HIGH;
				}
			break;
			//Thunderrain
			case TSSN:
				if(weather_data->severity == SEV_LIGHT){
					return WEATHER_SNOW_MOD;
				}else{
					return WEATHER_SNOW_HIGH;
				}
			break;
			//Hail
			case SHGR:
				if(weather_data->severity == SEV_HEAVY){
					return WEATHER_HAIL_MOD;
				}else{
					return WEATHER_HAIL_LOW;
				}
			case TSGR:
				if(weather_data->severity == SEV_LIGHT){
					return WEATHER_HAIL_MOD;
				}else{
					return WEATHER_HAIL_HIGH;
				}
			break;
			default:
			return 0;
			break;
		}	
	}
}
