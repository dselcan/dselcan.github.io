#ifndef LOCATION_H
#define LOCATION_H 1

#define LOCATIONS 19

extern uint8_t current_location;

extern char const* const location_string[LOCATIONS];
extern int16_t const location_lat[LOCATIONS];
extern int16_t const location_lon[LOCATIONS];

uint8_t closest_location(int16_t lat, int16_t lon);

#endif