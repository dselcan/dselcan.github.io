#ifndef ADC_H
#define ADC_H 1

//Periph library
#include <stm32l1xx.h>
#include <stm32l1xx_rcc.h>
#include <stm32l1xx_gpio.h>
#include <stm32l1xx_usart.h>
#include <stm32l1xx_tim.h>
#include <stm32l1xx_adc.h>
#include <stm32l1xx_rtc.h>
#include <stm32l1xx_pwr.h>
#include <stm32l1xx_exti.h>
#include <misc.h>

//Other files
#include "defines.h"
#include "cgpio.h"

#ifdef GLOBAL_INIT_STRUCTURES
extern ADC_InitTypeDef ADC_InitStructure;
extern GPIO_InitTypeDef GPIO_InitStructure;
#endif

void init_adc(void);

void stop_adc(void);
void start_adc(void);

uint16_t measure_battery(void);

uint16_t measure_key_1(void);


#endif