#include "timer.h"

uint16_t max_duty_cycle = 1024; //FULL

void init_timer(void)
{
	RCC->APB1ENR |= RCC_APB1ENR_TIM3EN; //Enable clock
	
	//RED 4
	GPIO_ALTERNATE(GPIOB, 4);
	GPIO_SPEED_10M(GPIOB, 4);
	GPIO_PUSHPULL(GPIOB, 4);
	GPIO_FUNCTION(GPIOB, 4, 0x02);
	GPIO_NOPULL(GPIOB, 4); //DUE TO DEFAULT
	
	//GREEN 5
	GPIO_ALTERNATE(GPIOB, 5);
	GPIO_SPEED_10M(GPIOB, 5);
	GPIO_PUSHPULL(GPIOB, 5);
	GPIO_FUNCTION(GPIOB, 5, 0x02);
	
	//BLUE 0
	GPIO_ALTERNATE(GPIOB, 0);
	GPIO_SPEED_10M(GPIOB, 0);
	GPIO_PUSHPULL(GPIOB, 0);
	GPIO_FUNCTION(GPIOB, 0, 0x02);
	
	//TIM init
	//CR1 OK
	TIM3->ARR = 2048; //Period, for 2 MHz clock = 1kHz
	TIM3->PSC = 0; //Prescaler
	
	TIM3->CR1 |= TIM_CR1_ARPE; // ARR Auto reload
	
	
	TIM3->CCMR1 |= (TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2 | TIM_CCMR1_OC1PE); //Set PWM 1, set preload
	TIM3->CCER |= TIM_CCER_CC1E; //Enable OC out
	TIM3->CCR1 = 0x0000; //PWM width
	
	TIM3->CCMR1 |= (TIM_CCMR1_OC2M_1 | TIM_CCMR1_OC2M_2 | TIM_CCMR1_OC2PE); //Set PWM 1, set preload
	TIM3->CCER |= TIM_CCER_CC2E; //Enable OC out
	TIM3->CCR2 = 0x0000; //PWM width
	
	TIM3->CCMR2 |= (TIM_CCMR2_OC3M_1 | TIM_CCMR2_OC3M_2 | TIM_CCMR2_OC3PE); //Set PWM 1, set preload
	TIM3->CCER |= TIM_CCER_CC3E; //Enable OC out
	TIM3->CCR3 = 0x0000; //PWM width
	
	TIM3->EGR |= TIM_EGR_UG; // Update values
	
	TIM3->CR1 |= TIM_CR1_CEN;  //Enable counter
	
	
}

void start_timer(void)
{
	RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;
	TIM3->CR1 |= TIM_CR1_CEN;
}

void stop_timer(void)
{
	TIM3->CR1 &= ~TIM_CR1_CEN;
	RCC->APB1ENR &= ~RCC_APB1ENR_TIM3EN;
}

void set_red(uint8_t color)
{
	uint16_t ccr = (uint16_t)((((uint32_t)color*(uint32_t)max_duty_cycle)/0xff)&0xffff);
	//pc_putchar('r');
	//pc_putint(ccr);
	TIM3->CCR1 = ccr;
}

void set_green(uint8_t color)
{
	uint16_t ccr = (uint16_t)((((uint32_t)color*(uint32_t)max_duty_cycle)/0xff)&0xffff);
	//pc_putchar('g');
	//pc_putint(ccr);
	TIM3->CCR2 = ccr;
}

void set_blue(uint8_t color)
{
	uint16_t ccr = (uint16_t)((((uint32_t)color*(uint32_t)max_duty_cycle)/0xff)&0xffff);
	//pc_putchar('b');
	//pc_putint(ccr);
	//pc_putchar('\r');
	//pc_putchar('\n');
	TIM3->CCR3 = ccr;
}

