#include "stdint.h"

#include "location.h"

uint8_t current_location;

char const* const location_string[LOCATIONS] = {
"AT_KAERNTEN", //0
"AT_STEIERMARK", //1
"HR_PRIMORSKO-GORANSKA", //2
"HR_ZAGREBACKA", //3
"SI_BELOKRANJSKA", //4
"SI_BOVSKA", //5
"SI_DOLENJSKA", //6
"SI_GORENJSKA", //7
"SI_GORISKA", //8
"SI_KOCEVSKA", //9
"SI_KOROSKA", //10
"SI_OSREDNJESLOVENSKA", //11
"SI_NOTRANJSKO-KRASKA", //12
"SI_OBALNO-KRASKA", //13
"SI_PODRAVSKA", //14
"SI_POMURSKA", //15
"SI_SAVINJSKA", //16
"SI_SPODNJEPOSAVSKA", //17
"SI_ZGORNJESAVSKA" //18
};

int16_t const location_lat[LOCATIONS] = {
4673,
4690,
4521,
4581,
4550,
4630,
4580,
4625,
4590,
4560,
4650,
4600,
4575,
4552,
4648,
4670,
4622,
4592,
4649
};

int16_t const location_lon[LOCATIONS] = {
1435,
1540,
1458,
1610,
1525,
1360,
1510,
1415,
1370,
1478,
1500,
1460,
1425,
1375,
1580,
1620,
1522,
1560,
1390
};


uint8_t closest_location(int16_t lat, int16_t lon){
	uint8_t i;
	uint8_t best;
	uint32_t best_val;
	uint32_t val;

	best_val = 0xffffffff;
	best = 0;
	for(i = 0; i < LOCATIONS; i++){
		int16_t dlat;
		int16_t dlon;
		dlat = lat - location_lat[i];
		dlon = lon - location_lon[i];

		val = (uint32_t)(dlat*dlat + dlon*dlon);

		if (val < best_val){
			best = i;
			best_val = val;
		}
	}
	return best;
}