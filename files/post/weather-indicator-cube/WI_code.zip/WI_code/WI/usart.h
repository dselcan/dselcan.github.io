#ifndef USART_H
#define USART_H 1

//Other files
#include "defines.h"
#include "cgpio.h"


//#ifdef GLOBAL_INIT_STRUCTURES
//extern USART_InitTypeDef USART_InitStructure;
//extern GPIO_InitTypeDef GPIO_InitStructure;
//#endif



#define BUFFER_MAX BUFFER_SIZE
typedef struct{
	char buffer[BUFFER_SIZE];
	uint16_t start;
	uint16_t end;
	//uint16_t fill;
} usart_buffer;


extern usart_buffer rn_buffer;

void init_usart(void);

void start_usart_pc(void);
void stop_usart_pc(void);

void pc_putchar(char c);
void pc_putstring(char* s);
void pc_putint(uint32_t num);

void start_usart_rn(void);
void stop_usart_rn(void);
void usart_rn_baud_rate_override(uint16_t val, uint8_t flow);

char rn_getchar(void);
char rn_filled(void);
void rn_putchar(char c);
void rn_putstring(char* s);
void rn_putstring_const(char const* const sc);

void USART3_IRQHandler(void);


#endif