//Other files
#include "defines.h"
#include "usart.h"
#include "timer.h"
#include "adc.h"
#include "regex.h"
#include "rtc.h"
#include "inet.h"
#include "time.h"

#include "cgpio.h"


//extern usart_buffer rn_buffer;



void enable_gpio_clocks(void)
{
	//enable clocks to ports
	RCC->AHBENR |= RCC_AHBENR_GPIOBEN;
}

void init_gpio(void)
{
	//RN RESET PIN - 1
	GPIO_SET(GPIOB, 1);
	GPIO_OUTPUT(GPIOB, 1);
	GPIO_PUSHPULL(GPIOB, 1);
	GPIO_SPEED_10M(GPIOB, 1);
	GPIO_FUNCTION(GPIOB, 1, 0x00);
	GPIO_SET(GPIOB, 1);
	
	//FORCE AWAKE PIN - 2
	GPIO_OUTPUT(GPIOB, 2);
	GPIO_PUSHPULL(GPIOB, 2);
	GPIO_SPEED_10M(GPIOB, 2);
	GPIO_RESET(GPIOB, 2);
	GPIO_FUNCTION(GPIOB, 2, 0x00);
	
	//ADHOC/REFLASH PIN - 3
	GPIO_OUTPUT(GPIOB, 3);
	GPIO_PUSHPULL(GPIOB, 3);
	GPIO_SPEED_10M(GPIOB, 3);
	GPIO_RESET(GPIOB, 3);
	GPIO_FUNCTION(GPIOB, 3, 0x00);
	
	//USB IN PIN - 12
	GPIO_INPUT(GPIOB, 12);
	GPIO_SPEED_10M(GPIOB, 12);
	GPIO_NOPULL(GPIOB, 12);
	GPIO_FUNCTION(GPIOB, 12, 0x00);
	
	//SEL2 PIN - 8
	GPIO_INPUT(GPIOB, 8);
	GPIO_SPEED_10M(GPIOB, 8);
	GPIO_NOPULL(GPIOB, 8);
	GPIO_FUNCTION(GPIOB, 8, 0x00);
	
	//SEL1 PIN - 9
	GPIO_INPUT(GPIOB, 9);
	GPIO_SPEED_10M(GPIOB, 9);
	GPIO_NOPULL(GPIOB, 9);
	GPIO_FUNCTION(GPIOB, 9, 0x00);
}

void configure_interrupts(void)
{
	//Got values from misc.c
	//Priorities 0x700 to 0x300, Group_0 = 0x700 - no priority; Group_4 = 0x300 - all priority
	SCB->AIRCR = 0x05FA0000 | 0x300;
}

uint8_t factory_reset_rn_module(void)
{
	char err = 0;
	//Factory reset sequence
	GPIO_SET(GPIOB, 3);
	
	//Reset the module
	reset_rn();
	
	delay_ms(1000);
	
	
	//Perform toggle
	GPIO_RESET(GPIOB, 3);
	delay_ms(1500);
	GPIO_SET(GPIOB, 3);
	delay_ms(1500);
	GPIO_RESET(GPIOB, 3);
	delay_ms(1500);
	GPIO_SET(GPIOB, 3);
	delay_ms(1500);
	GPIO_RESET(GPIOB, 3);
	delay_ms(1500);
	GPIO_SET(GPIOB, 3);
	delay_ms(1500);
	GPIO_RESET(GPIOB, 3);
	/*
	delay_ms(1500);
	GPIO_SET(GPIOB, 3);
	delay_ms(1500);
	GPIO_RESET(GPIOB, 3);
	delay_ms(1500);
	GPIO_SET(GPIOB, 3);
	delay_ms(1500);
	GPIO_RESET(GPIOB, 3);
	delay_ms(1500);
	GPIO_SET(GPIOB, 3);
	delay_ms(1500);
	GPIO_RESET(GPIOB, 3);
	delay_ms(1500);
	*/
	
	//Reset the module
	GPIO_RESET(GPIOB, 1);
	delay_ms(20);
	GPIO_SET(GPIOB, 1);
	delay_ms(1000);
	
	usart_rn_baud_rate_override(0x00d5, 0); //9,6k default, FLOW OFF
	//usart_rn_baud_rate_override(0x0034, 0); //9,6k default, FLOW OFF
	delay_ms(250);
	rn_putstring("$$$");
	err = block_until_sequence("CMD");
	if(err != 1){
		return 0;
	}
	
	//delay_ms(1000);
	//rn_putstring("set u f 0x01\r"); //Set uart flow control
	//err = block_until_sequence2("AOK", "ERR");
	//if (err != 1)
	//{
	//	return 0;
	//}
	
	rn_putstring("set u b 9600\r"); //Set uart baud rate
	err = block_until_sequence2("AOK", "ERR");
	if (err != 1)
	{
		return 0;
	}
	
	rn_putstring("save\r"); //Save
	//err = block_until_sequence2("AOK", "ERR");
	//if (err != 1)
	//{
	//	return 0;
	//}
	
	delay_ms(2000);
	rn_putstring("ls\r"); //Save
	delay_ms(2000);
	empty_buffer();
	delay_ms(1000);
	
	#if PC_DEBUG
	pc_putstring("Reset sucessfull.");
	#endif
	
	reset_rn();
	
	usart_rn_baud_rate_override(0x00d5, 0); 
	return 1;
}

inet_error update_time( void )
{
	inet_error error;
	uint8_t day;
	error = inet_get_time(&current_time);
	if(error){
		return error;
	}
	day = get_day_difference(&previous_time, &current_time);
	if((day >= (NUMBER_OF_SLOTS/SLOTS_PER_DAY)) || (day == 0)){
		status |= STATUS_WEATHER_SLOTS_EMPTY;
		current_slot = 0;
	}else{
		day--;
		current_slot = (current_slot + day*SLOTS_PER_DAY)%NUMBER_OF_SLOTS;
	}
	copy_time(&current_time, &previous_time);
	copy_time(&current_time, &rough_time);
	
	return INET_NO_ERROR;
}

inet_error update_location( void )
{
	inet_error error;
	error = inet_get_location(&current_location);
	if(error){
		return error;
	}	

	return INET_NO_ERROR;
}

inet_error update_weather( void )
{
	inet_error error;
	error = inet_get_weather_info(weather_slots);
	if(error && error != INET_MILD_ERROR){
		return error;
	}
	
	status &= ~STATUS_WEATHER_SLOTS_EMPTY;
	status &= ~STATUS_INIT;
	
	return error;
}

void enter_sleep(void)
{
	__WFI();
}


int main ( void )
{
	status |= STATUS_INIT; //We have inited the device;

	configure_interrupts();
	enable_gpio_clocks();
	init_gpio();
	init_usart();
	
	uint32_t reset_vector = RCC->CSR;
	pc_putstring("\nR-");
	if(reset_vector & RCC_CSR_LPWRRSTF){/*!< Low-Power reset flag */ 
		pc_putchar('L');
	}
	if(reset_vector & RCC_CSR_OBLRSTF){ /*!< Option Bytes Loader reset flag */
		pc_putchar('O');
	}
	if(reset_vector & RCC_CSR_PINRSTF){ /*!< PIN reset flag */
		pc_putchar('N');
	}
	if(reset_vector & RCC_CSR_PORRSTF){ /*!< POR/PDR reset flag */
		pc_putchar('P');
	}
	if(reset_vector & RCC_CSR_SFTRSTF){ /*!< Software Reset flag */
		pc_putchar('S');
	}
	if(reset_vector & RCC_CSR_IWDGRSTF){ /*!< Independent Watchdog reset flag */
		pc_putchar('I');
	}
	if(reset_vector & RCC_CSR_WWDGRSTF){ /*!< Window watchdog reset flag */
		pc_putchar('W');
	}
	pc_putchar('\n');
	RCC->CSR |= RCC_CSR_RMVF; /*!< Reset flags */
	
	
	//init_adc();
	init_timer();
	init_rtc();
	
	pc_putstring("Start.\n");
	
	//stop_timer();
	//start_timer();
	
	//stop_adc();
	//start_adc();
	//measure_battery();
	
	if GPIO_READ(GPIOB, 8){
		pc_putstring("Reinited.\n");
		factory_reset_rn_module();
	}else{
		pc_putstring("Didn't Reinit.\n");
		reset_rn();
	}
	
	
	inet_error error;
	while (1) {
		if(misc_update){
			//check_power_here();
			misc_update = 0;
		}
		if(rn_update){
			rn_stop_sleep();
			delay_ms(200);
			if(status&STATUS_INIT){
				setup_rn_module();
				delay_ms(200);
			}
			connect_to_network(0x00);
			delay_ms(200);
			error = update_time();
			delay_ms(200);
			error |= update_location();
			delay_ms(200);
			error |= update_weather();
			if(error){
				reset_rn();
				delay_ms(500);
				setup_rn_module();
				delay_ms(200);
			}else{
				delay_ms(200);
				rn_sleep();
				rn_update = 0;
			}
		}
		enter_sleep();
	}
}

# ifdef USE_FULL_ASSERT
void assert_failed ( uint8_t * file , uint32_t line )
{
/* Infinite loop */
/* Use GDB to find out why we 're here */
while (1) ;
}
# endif