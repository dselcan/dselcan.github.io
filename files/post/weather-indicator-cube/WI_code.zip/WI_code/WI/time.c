#include "time.h"

time current_time = {.year = 2000, .month = 1, .day = 1, .hour = 0, .minute = 0};
time previous_time = {.year = 2000, .month = 1, .day = 1, .hour = 0, .minute = 0};
time rough_time = {.year = 2000, .month = 1, .day = 1, .hour = 0, .minute = 0};
uint8_t current_slot = 0;

void copy_time(time* t_source, time* t_dest)
{
	t_dest->year = t_source->year;
	t_dest->month = t_source->month;
	t_dest->day = t_source->day;
	t_dest->hour = t_source->hour;
	t_dest->minute = t_source->minute;
}

uint8_t is_leap_year(uint16_t year)
{
	return !(year%400)||(!(year%4)&&(year%100));
}

uint8_t get_day_of_month(uint8_t month, uint16_t year)
{
	if (month == 4 || month == 6 || month == 9 || month == 11){
		return 30;
	}
	else if (month == 2){
		if(is_leap_year(year)){
			return 29;
		}
		else{
			return 28;
		}
	}
	return 31;
}

//Increments rough by 1 minute
void increment_rough_time(void)
{
	rough_time.minute++;
	if(rough_time.minute >= 60){
		rough_time.minute = 0;
		rough_time.hour++;
		if(rough_time.hour >= 24){
			rough_time.hour = 0;
			rough_time.day++;
			if(rough_time.day > get_day_of_month(rough_time.month, rough_time.year)){
				rough_time.day = 1;
				rough_time.month++;
				if(rough_time.month > 12){
					rough_time.month = 1;
					rough_time.year++;
				}
			}
		}
	}
}

//Max guaranteed number is 29 up to 62 everything else is 0
//1 is same day,...
uint8_t get_day_difference(time* t_old, time* t_new)
{
	if ((t_new->month == 1) && (t_old->month == 12) && (t_new->year - t_old->year == 1)){
		return (t_new->day + get_day_of_month(t_old->month, t_old->year) - t_old->day + 1);
	}else if ((t_new->month - t_old->month == 1) && (t_new->year == t_old->year)){
		return (t_new->day + get_day_of_month(t_old->month, t_old->year) - t_old->day + 1);
	}else if ((t_new->month == t_old->month) && (t_new->year == t_old->year) && (t_new->day >= t_old->day)){
		return (t_new->day - t_old->day + 1);
	}else{
		return 0;
	}
}

//Presumed t.day >= current_time.day
//**************************************************************************************
//MISSING FUNCTIONALITY: WON'T UPDATE WHEN T == 0 to 2 and the 21 to 23 timeslot changes
//**************************************************************************************
uint8_t get_slot_difference_old(time* t_old, time* t_new)
{
	uint8_t time_diff;
	if((t_new->day == t_old->day) && (t_new->month == t_old->month) && (t_new->year == t_old->year)){
		if(t_new->hour < t_old->hour){
			//6:05 - 6:00
			if(t_old->hour - t_new->hour <= HOURS_BETWEEN_SLOTS){
				return 1;
			}else{
				return 0;
			}
		}
	}
	time_diff = (24 + t_new->hour - t_old->hour)%24;
	time_diff = time_diff/HOURS_BETWEEN_SLOTS + 2;
	return time_diff;
}

uint8_t get_slot_difference(time* t)
{
	return t->hour/HOURS_BETWEEN_SLOTS;
}


//Slot MAX-1 is day difference too large
//Slot MAX is out of scope/can finish prediction
uint8_t get_prediction_slot(time* t)
{
	uint8_t slot;
	uint8_t day;
	
	day = get_day_difference(&current_time, t);
	if(day == 0){
		return 0xff-1;
	}
	day--;
	if(day >= (NUMBER_OF_SLOTS/SLOTS_PER_DAY)){
		return 0xff;
	}
	
	slot = get_slot_difference(t);
	assert_param(!(current_slot%SLOTS_PER_DAY));
	return (current_slot + NUMBER_OF_SLOTS + day*SLOTS_PER_DAY + slot)%NUMBER_OF_SLOTS;
	
}

uint8_t get_current_slot(void)
{
	uint8_t slot;
	slot = get_slot_difference(&rough_time);
	assert_param(!(current_slot%SLOTS_PER_DAY));
	return current_slot + slot;
}