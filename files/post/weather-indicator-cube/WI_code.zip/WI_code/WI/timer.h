#ifndef TIMER_H
#define TIMER_H 1

//Other files
#include "defines.h"
#include "cgpio.h"
#include "color.h"
#include "time.h"
#include "weather.h"
#include "inet.h"
#include "usart.h"

extern uint16_t max_duty_cycle;

void init_timer(void);

void stop_timer(void);
void start_timer(void);

void set_red(uint8_t color);
void set_green(uint8_t color);
void set_blue(uint8_t color);


#endif